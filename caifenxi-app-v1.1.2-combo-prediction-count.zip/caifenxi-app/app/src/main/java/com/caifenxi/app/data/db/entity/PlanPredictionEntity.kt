package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index

@Entity(
    tableName = "plan_predictions",
    primaryKeys = ["planId", "lotteryKey", "targetIssue"],
    indices = [Index(value = ["lotteryKey", "targetIssue"]), Index(value = ["planId", "targetIssue"])]
)
data class PlanPredictionEntity(
    val planId: String,
    val lotteryKey: String,
    val targetIssue: String,
    val cutoffIssue: String,
    val output: String,
    val scoreAtPredict: Double,
    val weightAtPredict: Double,
    val settled: Boolean = false,
    val hit: Boolean? = null,
    val settledAt: Long? = null,
    val planName: String = "",
    val category: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
