package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.AlgoSelector
import com.caifenxi.app.ui.components.CaptionMuted
import kotlin.math.roundToInt

private enum class AnalysisTab(val label: String) {
    PRED("预测"), FREQ("频率"), SUM("和值"), BS("大小单双"), PERIOD("时段"), LUZHU("路珠"), MANUAL("手动")
}

@Composable
fun PredictScreen(vm: MainViewModel) {
    var tab by remember { mutableStateOf(AnalysisTab.PRED) }
    val pred = vm.prediction.value
    val algo = vm.currentAlgo.value
    val compare = vm.algoCompare.value
    val analysis = vm.analysis.value
    val marks = vm.manualMarks.value

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("分析", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AnalysisTab.entries.forEach { t ->
                FilterChip(
                    selected = tab == t,
                    onClick = { tab = t },
                    label = { Text(t.label, fontSize = 12.sp) }
                )
            }
        }

        when (tab) {
            AnalysisTab.PRED -> {
                Text("算法模式", fontWeight = FontWeight.SemiBold)
                AlgoSelector(selected = algo, onSelect = { vm.selectAlgo(it) })
                Spacer(Modifier.height(8.dp))
                if (pred == null) {
                    Text("请先在首页加载数据")
                } else {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("目标第 ${pred.targetIssue} 期 · ${AlgoMode.fromId(pred.algoTag).label}", fontWeight = FontWeight.Bold)
                            Text("截止 ${pred.cutoffIssue}", style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(12.dp))
                            pred.dx?.let { DirBlock("大小", it.direction, it.score, it.detail) }
                            Spacer(Modifier.height(8.dp))
                            pred.ds?.let { DirBlock("单双", it.direction, it.score, it.detail) }
                            Spacer(Modifier.height(8.dp))
                            if (pred.comboList.isNotEmpty()) {
                                Text("大小单双组合预测 Top${pred.comboList.size}", fontWeight = FontWeight.SemiBold)
                                CaptionMuted("按设置显示 1~4 个结果；四类结果为大单、大双、小单、小双")
                                pred.comboList.forEachIndexed { i, c ->
                                    Spacer(Modifier.height(6.dp))
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("${i + 1}. ${c.direction}", fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Normal)
                                        Text("${(c.score * 100).toInt()}%")
                                    }
                                }
                            } else {
                                pred.combo?.let { DirBlock("组合首选", it.direction, it.score, it.detail) }
                            }
                        }
                    }
                    if (algo == AlgoMode.COMPARE && compare.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Text("多算法对比", fontWeight = FontWeight.Bold)
                        compare.forEach { (cat, list) ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(cat, fontWeight = FontWeight.SemiBold)
                                    list.forEach { r ->
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(r.algoLabel)
                                            Text("${r.direction} ${(r.score * 100).roundToInt()}% ${r.confidence}")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (pred.numberScores.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("号码热度 Top", fontWeight = FontWeight.Bold)
                                pred.numberScores.take(15).chunked(5).forEach { row ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        row.forEach { ns ->
                                            Box(
                                                Modifier.weight(1f).background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(8.dp)).padding(8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("${ns.number}\n${(ns.score * 100).roundToInt()}%", fontSize = 11.sp)
                                            }
                                        }
                                        repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
                                    }
                                    Spacer(Modifier.height(4.dp))
                                }
                            }
                        }
                    }
                    if (pred.combinations.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("快乐8组合首选结果", fontWeight = FontWeight.Bold)
                                CaptionMuted("由大小单双倾向 + 号码评分 + 区间/结构约束生成；不是中奖概率。")
                                pred.combinations.forEachIndexed { i, combo ->
                                    Text("${i + 1}. ${combo.joinToString(" ")}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
                                }
                            }
                        }
                    }
                    if (pred.positions.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("位置预测", fontWeight = FontWeight.Bold)
                                pred.positions.forEach { pos ->
                                    Text("${pos.positionName}：${pos.topNumbers.joinToString(" ") { "${it.number}" }}")
                                }
                            }
                        }
                    }
                }
            }
            AnalysisTab.FREQ -> {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("号码出现频率 Top20", fontWeight = FontWeight.Bold)
                        analysis.numberFreq.forEach {
                            Text("${it.label} · ${it.count} 次 · ${(it.rate * 100).roundToInt()}%")
                            LinearProgressIndicator(progress = { it.rate.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            AnalysisTab.SUM -> {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("和值分布", fontWeight = FontWeight.Bold)
                        Text("均值 ${"%.1f".format(analysis.sumAvg)} · 区间 ${analysis.sumMin}~${analysis.sumMax}")
                        analysis.sumBuckets.forEach {
                            Text("${it.range} · ${it.count} · ${(it.rate * 100).roundToInt()}%")
                            LinearProgressIndicator(progress = { it.rate.toFloat() }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            AnalysisTab.BS -> {
                listOf("大小" to analysis.freqDx, "单双" to analysis.freqDs, "组合" to analysis.freqCombo).forEach { (title, list) ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(title, fontWeight = FontWeight.Bold)
                            list.forEach {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(it.label)
                                    Text("${it.count}（${(it.rate * 100).roundToInt()}%）")
                                }
                                LinearProgressIndicator(progress = { it.rate.toFloat() }, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
                Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("最近走势", fontWeight = FontWeight.Bold)
                        Text("大小：" + analysis.recentDx.joinToString(" "))
                        Text("单双：" + analysis.recentDs.joinToString(" "))
                    }
                }
            }
            AnalysisTab.PERIOD -> {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("时段分布", fontWeight = FontWeight.Bold)
                        analysis.periodStats.forEach { p ->
                            val bigRate = if (p.total == 0) 0 else p.dxBig * 100 / p.total
                            val oddRate = if (p.total == 0) 0 else p.dsOdd * 100 / p.total
                            Text("${p.name}：n=${p.total} 大$bigRate% 单$oddRate%")
                        }
                    }
                }
            }
            AnalysisTab.LUZHU -> {
                Text("大小路珠", fontWeight = FontWeight.Bold)
                LuzhuRow(analysis.luzhuDx)
                Spacer(Modifier.height(12.dp))
                Text("单双路珠", fontWeight = FontWeight.Bold)
                LuzhuRow(analysis.luzhuDs)
            }
            AnalysisTab.MANUAL -> {
                Text("手动标记（选择后切换到「手动标记」算法生效）", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                ManualBlock("大小", listOf("大", "小"), marks["大小"]?.direction) { vm.setManualMark("大小", it) }
                ManualBlock("单双", listOf("单", "双"), marks["单双"]?.direction) { vm.setManualMark("单双", it) }
                ManualBlock("组合", listOf("大单", "大双", "小单", "小双"), marks["组合"]?.direction) { vm.setManualMark("组合", it) }
                Spacer(Modifier.height(8.dp))
                FilterChip(selected = false, onClick = { vm.clearManualMarks() }, label = { Text("清除本彩种手动标记") })
                Spacer(Modifier.height(8.dp))
                FilterChip(
                    selected = algo == AlgoMode.MANUAL,
                    onClick = { vm.selectAlgo(AlgoMode.MANUAL) },
                    label = { Text("启用手动标记算法") }
                )
            }
        }
    }
}

@Composable
private fun ManualBlock(title: String, options: List<String>, selected: String?, onPick: (String) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                options.forEach { o ->
                    FilterChip(selected = selected == o, onClick = { onPick(o) }, label = { Text(o) })
                }
            }
        }
    }
}

@Composable
private fun LuzhuRow(cols: List<com.caifenxi.app.domain.model.LuzhuColumn>) {
    Row(
        Modifier
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        cols.forEach { c ->
            val color = when (c.value) {
                "大", "单", "大单", "小单" -> Color(0xFFC62828)
                else -> Color(0xFF1565C0)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .width(18.dp)
                        .height((12 + c.height * 10).coerceAtMost(80).dp)
                        .background(color, RoundedCornerShape(3.dp))
                )
                Text(c.value.take(1), fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun DirBlock(title: String, dir: String, score: Double, detail: String) {
    val accent = if (dir.contains("大") || dir.contains("单")) Color(0xFFC62828) else Color(0xFF1565C0)
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("$title  ")
            Box(Modifier.background(accent, RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text(dir, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(Modifier.weight(1f))
            Text("${(score * 100).roundToInt()}%")
        }
        LinearProgressIndicator(progress = { score.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
        if (detail.isNotBlank()) Text(detail, style = MaterialTheme.typography.labelSmall)
    }
}
