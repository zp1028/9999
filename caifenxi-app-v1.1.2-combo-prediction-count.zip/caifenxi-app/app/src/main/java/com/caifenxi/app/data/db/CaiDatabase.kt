package com.caifenxi.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.dao.PlanDao
import com.caifenxi.app.data.db.entity.PlanPredictionEntity
import com.caifenxi.app.data.db.entity.PlanRuntimeEntity
import com.caifenxi.app.data.db.entity.DrawEntity

@Database(
    entities = [DrawEntity::class, PlanRuntimeEntity::class, PlanPredictionEntity::class],
    version = 2,
    exportSchema = false
)
abstract class CaiDatabase : RoomDatabase() {
    abstract fun drawDao(): DrawDao
    abstract fun planDao(): PlanDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS plan_runtime (planId TEXT NOT NULL PRIMARY KEY, weight REAL NOT NULL, score REAL NOT NULL, sampleCount INTEGER NOT NULL, hitCount INTEGER NOT NULL, consecutiveMiss INTEGER NOT NULL, maxHitStreak INTEGER NOT NULL, maxMissStreak INTEGER NOT NULL, recentHitRate REAL NOT NULL, midHitRate REAL NOT NULL, longHitRate REAL NOT NULL, stability REAL NOT NULL, baselineEdge REAL NOT NULL, confidence REAL NOT NULL, status TEXT NOT NULL, lastPrediction TEXT, lastTargetIssue TEXT, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS plan_predictions (planId TEXT NOT NULL, lotteryKey TEXT NOT NULL, targetIssue TEXT NOT NULL, cutoffIssue TEXT NOT NULL, output TEXT NOT NULL, scoreAtPredict REAL NOT NULL, weightAtPredict REAL NOT NULL, settled INTEGER NOT NULL, hit INTEGER, settledAt INTEGER, planName TEXT NOT NULL, category TEXT NOT NULL, createdAt INTEGER NOT NULL, PRIMARY KEY(planId, lotteryKey, targetIssue))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_plan_predictions_lotteryKey_targetIssue ON plan_predictions(lotteryKey, targetIssue)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_plan_predictions_planId_targetIssue ON plan_predictions(planId, targetIssue)")
            }
        }
        @Volatile private var instance: CaiDatabase? = null

        fun getInstance(context: Context): CaiDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CaiDatabase::class.java,
                    "caifenxi.db"
                ).addMigrations(MIGRATION_1_2).build().also { instance = it }
            }
        }
    }
}
