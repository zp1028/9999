package com.caifenxi.app.domain.engine

import com.caifenxi.app.domain.model.DirectionPrediction
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryType
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** 快乐8组合优化：先方向，再候选号码，再结构约束；仅作为统计实验，不是中奖概率。 */
object CombinationEngine {
    fun generate(history: List<DrawRecord>, lotteryType: LotteryType, dx: DirectionPrediction?, ds: DirectionPrediction?, count: Int): List<List<Int>> {
        if (lotteryType != LotteryType.LUCK20 || history.isEmpty()) return emptyList()
        val recent = history.takeLast(min(100, history.size))
        val freq = (1..80).associateWith { n -> recent.count { n in it.numbers }.toDouble() }.toMutableMap()
        val hot = recent.takeLast(min(20, recent.size))
        val cold = recent.takeLast(min(50, recent.size))
        (1..80).forEach { n -> freq[n] = freq.getValue(n) + hot.count { n in it.numbers } * 0.9 + cold.count { n in it.numbers } * 0.3 }
        val candidates = freq.entries.sortedByDescending { it.value }.take(40).map { it.key }
        val wantBig = dx?.direction == "大"
        val wantOdd = ds?.direction == "单"
        val scored = candidates.sortedByDescending { n ->
            val big = n > 40
            val odd = n % 2 == 1
            freq.getValue(n) * (1.0 + if (big == wantBig) 0.12 else -0.06) * (1.0 + if (odd == wantOdd) 0.10 else -0.04)
        }
        val result = mutableListOf<List<Int>>()
        for (seed in 0 until count.coerceIn(1, 20)) {
            val pick = mutableListOf<Int>()
            var cursor = seed
            while (pick.size < 20 && cursor < scored.size * 3) {
                val n = scored[(cursor * 7 + seed * 3) % scored.size]
                if (n !in pick && structureOk(pick + n)) pick += n
                cursor++
            }
            if (pick.size == 20) result += pick.sorted()
        }
        return result.distinct()
    }

    private fun structureOk(pick: List<Int>): Boolean {
        if (pick.size < 4) return true
        val big = pick.count { it > 40 }
        val odd = pick.count { it % 2 == 1 }
        val zones = (0..3).map { z -> pick.count { it in (z * 20 + 1)..(z * 20 + 20) } }
        return big in 7..13 && odd in 7..13 && zones.all { it in 3..7 }
    }
}
