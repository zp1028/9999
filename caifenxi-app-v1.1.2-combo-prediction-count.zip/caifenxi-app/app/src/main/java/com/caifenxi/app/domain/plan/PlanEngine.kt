package com.caifenxi.app.domain.plan

import com.caifenxi.app.data.db.dao.PlanDao
import com.caifenxi.app.data.db.entity.PlanPredictionEntity
import com.caifenxi.app.data.db.entity.PlanRuntimeEntity
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanStatus
import com.caifenxi.app.domain.model.ScoreWeights
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * PLAN-ENGINE-V1：固定40计划池 + 滚动回测 + 持久化运行时 + 动态权重 + 加权共识。
 * 所有结算均严格使用 targetIssue 之前的数据，避免未来数据泄漏。
 */
class PlanEngine(private val dao: PlanDao) {
    private val careerStats = mutableMapOf<String, PlanRuntime>()
    private var activePlans: List<PlanDefinition> = emptyList()
    private var loaded = false

    suspend fun initialize() {
        if (loaded) return
        careerStats.clear()
        dao.getAllRuntimes().forEach { careerStats[it.planId] = it.toDomain() }
        PlanPool.ALL.forEach { def -> careerStats.putIfAbsent(def.planId, PlanRuntime(def.planId)) }
        loaded = true
    }

    fun getActivePlans(): List<PlanDefinition> = activePlans

    fun getRuntimes(): List<Pair<PlanDefinition, PlanRuntime>> =
        PlanPool.ALL.map { it to (careerStats[it.planId] ?: PlanRuntime(it.planId)) }
            .sortedWith(compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.score }
                .thenByDescending { it.second.sampleCount })

    fun getCareerLeaderboard(): List<Pair<PlanDefinition, PlanRuntime>> = getRuntimes()

    fun generatePlansForIssue(targetIssue: String, count: Int = 40, force: Boolean = false): List<PlanDefinition> {
        if (!force && activePlans.isNotEmpty()) return activePlans
        // 计划ID固定；count只控制本期参与数量，不创造随机计划。
        activePlans = PlanPool.ALL.sortedWith(
            compareByDescending<PlanDefinition> { careerStats[it.planId]?.status == PlanStatus.PROMOTED }
                .thenByDescending { careerStats[it.planId]?.score ?: 50.0 }
                .thenBy { it.planId }
        ).take(count.coerceIn(4, PlanPool.ALL.size))
        return activePlans
    }

    suspend fun backtest(history: List<DrawRecord>, prefs: UserPrefs, minWarm: Int = 30) {
        initialize()
        if (history.size <= minWarm) return
        // 从历史头开始滚动，每个 (planId,targetIssue) 只能结算一次。
        for (i in minWarm until history.size) {
            val actual = history[i]
            val cutoff = history.subList(0, i)
            generatePlansForIssue(actual.issue, PlanPool.ALL.size, force = true)
            val preds = predictAll(cutoff, prefs, actual.issue, cutoff.last().issue, persist = true)
            preds.forEach { rec ->
                if (rec.settled) return@forEach
                val hit = evaluateHit(rec, actual)
                val changed = dao.settlePrediction(rec.planId, rec.lotteryKey, rec.targetIssue, hit, System.currentTimeMillis())
            }
        }
        refreshAllRuntimes()
    }

    suspend fun predictForNext(history: List<DrawRecord>, prefs: UserPrefs, targetIssue: String, cutoffIssue: String): List<PlanPredictionRecord> {
        initialize()
        generatePlansForIssue(targetIssue, PlanPool.ALL.size)
        return predictAll(history, prefs, targetIssue, cutoffIssue, persist = true)
    }

    suspend fun clearCareer() {
        careerStats.clear()
        dao.clearRuntimes()
        dao.clearPredictions()
        activePlans = emptyList()
        loaded = true
        PlanPool.ALL.forEach { careerStats[it.planId] = PlanRuntime(it.planId) }
    }

    suspend fun loadPersistedPredictions(lotteryKey: String, limit: Int = 1000): List<PlanPredictionRecord> =
        dao.getPredictions(lotteryKey, limit).map { it.toDomain() }

    fun consensus(lotteryKey: String, targetIssue: String, preds: List<PlanPredictionRecord>): List<ModelConsensus> {
        return listOf("大小", "单双", "组合", "区间").mapNotNull { cat ->
            val list = preds.filter { it.category == cat && (PlanPool.ALL.find { d -> d.planId == it.planId }?.participateConsensus == true) }
            if (list.isEmpty()) return@mapNotNull null
            val weights = linkedMapOf<String, Double>()
            var total = 0.0
            list.forEach { rec ->
                val rt = careerStats[rec.planId] ?: return@forEach
                if (rt.status == PlanStatus.ELIMINATED) return@forEach
                val w = rt.weight.coerceIn(0.05, 1.25)
                weights[rec.output] = (weights[rec.output] ?: 0.0) + w
                total += w
            }
            if (total <= 0) return@mapNotNull null
            val normalized = weights.mapValues { it.value / total }
            val lead = normalized.maxByOrNull { it.value } ?: return@mapNotNull null
            val second = normalized.values.sortedDescending().getOrNull(1) ?: 0.0
            ModelConsensus(
                lotteryKey = lotteryKey,
                targetIssue = targetIssue,
                category = cat,
                leadingDirection = lead.key,
                supportRatio = lead.value,
                disagreement = if (lead.value == 0.0) 1.0 else second / lead.value,
                participatingPlans = list.size,
                detail = normalized
            )
        }
    }

    private suspend fun predictAll(
        history: List<DrawRecord>, prefs: UserPrefs, targetIssue: String, cutoffIssue: String, persist: Boolean
    ): List<PlanPredictionRecord> {
        val plans = if (activePlans.isNotEmpty()) activePlans else generatePlansForIssue(targetIssue, PlanPool.ALL.size)
        return plans.mapNotNull { def ->
            val out = runPlan(def, history, prefs) ?: return@mapNotNull null
            val rt = careerStats[def.planId] ?: PlanRuntime(def.planId)
            val rec = PlanPredictionRecord(
                planId = def.planId,
                lotteryKey = history.lastOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                output = out,
                scoreAtPredict = rt.score,
                weightAtPredict = rt.weight,
                planName = def.planName,
                category = def.category
            )
            if (persist && rec.lotteryKey.isNotBlank()) {
                dao.insertPrediction(rec.toEntity())
            }
            rec.copy(settled = dao.findPrediction(rec.planId, rec.lotteryKey, rec.targetIssue)?.settled ?: false)
        }
    }

    private fun runPlan(def: PlanDefinition, history: List<DrawRecord>, prefs: UserPrefs): String? {
        if (history.isEmpty()) return null
        val slice = history.takeLast(def.window.coerceIn(5, history.size))
        return when (def.category) {
            "大小" -> directionPredict(slice.mapNotNull { it.dx }, def.algorithm, prefs, listOf("大", "小"))
            "单双" -> directionPredict(slice.mapNotNull { it.ds }, def.algorithm, prefs, listOf("单", "双"))
            "组合" -> directionPredict(slice.mapNotNull { it.combo }, def.algorithm, prefs, listOf("大单", "大双", "小单", "小双"))
            "区间" -> zonePredict(slice, def.algorithm, prefs)
            "号码" -> topNumbers(slice, def.algorithm, def.window, prefs).joinToString(",")
            "结构" -> structurePredict(slice, def.algorithm)
            "AI" -> aiProxyPredict(slice, def.algorithm, prefs)
            else -> directionPredict(slice.mapNotNull { it.dx }, def.algorithm, prefs, listOf("大", "小"))
        }
    }

    private fun directionPredict(seq: List<String>, algo: String, prefs: UserPrefs, labels: List<String>): String? {
        if (seq.isEmpty()) return null
        val scores = labels.associateWith { 0.0 }.toMutableMap()
        when (algo) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble().coerceIn(0.05, 0.5)
                val ewma = labels.associateWith { 1.0 / labels.size }.toMutableMap()
                seq.forEach { x -> labels.forEach { l -> ewma[l] = alpha * (if (l == x) 1.0 else 0.0) + (1 - alpha) * ewma.getValue(l) } }
                labels.forEach { scores[it] = ewma.getValue(it) }
            }
            "MKV1" -> {
                val last = seq.last()
                val trans = labels.associateWith { 0.0 }.toMutableMap()
                var n = 0.0
                for (i in 1 until seq.size) if (seq[i - 1] == last) { trans[seq[i]] = trans.getValue(seq[i]) + 1; n++ }
                if (n > 0) labels.forEach { scores[it] = trans.getValue(it) / n }
                else labels.forEach { scores[it] = seq.count { x -> x == it }.toDouble() / seq.size }
            }
            "MSF" -> {
                val windows = listOf(10, 20, 50).filter { it <= seq.size }
                val weights = listOf(0.45, 0.35, 0.20)
                windows.forEachIndexed { idx, w ->
                    val s = seq.takeLast(w)
                    labels.forEach { scores[it] = scores.getValue(it) + s.count { x -> x == it }.toDouble() / s.size * weights[idx] }
                }
            }
            else -> labels.forEach { scores[it] = seq.count { x -> x == it }.toDouble() / seq.size }
        }
        return scores.maxByOrNull { it.value }?.key
    }

    private fun zonePredict(slice: List<DrawRecord>, algo: String, prefs: UserPrefs): String {
        val maxNumber = slice.flatMap { it.numbers }.maxOrNull() ?: 80
        val zones = if (maxNumber <= 10) listOf(1..3, 4..6, 7..10) else listOf(1..20, 21..40, 41..60, 61..80)
        val scores = DoubleArray(zones.size)
        val rows = if (algo == "MSF") listOf(10, 20, 50).filter { it <= slice.size } else listOf(min(slice.size, 40))
        rows.forEachIndexed { idx, w ->
            val part = slice.takeLast(w)
            val wt = if (algo == "MSF") listOf(0.45, 0.35, 0.20).getOrElse(idx) { 0.1 } else 1.0
            part.forEach { r -> zones.forEachIndexed { zi, z -> scores[zi] += r.numbers.count { it in z } * wt / part.size } }
        }
        return zones[scores.indices.maxByOrNull { scores[it] } ?: 0].let { "${it.first}-${it.last}" }
    }

    private fun topNumbers(slice: List<DrawRecord>, algo: String, window: Int, prefs: UserPrefs): List<Int> {
        val range = if (slice.firstOrNull()?.numbers?.maxOrNull()?.let { it > 10 } == true) 1..80 else 1..10
        val score = range.associateWith { 0.0 }.toMutableMap()
        val recent = slice.takeLast(window.coerceAtMost(slice.size))
        when (algo) {
            "OMIT" -> {
                range.forEach { n ->
                    val idx = recent.indexOfLast { n in it.numbers }
                    score[n] = if (idx < 0) recent.size.toDouble() else (recent.size - 1 - idx).toDouble()
                }
            }
            "CHOT" -> {
                val hot = recent.takeLast(min(20, recent.size))
                val cold = recent.takeLast(min(50, recent.size))
                range.forEach { n -> score[n] = hot.count { n in it.numbers } * 1.4 + cold.count { n in it.numbers } * 0.6 }
            }
            "EWMA" -> {
                val a = prefs.ewmaAlpha.toDouble().coerceIn(0.05, 0.5)
                val e = range.associateWith { 0.0 }.toMutableMap()
                recent.forEach { r -> range.forEach { n -> e[n] = a * (if (n in r.numbers) 1.0 else 0.0) + (1 - a) * e.getValue(n) } }
                range.forEach { score[it] = e.getValue(it) }
            }
            "MSF" -> {
                listOf(10, 20, 50, 100).forEachIndexed { idx, w ->
                    if (recent.isEmpty()) return@forEachIndexed
                    val part = recent.takeLast(min(w, recent.size)); val wt = listOf(0.35, 0.30, 0.20, 0.15)[idx]
                    range.forEach { n -> score[n] = score.getValue(n) + part.count { n in it.numbers }.toDouble() / part.size * wt }
                }
            }
            else -> range.forEach { n -> score[n] = recent.count { n in it.numbers }.toDouble() }
        }
        return score.entries.sortedByDescending { it.value }.take(if (range.last == 80) 20 else range.last).map { it.key }
    }

    private fun structurePredict(slice: List<DrawRecord>, algo: String): String {
        if (slice.isEmpty()) return "稳定"
        return when (algo) {
            "STRUCT" -> {
                val last = slice.last().numbers.sorted()
                val consecutive = last.zipWithNext().count { it.second == it.first + 1 }
                if (consecutive >= 3) "连号偏强" else if (last.distinct().size < last.size) "重号偏强" else "分散"
            }
            "CHOT" -> {
                val recent = slice.takeLast(min(20, slice.size))
                val unique = recent.flatMap { it.numbers }.groupingBy { it }.eachCount()
                if ((unique.values.maxOrNull() ?: 0) >= 6) "冷热偏热" else "冷热均衡"
            }
            "MSF" -> {
                val avgRepeat = slice.zipWithNext().map { a -> a.first.numbers.intersect(a.second.numbers.toSet()).size }.average()
                if (avgRepeat >= 6) "重号偏强" else if (avgRepeat <= 3) "重号偏弱" else "重号中性"
            }
            "FREQ" -> {
                val oddRate = slice.flatMap { it.numbers }.count { it % 2 == 1 }.toDouble() / slice.flatMap { it.numbers }.size.coerceAtLeast(1)
                if (oddRate >= 0.55) "偏单" else if (oddRate <= 0.45) "偏双" else "奇偶均衡"
            }
            else -> "结构中性"
        }
    }

    /** 无外部API时的可复现AI代理：只做统计解释，不声称是真实AI概率。 */
    private fun aiProxyPredict(slice: List<DrawRecord>, algo: String, prefs: UserPrefs): String {
        return when (algo) {
            "STRUCT", "ANOM" -> structurePredict(slice, "MSF")
            "FILTER" -> topNumbers(slice, "CHOT", 50, prefs).take(20).joinToString(",")
            "EVAL" -> directionPredict(slice.mapNotNull { it.dx }, "MSF", prefs, listOf("大", "小")) ?: "大"
            else -> directionPredict(slice.mapNotNull { it.dx }, "MSF", prefs, listOf("大", "小")) ?: "大"
        }
    }

    private fun evaluateHit(rec: PlanPredictionRecord, actual: DrawRecord): Boolean {
        val def = PlanPool.ALL.find { it.planId == rec.planId } ?: return false
        return when (def.hitCriteria) {
            PlanHitCriteria.DIRECTION_MATCH -> rec.output == when (def.category) {
                "大小" -> actual.dx
                "单双" -> actual.ds
                "组合" -> actual.combo
                "AI" -> actual.dx ?: actual.ds
                else -> actual.dx
            }
            PlanHitCriteria.ZONE_DISTANCE -> {
                val predicted = rec.output.substringBefore('-').toIntOrNull() ?: return false
                val maxNumber = actual.numbers.maxOrNull() ?: 80
                val zones = if (maxNumber <= 10) listOf(1..3, 4..6, 7..10) else listOf(1..20, 21..40, 41..60, 61..80)
                val actualCounts = zones.map { z -> actual.numbers.count { it in z } }
                val actualZone = actualCounts.indices.maxByOrNull { actualCounts[it] } ?: 0
                predicted == zones[actualZone].first
            }
            PlanHitCriteria.TOP20_HIT -> {
                val picks = rec.output.split(',').mapNotNull { it.toIntOrNull() }.toSet()
                val hits = actual.numbers.count { it in picks }
                hits >= max(1, actual.numbers.size / 4)
            }
            PlanHitCriteria.STRUCTURE_RANGE -> {
                val predicted = rec.output
                when {
                    predicted.contains("连号") -> actual.numbers.sorted().zipWithNext().count { it.second == it.first + 1 } >= 2
                    predicted.contains("重号") -> actual.numbers.distinct().size < actual.numbers.size || actual.numbers.size <= 10
                    predicted.contains("偏单") -> actual.numbers.count { it % 2 == 1 } >= (actual.numbers.size * 0.55).toInt()
                    predicted.contains("偏双") -> actual.numbers.count { it % 2 == 0 } >= (actual.numbers.size * 0.55).toInt()
                    else -> true
                }
            }
        }
    }

    private suspend fun updateRuntimeFromHistory(planId: String) {
        val rows = dao.getPredictionsForPlan(planId)
        if (rows.isEmpty()) return
        val settled = rows.filter { it.settled && it.hit != null }
        if (settled.isEmpty()) return
        val hits = settled.count { it.hit == true }
        val sample = settled.size
        val missStreak = settled.asReversed().takeWhile { it.hit == false }.size
        val maxHit = maxStreak(settled.map { it.hit == true })
        val maxMiss = maxStreak(settled.map { it.hit == false })
        val recent = rate(settled.takeLast(20))
        val mid = rate(settled.takeLast(50))
        val long = rate(settled.takeLast(200))
        val stability = stability(settled.takeLast(100).map { if (it.hit == true) 1.0 else 0.0 })
        val def = PlanPool.ALL.find { it.planId == planId } ?: return
        val baseline = def.baselineValue
        val edge = long - baseline
        val confidence = (1.0 - kotlin.math.exp(-sample / 80.0)).coerceIn(0.0, 1.0)
        val raw = (recent * ScoreWeights.RECENT + mid * ScoreWeights.MID + long * ScoreWeights.LONG + stability * ScoreWeights.STABILITY_WEIGHT + (maxHit.toDouble() / max(1, sample)) * ScoreWeights.STREAK_WEIGHT - (missStreak.toDouble() / max(1, sample)) * ScoreWeights.MISS_RISK)
        val score = ((raw * 100.0) + edge * 100.0 * ScoreWeights.BASELINE_BEAT).coerceIn(0.0, 100.0) * (0.65 + 0.35 * confidence)
        val targetWeight = (0.65 + edge * 2.0 + (recent - long) * 0.6).coerceIn(0.25, 1.25)
        val previous = careerStats[planId]?.weight ?: 1.0
        val weight = targetWeight.coerceIn(previous - 0.15, previous + 0.15).coerceIn(0.25, 1.25)
        val status = when {
            sample < 20 -> PlanStatus.HOLD
            sample >= 100 && edge < -0.08 && long < 0.42 -> PlanStatus.ELIMINATED
            missStreak >= 12 && sample >= 30 -> PlanStatus.DEMOTED
            sample >= 50 && score >= 65 && edge > 0 -> PlanStatus.PROMOTED
            else -> PlanStatus.ACTIVE
        }
        val rt = PlanRuntime(planId, weight, score, sample, hits, missStreak, maxHit, maxMiss, recent, mid, long, stability, edge, confidence, status, settled.last().output, settled.last().targetIssue)
        careerStats[planId] = rt
        dao.upsertRuntime(rt.toEntity())
    }

    private suspend fun refreshAllRuntimes() {
        PlanPool.ALL.forEach { updateRuntimeFromHistory(it.planId) }
    }

    private fun rate(rows: List<PlanPredictionEntity>): Double = if (rows.isEmpty()) 0.0 else rows.count { it.hit == true }.toDouble() / rows.size
    private fun stability(values: List<Double>): Double {
        if (values.size < 2) return 0.5
        val mean = values.average()
        val variance = values.map { (it - mean) * (it - mean) }.average()
        return (1.0 - min(variance * 4.0, 1.0)).coerceIn(0.0, 1.0)
    }
    private fun maxStreak(values: List<Boolean>): Int { var best = 0; var cur = 0; values.forEach { if (it) { cur++; best = max(best, cur) } else cur = 0 }; return best }

    private fun PlanRuntimeEntity.toDomain() = PlanRuntime(planId, weight, score, sampleCount, hitCount, consecutiveMiss, maxHitStreak, maxMissStreak, recentHitRate, midHitRate, longHitRate, stability, baselineEdge, confidence, runCatching { PlanStatus.valueOf(status) }.getOrDefault(PlanStatus.ACTIVE), lastPrediction, lastTargetIssue)
    private fun PlanRuntime.toEntity() = PlanRuntimeEntity(planId, weight, score, sampleCount, hitCount, consecutiveMiss, maxHitStreak, maxMissStreak, recentHitRate, midHitRate, longHitRate, stability, baselineEdge, confidence, status.name, lastPrediction, lastTargetIssue)
    private fun PlanPredictionRecord.toEntity() = PlanPredictionEntity(planId, lotteryKey, targetIssue, cutoffIssue, output, scoreAtPredict, weightAtPredict, settled, hit, settledAt, planName, category)
    private fun PlanPredictionEntity.toDomain() = PlanPredictionRecord(planId, lotteryKey, targetIssue, cutoffIssue, output, scoreAtPredict, weightAtPredict, settled, hit, settledAt, planName, category)

}
