package com.caifenxi.app.data.db.entity

import androidx.room.Entity

@Entity(tableName = "plan_runtime")
data class PlanRuntimeEntity(
    @androidx.room.PrimaryKey val planId: String,
    val weight: Double = 1.0,
    val score: Double = 50.0,
    val sampleCount: Int = 0,
    val hitCount: Int = 0,
    val consecutiveMiss: Int = 0,
    val maxHitStreak: Int = 0,
    val maxMissStreak: Int = 0,
    val recentHitRate: Double = 0.0,
    val midHitRate: Double = 0.0,
    val longHitRate: Double = 0.0,
    val stability: Double = 0.0,
    val baselineEdge: Double = 0.0,
    val confidence: Double = 0.0,
    val status: String = "ACTIVE",
    val lastPrediction: String? = null,
    val lastTargetIssue: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
