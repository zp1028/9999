package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.PlanPredictionEntity
import com.caifenxi.app.data.db.entity.PlanRuntimeEntity

@Dao
interface PlanDao {
    @Query("SELECT * FROM plan_runtime")
    suspend fun getAllRuntimes(): List<PlanRuntimeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRuntime(entity: PlanRuntimeEntity)

    @Query("SELECT * FROM plan_predictions WHERE planId = :planId AND lotteryKey = :lotteryKey AND targetIssue = :targetIssue LIMIT 1")
    suspend fun findPrediction(planId: String, lotteryKey: String, targetIssue: String): PlanPredictionEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPrediction(entity: PlanPredictionEntity): Long

    @Query("UPDATE plan_predictions SET settled = 1, hit = :hit, settledAt = :settledAt WHERE planId = :planId AND lotteryKey = :lotteryKey AND targetIssue = :targetIssue AND settled = 0")
    suspend fun settlePrediction(planId: String, lotteryKey: String, targetIssue: String, hit: Boolean, settledAt: Long): Int

    @Query("SELECT * FROM plan_predictions WHERE planId = :planId ORDER BY targetIssue ASC, createdAt ASC")
    suspend fun getPredictionsForPlan(planId: String): List<PlanPredictionEntity>

    @Query("SELECT * FROM plan_predictions WHERE lotteryKey = :lotteryKey ORDER BY targetIssue DESC, createdAt DESC LIMIT :limit")
    suspend fun getPredictions(lotteryKey: String, limit: Int): List<PlanPredictionEntity>

    @Query("DELETE FROM plan_runtime")
    suspend fun clearRuntimes()

    @Query("DELETE FROM plan_predictions")
    suspend fun clearPredictions()
}
