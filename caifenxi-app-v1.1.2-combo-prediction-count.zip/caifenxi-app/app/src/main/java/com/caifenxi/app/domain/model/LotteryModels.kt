package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 彩种类型（与原 JS adapters 对齐）
 */
enum class LotteryType {
    /** PK拾 / 飞艇 / 赛车：10 个位置，号码 1-10 */
    PKS,
    /** 快乐8 / 幸运20：20 个号码，范围 1-80 */
    LUCK20
}

/**
 * 彩种配置（对应原 LOTTERY_CATALOG）
 */
@Serializable
data class LotteryConfig(
    val key: String,          // API code，如 "10037"
    val name: String,         // 显示名
    val type: LotteryType,
    val code: Int
) {
    companion object {
        val CATALOG = listOf(
            LotteryConfig("10037", "极速飞艇", LotteryType.PKS, 10037),
            LotteryConfig("10035", "极速赛车", LotteryType.PKS, 10035),
            LotteryConfig("10012", "幸运飞艇", LotteryType.PKS, 10012),
            LotteryConfig("10058", "PK拾(10058)", LotteryType.PKS, 10058),
            LotteryConfig("10057", "澳洲幸运10", LotteryType.PKS, 10057),
            LotteryConfig("10054", "极速快乐8", LotteryType.LUCK20, 10054),
            LotteryConfig("10047", "幸运20(10047)", LotteryType.LUCK20, 10047),
        )

        fun findByKey(key: String): LotteryConfig? = CATALOG.find { it.key == key }
    }
}

/**
 * 单期开奖记录（统一模型，兼容 PKS 与 LUCK20）
 */
@Serializable
data class DrawRecord(
    val lotteryKey: String,       // 彩种 key
    val issue: String,            // 期号
    val drawTime: String,         // 开奖时间原文
    val numbers: List<Int>,       // 开奖号码列表
    val sum: Int? = null,         // 和值（LUCK20 常用）
    val dx: String? = null,       // 大小："大" / "小"
    val ds: String? = null,       // 单双："单" / "双"
    val combo: String? = null,    // 组合："大单" 等
    val extra: Int? = null,       // 附加号（若有）
    val nextIssue: String? = null // 下期期号（API 有时会给）
) {
    /** 位置名（PKS 用） */
    fun positionName(index: Int): String = when (index) {
        0 -> "冠军"
        1 -> "亚军"
        else -> "第${index + 1}"
    }

    fun numberAt(index: Int): Int? = numbers.getOrNull(index)
}

/**
 * 大小 / 单双 方向
 */
enum class Direction(val label: String) {
    BIG("大"),
    SMALL("小"),
    ODD("单"),
    EVEN("双");

    companion object {
        fun fromDx(s: String?): Direction? = when (s) {
            "大" -> BIG
            "小" -> SMALL
            else -> null
        }
        fun fromDs(s: String?): Direction? = when (s) {
            "单" -> ODD
            "双" -> EVEN
            else -> null
        }
    }
}

/**
 * 预测类别
 */
enum class PredictCategory {
    DX,      // 大小
    DS,      // 单双
    COMBO,   // 组合（大小+单双）
    ZONE,    // 区间
    NUMBER,  // 号码
    POSITION,// 位置（PKS）
    STRUCT   // 结构
}

/**
 * 单次预测结果（方向类）
 */
@Serializable
data class DirectionPrediction(
    val category: PredictCategory,
    val direction: String,          // "大"/"小"/"单"/"双"/"大单" 等
    val score: Double = 0.0,        // 模型支持度 / 相对评分（非真实概率）
    val algo: String = "",          // 算法名
    val detail: String = ""
)

/**
 * 号码评分预测（热力图用）
 */
@Serializable
data class NumberScore(
    val number: Int,
    val score: Double,
    val rank: Int = 0
)

/**
 * 位置预测（每个位置 TopN 号码）
 */
@Serializable
data class PositionPrediction(
    val positionIndex: Int,
    val positionName: String,
    val topNumbers: List<NumberScore>
)

/**
 * 一轮完整预测快照（对应一期，可冻结）
 */
@Serializable
data class PredictionSnapshot(
    val lotteryKey: String,
    val targetIssue: String,        // 预测的目标期号
    val cutoffIssue: String,        // 截止已开奖期号
    val createdAt: Long,
    val frozen: Boolean = false,
    val dx: DirectionPrediction? = null,
    val ds: DirectionPrediction? = null,
    val combo: DirectionPrediction? = null,
    /** 组合预测多候选（按支持度排序） */
    val comboList: List<DirectionPrediction> = emptyList(),
    val numberScores: List<NumberScore> = emptyList(),
    /** 快乐8统计组合候选；不是中奖概率。 */
    val combinations: List<List<Int>> = emptyList(),
    val positions: List<PositionPrediction> = emptyList(),
    val algoTag: String = "experience"
)

/**
 * 用户偏好（对应原 UserPrefs）
 */
@Serializable
data class UserPrefs(
    val predictionWindow: Int = 100,
    val positionTopN: Int = 3,
    val zuheTopN: Int = 3,
    /** 快乐8首选组合结果输出数量，可独立于大小单双组合候选数量设置 */
    val comboPredCount: Int = 2,
    /** 每期计划池随机生成数量 */
    val planPoolCount: Int = 40,
    val ewmaEnabled: Boolean = true,
    val ewmaAlpha: Float = 0.25f,
    val ewmaWeightTemperature: Float = 0.08f,
    val trendBoostEnabled: Boolean = true,
    val sensitivityMode: String = "balanced", // simple / balanced / pro
    val momentumStrength: Float = 0.5f,
    val antiHerdStrength: Float = 0.3f,
    val streakDecayEnabled: Boolean = true,
    val autoRefresh: Boolean = true,
    val darkMode: Boolean = false,
    val themeMode: String = "system", // system | light | dark
    val predFreeze: Boolean = true,
    val selectedLotteryKey: String = "10037",
    val aiApiKey: String = "",
    val currentAlgo: String = "experience"
)

/**
 * API 配置
 */
object ApiConfig {
    const val PRIMARY_BASE = "https://api.api16868.com"
    const val ALT_BASE = "https://api.api68.com"
    const val TIMEOUT_MS = 10_000L
    const val RETRIES = 2
}
