package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Path
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.OmissionStat
import com.caifenxi.app.domain.model.TransferCell
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.AlgoSelector
import kotlin.math.roundToInt

private enum class AnalysisTab(val label: String) {
    PRED("预测"), FREQ("频率"), SUM("和值"), BS("大小单双"), TREND("走势"), PERIOD("时段"), LUZHU("路珠"), MANUAL("手动")
}

@Composable
fun PredictScreen(vm: MainViewModel) {
    var tab by remember { mutableStateOf(AnalysisTab.PRED) }
    val pred = vm.prediction.value
    val algo = vm.currentAlgo.value
    val compare = vm.algoCompare.value
    val analysis = vm.analysis.value
    val marks = vm.manualMarks.value

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("分析", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AnalysisTab.entries.forEach { t ->
                FilterChip(
                    selected = tab == t,
                    onClick = { tab = t },
                    label = { Text(t.label, fontSize = 12.sp) }
                )
            }
        }

        when (tab) {
            AnalysisTab.PRED -> {
                Text("算法模式", fontWeight = FontWeight.SemiBold)
                AlgoSelector(selected = algo, onSelect = { vm.selectAlgo(it) })
                Spacer(Modifier.height(8.dp))
                if (pred == null) {
                    Text("请先在首页加载数据")
                } else {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            val algoLabel = buildString {
                                append(AlgoMode.fromId(pred.algoTag).label)
                                if (pred.resolvedAlgo.isNotBlank() && pred.resolvedAlgo != pred.algoTag) {
                                    append(" · 实际采用 ${AlgoMode.fromId(pred.resolvedAlgo).label}")
                                }
                            }
                            Text("目标第 ${pred.targetIssue} 期 · $algoLabel", fontWeight = FontWeight.Bold)
                            Text("截止 ${pred.cutoffIssue}", style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(12.dp))
                            pred.dx?.let { DirBlock("大小", it.direction, it.score, it.detail) }
                            Spacer(Modifier.height(8.dp))
                            pred.ds?.let { DirBlock("单双", it.direction, it.score, it.detail) }
                            Spacer(Modifier.height(8.dp))
                            pred.combo?.let { DirBlock("组合首选", it.direction, it.score, it.detail) }
                            if (pred.comboList.size > 1) {
                                Spacer(Modifier.height(8.dp))
                                Text("组合候选 Top${pred.comboList.size}", fontWeight = FontWeight.SemiBold)
                                pred.comboList.forEachIndexed { i, c ->
                                    Text("${i + 1}. ${c.direction}  ${(c.score * 100).toInt()}%")
                                }
                            }
                        }
                    }
                    if (algo == AlgoMode.COMPARE && compare.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Text("多算法对比", fontWeight = FontWeight.Bold)
                        compare.forEach { (cat, list) ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(cat, fontWeight = FontWeight.SemiBold)
                                    list.forEach { r ->
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(r.algoLabel)
                                            Text("${r.direction} ${(r.score * 100).roundToInt()}% ${r.confidence}")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (pred.numberScores.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("号码热度 Top", fontWeight = FontWeight.Bold)
                                pred.numberScores.take(15).chunked(5).forEach { row ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        row.forEach { ns ->
                                            Box(
                                                Modifier.weight(1f).background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(8.dp)).padding(8.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("${ns.number}\n${(ns.score * 100).roundToInt()}%", fontSize = 11.sp)
                                            }
                                        }
                                        repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
                                    }
                                    Spacer(Modifier.height(4.dp))
                                }
                            }
                        }
                    }
                    if (pred.positions.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("位置预测", fontWeight = FontWeight.Bold)
                                pred.positions.forEach { pos ->
                                    Text("${pos.positionName}：${pos.topNumbers.joinToString(" ") { "${it.number}" }}")
                                }
                            }
                        }
                    }
                }
            }
            AnalysisTab.FREQ -> {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("号码出现频率 Top20", fontWeight = FontWeight.Bold)
                        analysis.numberFreq.forEach {
                            Text("${it.label} · ${it.count} 次 · ${(it.rate * 100).roundToInt()}%")
                            LinearProgressIndicator(progress = { it.rate.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            AnalysisTab.SUM -> {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("和值分布", fontWeight = FontWeight.Bold)
                        Text("均值 ${"%.1f".format(analysis.sumAvg)} · 区间 ${analysis.sumMin}~${analysis.sumMax}")
                        analysis.sumBuckets.forEach {
                            Text("${it.range} · ${it.count} · ${(it.rate * 100).roundToInt()}%")
                            LinearProgressIndicator(progress = { it.rate.toFloat() }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            AnalysisTab.BS -> {
                listOf("大小" to analysis.freqDx, "单双" to analysis.freqDs, "组合" to analysis.freqCombo).forEach { (title, list) ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(title, fontWeight = FontWeight.Bold)
                            list.forEach {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(it.label)
                                    Text("${it.count}（${(it.rate * 100).roundToInt()}%）")
                                }
                                LinearProgressIndicator(progress = { it.rate.toFloat() }, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
                Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("最近走势", fontWeight = FontWeight.Bold)
                        Text("大小：" + analysis.recentDx.joinToString(" "))
                        Text("单双：" + analysis.recentDs.joinToString(" "))
                    }
                }
            }
            AnalysisTab.TREND -> {
                TrendAnalysis(analysis)
            }
            AnalysisTab.PERIOD -> {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("时段分布", fontWeight = FontWeight.Bold)
                        analysis.periodStats.forEach { p ->
                            val bigRate = if (p.total == 0) 0 else p.dxBig * 100 / p.total
                            val oddRate = if (p.total == 0) 0 else p.dsOdd * 100 / p.total
                            Text("${p.name}：n=${p.total} 大$bigRate% 单$oddRate%")
                        }
                    }
                }
            }
            AnalysisTab.LUZHU -> {
                Text("大小路珠", fontWeight = FontWeight.Bold)
                LuzhuRow(analysis.luzhuDx)
                Spacer(Modifier.height(12.dp))
                Text("单双路珠", fontWeight = FontWeight.Bold)
                LuzhuRow(analysis.luzhuDs)
            }
            AnalysisTab.MANUAL -> {
                Text("手动标记（选择后切换到「手动标记」算法生效）", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                ManualBlock("大小", listOf("大", "小"), marks["大小"]?.direction) { vm.setManualMark("大小", it) }
                ManualBlock("单双", listOf("单", "双"), marks["单双"]?.direction) { vm.setManualMark("单双", it) }
                ManualBlock("组合", listOf("大单", "大双", "小单", "小双"), marks["组合"]?.direction) { vm.setManualMark("组合", it) }
                Spacer(Modifier.height(8.dp))
                FilterChip(selected = false, onClick = { vm.clearManualMarks() }, label = { Text("清除本彩种手动标记") })
                Spacer(Modifier.height(8.dp))
                FilterChip(
                    selected = algo == AlgoMode.MANUAL,
                    onClick = { vm.selectAlgo(AlgoMode.MANUAL) },
                    label = { Text("启用手动标记算法") }
                )
            }
        }
    }
}

@Composable
private fun TrendAnalysis(analysis: com.caifenxi.app.domain.model.AnalysisBundle) {
    if (analysis.sumTrend.isEmpty() && analysis.dxTrend.isEmpty() && analysis.numberOmissions.isEmpty()) {
        Text("暂无足够数据")
        return
    }
    TrendCard("和值趋势", analysis.sumTrend, Color(0xFFC62828))
    TrendCard("大小走势", analysis.dxTrend, Color(0xFF1565C0))
    TrendCard("单双走势", analysis.dsTrend, Color(0xFF2E7D32))
    OmissionCard("号码遗漏", analysis.numberOmissions)
    OmissionCard("组合遗漏", analysis.comboOmissions)
    HeatmapCard(analysis)
    TransferCard("大小转移矩阵", analysis.dxTransfers)
    TransferCard("单双转移矩阵", analysis.dsTransfers)
}

@Composable
private fun TrendCard(title: String, points: List<com.caifenxi.app.domain.model.TrendPoint>, color: Color) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (points.isEmpty()) {
                Text("暂无数据", style = MaterialTheme.typography.bodySmall)
            } else {
                val min = points.minOf { it.value }
                val max = points.maxOf { it.value }
                Canvas(Modifier.fillMaxWidth().height(130.dp).padding(top = 8.dp)) {
                    val span = (max - min).coerceAtLeast(1).toFloat()
                    val step = if (points.size == 1) size.width else size.width / (points.size - 1)
                    val path = Path()
                    points.forEachIndexed { index, point ->
                        val x = if (points.size == 1) size.width / 2f else index * step
                        val y = size.height - ((point.value - min) / span) * size.height
                        if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, color = color, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f))
                }
                Text("${points.first().issue} ~ ${points.last().issue}", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun OmissionCard(title: String, rows: List<OmissionStat>) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (rows.isEmpty()) Text("暂无数据")
            rows.sortedByDescending { it.current }.take(20).forEach {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(it.label)
                    Text("当前${it.current} · 均值${"%.1f".format(it.average)} · 最大${it.maximum}")
                }
            }
        }
    }
}

@Composable
private fun HeatmapCard(analysis: com.caifenxi.app.domain.model.AnalysisBundle) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text("号码热力图", fontWeight = FontWeight.Bold)
            if (analysis.numberHeatmap.isEmpty()) {
                Text("暂无数据")
            } else {
                analysis.numberHeatmap.takeLast(12).forEach { row ->
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(row.issue, modifier = Modifier.width(70.dp), style = MaterialTheme.typography.labelSmall)
                        analysis.heatmapNumbers.forEach { number ->
                            val present = number in row.numbers
                            Box(
                                Modifier.width(22.dp).height(22.dp).background(
                                    if (present) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    RoundedCornerShape(3.dp)
                                ), contentAlignment = Alignment.Center
                            ) { Text(number.toString(), fontSize = 8.sp, color = if (present) Color.White else Color.Unspecified) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TransferCard(title: String, cells: List<TransferCell>) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (cells.isEmpty()) Text("暂无足够数据")
            cells.forEach { cell ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${cell.from} → ${cell.to}")
                    Text("${cell.count} 次 · ${(cell.rate * 100).roundToInt()}%")
                }
            }
        }
    }
}

@Composable
private fun ManualBlock(title: String, options: List<String>, selected: String?, onPick: (String) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                options.forEach { o ->
                    FilterChip(selected = selected == o, onClick = { onPick(o) }, label = { Text(o) })
                }
            }
        }
    }
}

@Composable
private fun LuzhuRow(cols: List<com.caifenxi.app.domain.model.LuzhuColumn>) {
    Row(
        Modifier
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        cols.forEach { c ->
            val color = when (c.value) {
                "大", "单", "大单", "小单" -> Color(0xFFC62828)
                else -> Color(0xFF1565C0)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .width(18.dp)
                        .height((12 + c.height * 10).coerceAtMost(80).dp)
                        .background(color, RoundedCornerShape(3.dp))
                )
                Text(c.value.take(1), fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun DirBlock(title: String, dir: String, score: Double, detail: String) {
    val accent = if (dir.contains("大") || dir.contains("单")) Color(0xFFC62828) else Color(0xFF1565C0)
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("$title  ")
            Box(Modifier.background(accent, RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text(dir, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(Modifier.weight(1f))
            Text("${(score * 100).roundToInt()}%")
        }
        LinearProgressIndicator(progress = { score.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
        if (detail.isNotBlank()) Text(detail, style = MaterialTheme.typography.labelSmall)
    }
}
