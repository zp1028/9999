package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.StatEntity

@Dao
interface StatDao {
    @Query("SELECT * FROM stats WHERE lotteryKey = :lotteryKey ORDER BY createdAt DESC")
    suspend fun getByLottery(lotteryKey: String): List<StatEntity>

    @Query("SELECT * FROM stats ORDER BY lotteryKey ASC, createdAt DESC")
    suspend fun getAll(): List<StatEntity>

    @Query("SELECT * FROM stats WHERE lotteryKey = :lotteryKey AND category = :category ORDER BY createdAt DESC")
    suspend fun getByLotteryAndCategory(lotteryKey: String, category: String): List<StatEntity>

    /** 预测历史分页：分类为空表示全部；位置表示所有位置预测。 */
    @Query("SELECT * FROM stats WHERE lotteryKey = :lotteryKey AND (:category = '' OR category = :category) AND (:result = '' OR result = :result) ORDER BY createdAt DESC, id DESC LIMIT :limit OFFSET :offset")
    suspend fun getPage(lotteryKey: String, category: String, result: String, limit: Int, offset: Int): List<StatEntity>

    @Query("SELECT * FROM stats WHERE lotteryKey = :lotteryKey AND category LIKE '位置-%' AND (:result = '' OR result = :result) ORDER BY createdAt DESC, id DESC LIMIT :limit OFFSET :offset")
    suspend fun getPositionPage(lotteryKey: String, result: String, limit: Int, offset: Int): List<StatEntity>

    @Query("SELECT COUNT(*) FROM stats WHERE lotteryKey = :lotteryKey AND (:category = '' OR category = :category) AND (:result = '' OR result = :result)")
    suspend fun countByCategory(lotteryKey: String, category: String, result: String): Int

    @Query("SELECT COUNT(*) FROM stats WHERE lotteryKey = :lotteryKey AND category LIKE '位置-%' AND (:result = '' OR result = :result)")
    suspend fun countPositions(lotteryKey: String, result: String): Int

    @Query("SELECT * FROM stats WHERE lotteryKey = :lotteryKey AND issue = :issue AND category = :category LIMIT 1")
    suspend fun getByLotteryIssueCategory(lotteryKey: String, issue: String, category: String): StatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(stat: StatEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(stats: List<StatEntity>)

    @Query("DELETE FROM stats WHERE lotteryKey = :lotteryKey")
    suspend fun deleteByLottery(lotteryKey: String)

    @Query("DELETE FROM stats")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM stats WHERE lotteryKey = :lotteryKey")
    suspend fun countByLottery(lotteryKey: String): Int
}
