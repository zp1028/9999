package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.caifenxi.app.domain.model.ConsensusRecord
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Entity(
    tableName = "consensus",
    indices = [
        Index(value = ["lotteryKey", "targetIssue", "category"], unique = true),
        Index(value = ["lotteryKey", "createdAt"])
    ]
)
@Serializable
data class ConsensusEntity(
    @PrimaryKey val id: String,
    val lotteryKey: String,
    val targetIssue: String,
    val category: String,
    val leadingDirection: String,
    val candidatesJson: String,
    val supportRatio: Double,
    val participatingPlans: Int,
    val actual: String?,
    val result: String,
    val createdAt: Long,
    val settledAt: Long?
) {
    fun toDomain(): ConsensusRecord = ConsensusRecord(
        id = id,
        lotteryKey = lotteryKey,
        targetIssue = targetIssue,
        category = category,
        leadingDirection = leadingDirection,
        candidates = Json.decodeFromString<List<String>>(candidatesJson),
        supportRatio = supportRatio,
        participatingPlans = participatingPlans,
        actual = actual,
        result = result,
        createdAt = createdAt,
        settledAt = settledAt
    )

    companion object {
        fun fromDomain(record: ConsensusRecord): ConsensusEntity = ConsensusEntity(
            id = record.id,
            lotteryKey = record.lotteryKey,
            targetIssue = record.targetIssue,
            category = record.category,
            leadingDirection = record.leadingDirection,
            candidatesJson = Json.encodeToString<List<String>>(record.candidates),
            supportRatio = record.supportRatio,
            participatingPlans = record.participatingPlans,
            actual = record.actual,
            result = record.result,
            createdAt = record.createdAt,
            settledAt = record.settledAt
        )
    }
}
