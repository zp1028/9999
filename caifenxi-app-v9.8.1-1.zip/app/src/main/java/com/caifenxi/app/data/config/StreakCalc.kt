package com.caifenxi.app.data.config

import com.caifenxi.app.domain.model.CategoryStats

/**
 * 连对连错与两期/三期滚动窗口的通用计算。
 * 「两期对」= 连续两期窗口内至少对 1 次；「两期错」= 两期全错。三期同理。
 */
internal object StreakCalc {

    /** 稳定时间序：按期号升序（批量结算时 settledAt 相同，不能作为排序依据） */
    fun <T> chronoOf(
        rows: List<T>,
        issue: (T) -> String,
        createdAt: (T) -> Long,
        id: (T) -> String
    ): List<T> =
        rows.sortedWith(compareBy({ issue(it).toLongOrNull() ?: 0L }, { createdAt(it) }, { id(it) }))

    /**
     * 连对连错指标。
     * @param results 按时间升序的对/错结果序列
     * @return Triple(当前带符号连击：连对为正、连错为负, 最长连对, 最长连错)
     */
    fun streaksOf(results: List<String>): Triple<Int, Int, Int> {
        var maxH = 0; var maxM = 0; var curH = 0; var curM = 0
        results.forEach { r ->
            if (r == "对") { curH++; curM = 0; maxH = maxOf(maxH, curH) }
            else { curM++; curH = 0; maxM = maxOf(maxM, curM) }
        }
        var recent = 0
        if (results.isNotEmpty()) {
            val last = results.last()
            for (i in results.indices.reversed()) {
                if (results[i] == last) recent++ else break
            }
            if (last == "错") recent = -recent
        }
        return Triple(recent, maxH, maxM)
    }

    /**
     * 滚动窗口对错率：窗口内至少 1 次对 = 对窗口；全错 = 错窗口。
     * @return Triple(窗口数, 至少一次对的窗口数, 全错窗口数)
     */
    fun windowRates(results: List<String>, size: Int): Triple<Int, Int, Int> {
        var total = 0; var hit = 0
        if (results.size >= size) {
            for (i in 0..results.size - size) {
                total++
                var hasHit = false
                for (j in i until i + size) {
                    if (results[j] == "对") { hasHit = true; break }
                }
                if (hasHit) hit++
            }
        }
        return Triple(total, hit, total - hit)
    }

    /** 由已结算的结果序列构建完整分类统计（连击 + 两期/三期窗口率） */
    fun buildCategoryStats(results: List<String>): CategoryStats {
        val hit = results.count { it == "对" }
        val miss = results.count { it == "错" }
        val (recent, maxH, maxM) = streaksOf(results)
        val (w2, w2Hit, w2Miss) = windowRates(results, 2)
        val (w3, w3Hit, w3Miss) = windowRates(results, 3)
        return CategoryStats(
            total = results.size,
            hit = hit,
            miss = miss,
            recentStreak = recent,
            maxHitStreak = maxH,
            maxMissStreak = maxM,
            twoWindows = w2,
            twoHitWindows = w2Hit,
            twoMissWindows = w2Miss,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3,
            threeHitWindows = w3Hit,
            threeMissWindows = w3Miss,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }
}
