package com.caifenxi.app.util

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * 应用内滚动运行日志。
 * 错误/失败带问题编号 E###,便于对照排查。
 */
object RuntimeLog {

    enum class Level { INFO, WARN, ERROR }

    data class Entry(
        val id: Int,
        val code: String,
        val level: Level,
        val message: String,
        val timeMs: Long = System.currentTimeMillis()
    ) {
        val timeText: String
            get() = fmt.format(Date(timeMs))
    }

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val seq = AtomicInteger(0)
    private const val MAX = 120

    val entries: SnapshotStateList<Entry> = mutableStateListOf()

    fun info(code: String, message: String) = append(Level.INFO, code, message)

    fun warn(code: String, message: String) = append(Level.WARN, code, message)

    fun error(code: String, message: String) = append(Level.ERROR, code, message)

    /** 捕获异常并写 ERROR 日志 */
    fun exception(code: String, prefix: String, t: Throwable) {
        val msg = t.message?.take(120) ?: t.javaClass.simpleName
        error(code, "$prefix: $msg")
    }

    @Synchronized
    private fun append(level: Level, code: String, message: String) {
        val id = seq.incrementAndGet()
        entries.add(0, Entry(id = id, code = code, level = level, message = message))
        while (entries.size > MAX) {
            entries.removeAt(entries.lastIndex)
        }
    }

    fun clear() {
        entries.clear()
    }
}
