package com.caifenxi.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.caifenxi.app.ui.CaiFenXiApp
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.theme.CaiTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()
        setContent {
            val mode = viewModel.prefs.value.themeMode
            val dark = when (mode) {
                "light" -> false
                "dark" -> true
                else -> isSystemInDarkTheme() || viewModel.prefs.value.darkMode
            }
            CaiTheme(darkTheme = dark) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CaiFenXiApp(viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (viewModel.prefs.value.floatingEnabled && !android.provider.Settings.canDrawOverlays(this)) {
            viewModel.updatePrefs { it.copy(floatingEnabled = false) }
        }
        viewModel.onForeground()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
