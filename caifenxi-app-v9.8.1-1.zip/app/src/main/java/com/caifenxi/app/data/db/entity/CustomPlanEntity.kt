package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.caifenxi.app.domain.model.CustomPlan
import kotlinx.serialization.Serializable

@Entity(
    tableName = "custom_plans",
    indices = [Index(value = ["lotteryKey", "enabled"])]
)
@Serializable
data class CustomPlanEntity(
    @PrimaryKey val planId: String,
    val lotteryKey: String,
    val planName: String,
    val category: String,
    val algorithm: String,
    val window: Int,
    val outputFormat: String,
    val hitCriteria: String,
    val enabled: Boolean,
    val participateConsensus: Boolean,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomain(): CustomPlan = CustomPlan(
        planId = planId,
        lotteryKey = lotteryKey,
        planName = planName,
        category = category,
        algorithm = algorithm,
        window = window,
        outputFormat = outputFormat,
        hitCriteria = hitCriteria,
        enabled = enabled,
        participateConsensus = participateConsensus,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    companion object {
        fun fromDomain(plan: CustomPlan): CustomPlanEntity = CustomPlanEntity(
            planId = plan.planId,
            lotteryKey = plan.lotteryKey,
            planName = plan.planName,
            category = plan.category,
            algorithm = plan.algorithm,
            window = plan.window,
            outputFormat = plan.outputFormat,
            hitCriteria = plan.hitCriteria,
            enabled = plan.enabled,
            participateConsensus = plan.participateConsensus,
            createdAt = plan.createdAt,
            updatedAt = plan.updatedAt
        )
    }
}
