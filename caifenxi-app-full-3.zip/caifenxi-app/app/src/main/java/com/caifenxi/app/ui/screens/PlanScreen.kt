package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun PlanScreen(vm: MainViewModel) {
    val rows = vm.planRows.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value
    val allHist = vm.planHistory.value
    var expandedId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16, bottom = CaiTokens.ScreenBottom),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
    ) {
        item {
            Text("计划大厅", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("点击展开：当期预测号码/方向 + 历史预测与对错")
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                text = if (vm.backtestRunning.value) "生成/回测中…" else "重新随机生成本期计划并回测",
                onClick = { vm.runBacktest() },
                enabled = !vm.backtestRunning.value,
                modifier = Modifier.fillMaxWidth()
            )
            CaptionMuted("计划数 ${vm.prefs.value.planPoolCount}" + (pred?.let { " · 目标 ${it.targetIssue}" } ?: ""))
        }

        items(consensus) { c ->
            GlobalCard {
                Text("${c.category} 共识 → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                Text("支持 ${(c.supportRatio * 100).roundToInt()}% · ${c.participatingPlans} 计划")
            }
        }


        item {
            Spacer(Modifier.height(CaiTokens.S8))
            Text("共识预测战绩", fontWeight = FontWeight.Bold)
            CaptionMuted("计划池加权共识的对错历史 · 仅本页查看")
        }
        item {
            val cs = vm.consensusStats.value
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                        Text("${cs.hit + cs.miss}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        CaptionMuted("已结算")
                    }
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                        Text("${cs.hit}", fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color(0xFF2E7D32))
                        CaptionMuted("对")
                    }
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                        Text("${cs.miss}", fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color(0xFFC62828))
                        CaptionMuted("错")
                    }
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                        Text(
                            if (cs.hit + cs.miss == 0) "-" else "${(cs.hitRate * 100).roundToInt()}%",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        CaptionMuted("对错率")
                    }
                }
                if (cs.pending > 0) CaptionMuted("待开 ${cs.pending} 条")
                cs.byCategory.forEach { (cat, pair) ->
                    val (h, m) = pair
                    val rate = if (h + m == 0) 0 else (h * 100.0 / (h + m)).roundToInt()
                    Text("$cat：对 $h / 错 $m · 命中率 $rate%")
                }
                Spacer(Modifier.height(CaiTokens.S8))
                PrimaryButton("清空共识战绩", onClick = { vm.clearConsensusStats() }, ghost = true)
            }
        }
        item {
            Text("共识预测记录", fontWeight = FontWeight.SemiBold)
            CaptionMuted("当期共识与历史对错")
        }
        items(vm.consensusRecords.value.take(40), key = { it.id }) { r ->
            val color = when (r.result) {
                "对" -> androidx.compose.ui.graphics.Color(0xFF2E7D32)
                "错" -> androidx.compose.ui.graphics.Color(0xFFC62828)
                else -> androidx.compose.ui.graphics.Color(0xFFF9A825)
            }
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("第 ${r.targetIssue} 期 · ${r.category}", fontWeight = FontWeight.Bold)
                        Text(
                            "共识「${r.leadingDirection}」" + (r.actual?.let { " → 开奖「$it」" } ?: " · 待开奖")
                        )
                        CaptionMuted(
                            "支持度 ${(r.supportRatio * 100).roundToInt()}% · ${r.participatingPlans} 个计划参与" +
                                if (r.candidates.size > 1) " · 命中任一即对" else ""
                        )
                    }
                    Text(r.result, fontWeight = FontWeight.Bold, color = color)
                }
            }
        }

        item { Text("本期计划", fontWeight = FontWeight.Bold) }


        if (rows.isEmpty()) {
            item { GlobalCard { Text("暂无计划，请先首页加载。") } }
        } else {
            items(rows, key = { it.first.planId }) { (def, rt) ->
                val hist = allHist.filter { it.planId == def.planId }
                val current = hist.filter { !it.settled }.ifEmpty {
                    hist.filter { it.targetIssue == pred?.targetIssue }
                }
                PlanCard(
                    def = def,
                    rt = rt,
                    currentPreds = current,
                    history = hist.filter { it.settled }.take(15),
                    expanded = expandedId == def.planId,
                    onToggle = {
                        expandedId = if (expandedId == def.planId) null else def.planId
                        if (expandedId == def.planId) vm.loadPlanDetail(def.planId)
                    }
                )
            }
        }
        item { Spacer(Modifier.height(CaiTokens.S24)) }
    }
}

@Composable
private fun PlanCard(
    def: PlanDefinition,
    rt: PlanRuntime,
    currentPreds: List<PlanPredictionRecord>,
    history: List<PlanPredictionRecord>,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    GlobalCard(onClick = onToggle) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(def.planName, fontWeight = FontWeight.Bold)
                CaptionMuted("${def.category} · ${def.algorithm} · 窗${def.window}")
                // 列表上直接显示当期预测
                val curOut = currentPreds.firstOrNull()?.output ?: rt.lastPrediction
                if (curOut != null) {
                    Text(
                        "当期预测：${curOut}" + (currentPreds.firstOrNull()?.targetIssue?.let { " → 第${it}期" } ?: ""),
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text(rt.hitRatePercent, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                CaptionMuted(if (expanded) "收起" else "展开")
            }
        }
        if (rt.sampleCount > 0) {
            LinearProgressIndicator(
                progress = { rt.hitRate.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                color = MaterialTheme.colorScheme.secondary
            )
        }

        AnimatedVisibility(visible = expanded) {
            Column(Modifier.padding(top = CaiTokens.S12)) {
                Text("计划参数", fontWeight = FontWeight.SemiBold)
                DetailLine("ID", def.planId)
                DetailLine("分类/算法/窗口", "${def.category} / ${def.algorithm} / ${def.window}")
                DetailLine("命中规则", def.hitCriteria.name)

                Spacer(Modifier.height(CaiTokens.S8))
                Text("当期预测", fontWeight = FontWeight.SemiBold)
                if (currentPreds.isEmpty() && rt.lastPrediction == null) {
                    CaptionMuted("暂无当期预测")
                } else {
                    currentPreds.ifEmpty {
                        listOf(
                            PlanPredictionRecord(
                                planId = def.planId,
                                lotteryKey = "",
                                targetIssue = rt.lastTargetIssue ?: "-",
                                cutoffIssue = "-",
                                output = rt.lastPrediction ?: "-",
                                scoreAtPredict = rt.score,
                                weightAtPredict = rt.weight,
                                planName = def.planName,
                                category = def.category
                            )
                        )
                    }.forEach { rec ->
                        GlobalCard {
                            Text("目标第 ${rec.targetIssue} 期", fontWeight = FontWeight.Medium)
                            Text(
                                "预测结果：${rec.output}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            CaptionMuted("评分时 ${"%.0f".format(rec.scoreAtPredict)} · 权重 ${"%.2f".format(rec.weightAtPredict)}")
                        }
                    }
                }

                Spacer(Modifier.height(CaiTokens.S8))
                Text("历史预测与结果", fontWeight = FontWeight.SemiBold)
                CaptionMuted("对 ${rt.hitCount} / 共 ${rt.sampleCount} · 成功率 ${rt.hitRatePercent}")
                if (history.isEmpty()) {
                    CaptionMuted("尚无已结算历史（开奖后自动写入）")
                } else {
                    history.forEach { rec ->
                        val tag = when (rec.hit) {
                            true -> "对"
                            false -> "错"
                            null -> "—"
                        }
                        val color = when (rec.hit) {
                            true -> androidx.compose.ui.graphics.Color(0xFF2E7D32)
                            false -> androidx.compose.ui.graphics.Color(0xFFC62828)
                            null -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("第${rec.targetIssue}期 预测「${rec.output}」")
                            Text(tag, fontWeight = FontWeight.Bold, color = color)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
