package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.AccentTag
import com.caifenxi.app.ui.components.AlgoSelector
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.ScreenContainer
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel) {
    val lottery = vm.currentLottery.value
    val latest = vm.latest.value
    val history = vm.history.value
    val loading = vm.loading.value
    val error = vm.errorMessage.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value
    val summary = vm.statsSummary.value
    val algo = vm.currentAlgo.value
    val countdown = vm.countdownText.value
    val nextIssue = vm.nextIssueText.value

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
            .padding(bottom = CaiTokens.ScreenBottom)
    ) {
        Text("彩析", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        CaptionMuted("统计可视化与策略回测 · 非中奖保证")
        Spacer(Modifier.height(CaiTokens.S12))

        GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
            Text(
                "开奖为随机事件，历史无法预测未来。「共识/评分」是模型加权支持度与相对评分，不是真实中奖概率。请理性对待。",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }

        Spacer(Modifier.height(CaiTokens.S16))

        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            TextField(
                value = lottery.name,
                onValueChange = {},
                readOnly = true,
                label = { Text("当前彩种") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                shape = RoundedCornerShape(CaiTokens.RadiusIcon),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedIndicatorColor = MaterialTheme.colorScheme.secondary
                )
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                LotteryConfig.CATALOG.forEach { item ->
                    DropdownMenuItem(
                        text = { Text(item.name) },
                        onClick = {
                            vm.selectLottery(item)
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S8))
        SectionTitle("算法模式")
        AlgoSelector(selected = algo, onSelect = { vm.selectAlgo(it) })
        CaptionMuted(vm.statusText.value)

        if (loading && history.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(CaiTokens.S32), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.secondary)
            }
            return
        }

        if (error != null && history.isEmpty()) {
            GlobalCard {
                Text("数据加载失败", fontWeight = FontWeight.Bold)
                Text(error, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(CaiTokens.S8))
                PrimaryButton("重新加载", onClick = { vm.loadData() })
            }
            Spacer(Modifier.height(CaiTokens.S12))
        }

        Spacer(Modifier.height(CaiTokens.S12))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
            MiniStat("期数", "${history.size}", Modifier.weight(1f))
            MiniStat("最新", latest?.issue ?: "-", Modifier.weight(1f))
            MiniStat(
                "命中率",
                if (summary.hit + summary.miss == 0) "-" else "${(summary.hitRate * 100).roundToInt()}%",
                Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(CaiTokens.S16))
        GlobalCard(containerColor = MaterialTheme.colorScheme.surface) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("下期 第 $nextIssue 期", fontWeight = FontWeight.SemiBold)
                Text(
                    countdown,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                CaptionMuted("估算倒计时 · 以接口时间校准更佳")
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))
        GlobalCard {
            Text("实时开奖", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(CaiTokens.S8))
            if (latest == null) {
                CaptionMuted("暂无数据")
            } else {
                Text("第 ${latest.issue} 期", fontWeight = FontWeight.Medium)
                CaptionMuted(latest.drawTime.take(19))
                Spacer(Modifier.height(CaiTokens.S8))
                NumberBalls(latest.numbers)
                Spacer(Modifier.height(CaiTokens.S8))
                Row(horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                    latest.dx?.let { AccentTag(it) }
                    latest.ds?.let { AccentTag(it) }
                    latest.combo?.let { AccentTag(it) }
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))
        GlobalCard(containerColor = MaterialTheme.colorScheme.primaryContainer) {
            Text("策略驾驶舱", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(CaiTokens.S8))
            if (pred == null) {
                CaptionMuted("加载后显示预测与共识")
            } else {
                CaptionMuted("目标 ${pred.targetIssue} · ${AlgoMode.fromId(pred.algoTag).label}")
                Spacer(Modifier.height(CaiTokens.S8))
                pred.dx?.let { PredLine("大小", it.direction, it.score) }
                pred.ds?.let { PredLine("单双", it.direction, it.score) }
                pred.combo?.let { PredLine("组合", it.direction, it.score) }
                consensus.forEach { c ->
                    Spacer(Modifier.height(CaiTokens.S4))
                    Text(
                        "共识 ${c.category}→${c.leadingDirection} ${(c.supportRatio * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelMedium
                    )
                    LinearProgressIndicator(
                        progress = { c.supportRatio.toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))
        PrimaryButton("刷新数据与预测", onClick = { vm.loadData() }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("仅用缓存重算", onClick = { vm.loadData() }, ghost = true, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    GlobalCard(modifier = modifier) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            CaptionMuted(label)
        }
    }
}

@Composable
private fun PredLine(title: String, dir: String, score: Double) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$title  ", style = MaterialTheme.typography.bodyMedium)
        Text(dir, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.weight(1f))
        Text("${(score * 100).roundToInt()}%", style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun NumberBalls(nums: List<Int>) {
    Column(verticalArrangement = Arrangement.spacedBy(CaiTokens.S4)) {
        nums.chunked(10).forEach { row ->
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(CaiTokens.S4)
            ) {
                row.forEach { n ->
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(CaiTokens.RadiusIcon))
                            .background(MaterialTheme.colorScheme.secondary)
                            .padding(horizontal = CaiTokens.S8, vertical = CaiTokens.S4)
                    ) {
                        Text(
                            n.toString().padStart(2, '0'),
                            color = MaterialTheme.colorScheme.onSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
