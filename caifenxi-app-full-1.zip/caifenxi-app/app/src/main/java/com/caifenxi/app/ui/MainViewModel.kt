package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.AnalysisEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.engine.StatsEngine
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.AlgoResult
import com.caifenxi.app.domain.model.AnalysisBundle
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LabRow
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.ManualMark
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.StatRecord
import com.caifenxi.app.domain.model.StatsSummary
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.domain.plan.PlanEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val repo get() = app.drawRepository
    private val configStore get() = app.configStore
    private val statStore get() = app.statStore
    private val manualStore get() = app.manualStore
    private val planEngine = PlanEngine()

    val prefs = mutableStateOf(configStore.loadPrefs())
    val currentLottery = mutableStateOf(
        LotteryConfig.findByKey(prefs.value.selectedLotteryKey) ?: LotteryConfig.CATALOG.first()
    )
    val currentAlgo = mutableStateOf(AlgoMode.fromId(prefs.value.currentAlgo))
    val history = mutableStateOf<List<DrawRecord>>(emptyList())
    val latest = mutableStateOf<DrawRecord?>(null)
    val loading = mutableStateOf(false)
    val errorMessage = mutableStateOf<String?>(null)
    val prediction = mutableStateOf<PredictionSnapshot?>(null)
    val algoCompare = mutableStateOf<Map<String, List<AlgoResult>>>(emptyMap())
    val consensus = mutableStateOf<List<ModelConsensus>>(emptyList())
    val planRows = mutableStateOf<List<Pair<PlanDefinition, PlanRuntime>>>(emptyList())
    val backtestRunning = mutableStateOf(false)
    val statusText = mutableStateOf("")
    val statsSummary = mutableStateOf(StatsSummary())
    val statRecords = mutableStateOf<List<StatRecord>>(emptyList())
    val analysis = mutableStateOf(AnalysisBundle())
    val labRows = mutableStateOf<List<LabRow>>(emptyList())
    val planHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val selectedPlanHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val manualMarks = mutableStateOf<Map<String, ManualMark>>(emptyMap())
    val countdownText = mutableStateOf("--:--")
    val nextIssueText = mutableStateOf("-")

    private var refreshJob: Job? = null
    private var countdownJob: Job? = null

    init {
        loadData()
        startAutoRefreshIfNeeded()
        startCountdown()
    }

    fun selectLottery(config: LotteryConfig) {
        currentLottery.value = config
        val p = prefs.value.copy(selectedLotteryKey = config.key)
        prefs.value = p
        configStore.savePrefs(p)
        loadData()
    }

    fun selectAlgo(mode: AlgoMode) {
        currentAlgo.value = mode
        val p = prefs.value.copy(currentAlgo = mode.id)
        prefs.value = p
        configStore.savePrefs(p)
        viewModelScope.launch {
            if (history.value.isNotEmpty()) runPredictAndPlans(history.value, forceAlgo = mode)
        }
    }

    fun setManualMark(category: String, direction: String) {
        val m = ManualMark(currentLottery.value.key, category, direction)
        manualStore.save(m)
        manualMarks.value = manualStore.load(currentLottery.value.key)
        if (currentAlgo.value == AlgoMode.MANUAL) {
            viewModelScope.launch {
                if (history.value.isNotEmpty()) runPredictAndPlans(history.value, forceAlgo = AlgoMode.MANUAL)
            }
        }
    }

    fun clearManualMarks() {
        manualStore.clear(currentLottery.value.key)
        manualMarks.value = emptyMap()
    }

    fun updatePrefs(transform: (UserPrefs) -> UserPrefs) {
        val p = transform(prefs.value)
        prefs.value = p
        configStore.savePrefs(p)
        if (p.autoRefresh) startAutoRefreshIfNeeded() else stopAutoRefresh()
    }

    fun loadData() {
        viewModelScope.launch {
            loading.value = true
            errorMessage.value = null
            statusText.value = "拉取开奖…"
            try {
                // 先展示缓存
                val cached = repo.getLocalHistory(currentLottery.value.key)
                if (cached.isNotEmpty()) {
                    history.value = cached
                    latest.value = cached.lastOrNull()
                    statusText.value = "缓存 ${cached.size} 期 · 同步中…"
                }
                val (rows, source) = repo.fetchAndCacheHistory(currentLottery.value, days = 5)
                history.value = rows
                latest.value = rows.lastOrNull()
                rows.forEach {
                    StatsEngine.settleWithDraw(statStore, currentLottery.value.key, it)
                    planEngine.settlePendingWithDraw(it)
                }
                refreshStats()
                manualMarks.value = manualStore.load(currentLottery.value.key)
                statusText.value = "分析与预测…（$source）"
                runPredictAndPlans(rows)
                rebuildAnalysis(rows)
                statusText.value = "就绪 · ${rows.size} 期 · $source"
                updateNextIssue(rows)
            } catch (e: Exception) {
                errorMessage.value = e.message ?: "数据加载失败"
                statusText.value = "失败"
            } finally {
                loading.value = false
            }
        }
    }

    fun runBacktest() {
        viewModelScope.launch {
            val rows = history.value
            if (rows.size < 40) {
                errorMessage.value = "历史不足，至少约 40 期再回测"
                return@launch
            }
            backtestRunning.value = true
            statusText.value = "回测中…"
            try {
                withContext(Dispatchers.Default) {
                    planEngine.backtest(rows, prefs.value, minWarm = 30)
                }
                val target = PredictEngine.suggestNextIssue(rows.lastOrNull()?.issue)
                val cutoff = rows.last().issue
                // 强制为本期目标重新随机生成计划
                val preds = withContext(Dispatchers.Default) {
                    planEngine.generateRandomPlansForIssue(target, count = prefs.value.planPoolCount.coerceIn(4, 30), force = true)
                    planEngine.predictForNext(rows, prefs.value, target, cutoff)
                }
                planRows.value = planEngine.getRuntimes()
                planHistory.value = planEngine.getAllRecentPredictions(100)
                consensus.value = planEngine.consensus(currentLottery.value.key, target, preds)
                labRows.value = withContext(Dispatchers.Default) {
                    AnalysisEngine.labTable(rows, prefs.value)
                }
                statusText.value = "已随机生成 ${planRows.value.size} 条计划 · 回测完成"
            } catch (e: Exception) {
                errorMessage.value = e.message
            } finally {
                backtestRunning.value = false
            }
        }
    }

    fun loadPlanDetail(planId: String) {
        selectedPlanHistory.value = planEngine.getPredictionHistory(planId, 40)
    }

    fun clearStats() {
        statStore.clear(currentLottery.value.key)
        refreshStats()
    }

    fun backfillStats() {
        StatsEngine.backfillFromHistory(statStore, currentLottery.value.key, history.value)
        refreshStats()
    }

    private fun refreshStats() {
        val key = currentLottery.value.key
        statsSummary.value = statStore.summary(key)
        statRecords.value = statStore.loadAll(key).sortedByDescending { it.createdAt }
    }

    private suspend fun rebuildAnalysis(rows: List<DrawRecord>) {
        analysis.value = withContext(Dispatchers.Default) {
            AnalysisEngine.build(rows, prefs.value.predictionWindow)
        }
        labRows.value = withContext(Dispatchers.Default) {
            AnalysisEngine.labTable(rows, prefs.value)
        }
    }

    private suspend fun runPredictAndPlans(rows: List<DrawRecord>, forceAlgo: AlgoMode? = null) {
        if (rows.isEmpty()) return
        val cfg = currentLottery.value
        val mode = forceAlgo ?: currentAlgo.value
        val cutoff = rows.last().issue
        val target = rows.last().nextIssue?.takeIf { it.isNotBlank() }
            ?: PredictEngine.suggestNextIssue(cutoff)

        var snap = withContext(Dispatchers.Default) {
            PredictEngine.predict(rows, cfg.type, prefs.value, target, cutoff, mode)
        }
        // 手动标记覆盖
        if (mode == AlgoMode.MANUAL) {
            val marks = manualStore.load(cfg.key)
            snap = snap.copy(
                dx = marks["大小"]?.let { snap.dx?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.dx,
                ds = marks["单双"]?.let { snap.ds?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.ds,
                combo = marks["组合"]?.let { snap.combo?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.combo,
                algoTag = "manual"
            )
        }
        // 预测冻结：同目标期已有待开/已结算则不覆盖展示（仍允许算法切换 force）
        val freeze = prefs.value.predFreeze
        val existing = if (freeze) {
            statStore.loadAll(cfg.key).any {
                it.issue == target && it.algoId == mode.id && it.result != "待开"
            }
        } else false
        if (!existing || forceAlgo != null) {
            prediction.value = snap
        }

        if (mode != AlgoMode.COMPARE) {
            StatsEngine.recordPending(statStore, snap, mode.id)
            refreshStats()
        }

        algoCompare.value = withContext(Dispatchers.Default) {
            PredictEngine.compareAll(rows, prefs.value)
        }

        withContext(Dispatchers.Default) {
            if (rows.size >= 40) planEngine.backtest(rows, prefs.value, minWarm = 30)
            val preds = planEngine.predictForNext(rows, prefs.value, target, cutoff)
            consensus.value = planEngine.consensus(cfg.key, target, preds)
            planRows.value = planEngine.getRuntimes()
            planHistory.value = planEngine.getAllRecentPredictions(100)
        }
    }

    private fun updateNextIssue(rows: List<DrawRecord>) {
        val last = rows.lastOrNull() ?: return
        nextIssueText.value = last.nextIssue?.takeIf { it.isNotBlank() }
            ?: PredictEngine.suggestNextIssue(last.issue)
    }

    private fun startCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            while (isActive) {
                val last = latest.value
                val t = last?.drawTime
                if (t != null) {
                    try {
                        // 极速类约 75 秒一期，用上次开奖+75s 估算
                        val base = fmt.parse(t.take(19).replace('T', ' '))
                        if (base != null) {
                            val next = base.time + 75_000
                            val left = next - System.currentTimeMillis()
                            countdownText.value = if (left <= 0) "即将开奖" else {
                                val s = (left / 1000).toInt()
                                "%02d:%02d".format(s / 60, s % 60)
                            }
                        }
                    } catch (_: Exception) {
                        countdownText.value = "--:--"
                    }
                }
                delay(1000)
            }
        }
    }

    private fun startAutoRefreshIfNeeded() {
        stopAutoRefresh()
        if (!prefs.value.autoRefresh) return
        refreshJob = viewModelScope.launch {
            while (isActive) {
                delay(30_000)
                try {
                    val one = app.apiClient.fetchLatest(currentLottery.value)
                    if (one != null) {
                        val exists = history.value.any { it.issue == one.issue }
                        if (!exists) {
                            val merged = (history.value + one).distinctBy { it.issue }
                                .sortedBy { it.issue.toLongOrNull() ?: 0L }
                            history.value = merged
                            latest.value = one
                            StatsEngine.settleWithDraw(statStore, currentLottery.value.key, one)
                            planEngine.settlePendingWithDraw(one)
                            planHistory.value = planEngine.getAllRecentPredictions(100)
                            planRows.value = planEngine.getRuntimes()
                            refreshStats()
                            runPredictAndPlans(merged)
                            rebuildAnalysis(merged)
                            updateNextIssue(merged)
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun stopAutoRefresh() {
        refreshJob?.cancel()
        refreshJob = null
    }

    override fun onCleared() {
        stopAutoRefresh()
        countdownJob?.cancel()
        super.onCleared()
    }
}
