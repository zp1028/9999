package com.caifenxi.app.data.repository

import com.caifenxi.app.data.api.LotteryApiClient
import com.caifenxi.app.data.config.ConfigStore
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.entity.DrawEntity
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class DrawRepository(
    private val api: LotteryApiClient,
    private val drawDao: DrawDao,
    private val configStore: ConfigStore
) {
    private val json = Json { encodeDefaults = true }

    /** 仅本地缓存 */
    suspend fun getLocalHistory(key: String): List<DrawRecord> =
        drawDao.getByLottery(key).map { it.toDomain() }

    /**
     * 缓存优先：先返回本地，再尝试网络合并。
     * @return Pair(数据, 来源说明)
     */
    suspend fun fetchAndCacheHistory(
        config: LotteryConfig,
        days: Int = 3
    ): Pair<List<DrawRecord>, String> {
        val local = getLocalHistory(config.key)
        return try {
            val remote = api.fetchHistory(config, days)
            if (remote.isNotEmpty()) {
                drawDao.upsertAll(remote.map { it.toEntity() })
                val merged = drawDao.getByLottery(config.key).map { it.toDomain() }
                merged to if (local.isEmpty()) "网络" else "缓存+网络"
            } else {
                if (local.isNotEmpty()) local to "缓存（网络无新数据）"
                else emptyList<DrawRecord>() to "网络返回空"
            }
        } catch (e: Exception) {
            if (local.isNotEmpty()) local to "缓存（网络失败: ${e.message?.take(40)}）"
            else throw e
        }
    }

    private fun DrawRecord.toEntity() = DrawEntity(
        lotteryKey = lotteryKey,
        issue = issue,
        drawTime = drawTime,
        numbersJson = json.encodeToString(numbers),
        sum = sum,
        dx = dx,
        ds = ds,
        combo = combo,
        extra = extra,
        nextIssue = nextIssue
    )

    private fun DrawEntity.toDomain(): DrawRecord {
        val nums = try {
            json.decodeFromString<List<Int>>(numbersJson)
        } catch (_: Exception) {
            emptyList()
        }
        return DrawRecord(
            lotteryKey = lotteryKey,
            issue = issue,
            drawTime = drawTime,
            numbers = nums,
            sum = sum,
            dx = dx,
            ds = ds,
            combo = combo,
            extra = extra,
            nextIssue = nextIssue
        )
    }
}
