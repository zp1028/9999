package com.caifenxi.app.domain.engine

import com.caifenxi.app.domain.model.AnalysisBundle
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.FreqItem
import com.caifenxi.app.domain.model.LabRow
import com.caifenxi.app.domain.model.LuzhuColumn
import com.caifenxi.app.domain.model.PeriodStat
import com.caifenxi.app.domain.model.SumBucket
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.domain.plan.PlanPool

object AnalysisEngine {

    fun build(history: List<DrawRecord>, window: Int = 100): AnalysisBundle {
        if (history.isEmpty()) return AnalysisBundle()
        val recent = history.takeLast(window.coerceAtMost(history.size))
        val dx = recent.mapNotNull { it.dx }
        val ds = recent.mapNotNull { it.ds }
        val combo = recent.mapNotNull { it.combo }
        val sums = recent.mapNotNull { it.sum }

        return AnalysisBundle(
            freqDx = freqList(dx, listOf("大", "小")),
            freqDs = freqList(ds, listOf("单", "双")),
            freqCombo = freqList(combo, listOf("大单", "大双", "小单", "小双")),
            numberFreq = numberFreq(recent),
            sumBuckets = sumBuckets(sums),
            sumAvg = if (sums.isEmpty()) 0.0 else sums.average(),
            sumMin = sums.minOrNull() ?: 0,
            sumMax = sums.maxOrNull() ?: 0,
            luzhuDx = luzhu(dx),
            luzhuDs = luzhu(ds),
            periodStats = periodStats(recent),
            recentDx = dx.takeLast(30),
            recentDs = ds.takeLast(30)
        )
    }

    /** 简易实验室滚动验证表 */
    fun labTable(history: List<DrawRecord>, prefs: UserPrefs): List<LabRow> {
        if (history.size < 40) return emptyList()
        val rows = mutableListOf<LabRow>()
        for (def in PlanPool.ALL.filter { it.category == "大小" || it.category == "单双" }) {
            var hit = 0
            var n = 0
            val warm = maxOf(def.window, 20)
            for (i in warm until history.size) {
                val cut = history.subList(0, i)
                val seq = if (def.category == "大小") cut.mapNotNull { it.dx } else cut.mapNotNull { it.ds }
                if (seq.size < 5) continue
                val labels = if (def.category == "大小") listOf("大", "小") else listOf("单", "双")
                val pred = majority(seq.takeLast(def.window.coerceAtMost(seq.size)), def.algorithm, prefs)
                val actual = if (def.category == "大小") history[i].dx else history[i].ds
                if (pred != null && actual != null) {
                    if (pred == actual) hit++
                    n++
                }
            }
            if (n == 0) continue
            val rate = hit.toDouble() / n
            rows.add(
                LabRow(
                    name = def.planName,
                    algo = def.algorithm,
                    window = def.window,
                    sample = n,
                    hits = hit,
                    hitRate = rate,
                    score = rate * 100
                )
            )
        }
        return rows.sortedByDescending { it.score }
    }

    private fun majority(seq: List<String>, algo: String, prefs: UserPrefs): String? {
        if (seq.isEmpty()) return null
        return when (algo) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val e = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { l ->
                        e[l] = alpha * (if (l == x) 1.0 else 0.0) + (1 - alpha) * (e[l] ?: 0.0)
                    }
                }
                e.maxByOrNull { it.value }?.key
            }
            "MKV1" -> {
                if (seq.size < 2) return seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                val last = seq.last()
                val next = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0) + 1
                }
                next.maxByOrNull { it.value }?.key
                    ?: seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            }
            else -> seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        }
    }

    private fun freqList(seq: List<String>, labels: List<String>): List<FreqItem> {
        if (seq.isEmpty()) return labels.map { FreqItem(it, 0, 0.0) }
        val n = seq.size.toDouble()
        return labels.map { lab ->
            val c = seq.count { it == lab }
            FreqItem(lab, c, c / n)
        }
    }

    private fun numberFreq(recent: List<DrawRecord>): List<FreqItem> {
        val cnt = mutableMapOf<Int, Int>()
        recent.forEach { r -> r.numbers.forEach { n -> cnt[n] = (cnt[n] ?: 0) + 1 } }
        val total = recent.size.coerceAtLeast(1).toDouble()
        return cnt.entries.sortedByDescending { it.value }
            .take(20)
            .map { FreqItem(it.key.toString(), it.value, it.value / total) }
    }

    private fun sumBuckets(sums: List<Int>): List<SumBucket> {
        if (sums.isEmpty()) return emptyList()
        val min = sums.min()
        val max = sums.max()
        val step = ((max - min) / 5).coerceAtLeast(1)
        val buckets = mutableListOf<SumBucket>()
        var start = min
        while (start <= max) {
            val end = start + step
            val c = sums.count { it in start until end || (end > max && it == max) }
            buckets.add(SumBucket("$start-${end - 1}", c, c.toDouble() / sums.size))
            start = end
            if (buckets.size >= 6) break
        }
        return buckets
    }

    /** 路珠：连续相同结果合并成柱 */
    private fun luzhu(seq: List<String>): List<LuzhuColumn> {
        if (seq.isEmpty()) return emptyList()
        val cols = mutableListOf<LuzhuColumn>()
        var cur = seq.first()
        var h = 1
        for (i in 1 until seq.size) {
            if (seq[i] == cur) h++ else {
                cols.add(LuzhuColumn(cur, h))
                cur = seq[i]
                h = 1
            }
        }
        cols.add(LuzhuColumn(cur, h))
        return cols.takeLast(40)
    }

    private fun periodStats(rows: List<DrawRecord>): List<PeriodStat> {
        data class Acc(var total: Int = 0, var big: Int = 0, var odd: Int = 0)
        val map = linkedMapOf(
            "凌晨" to Acc(), "上午" to Acc(), "下午" to Acc(), "晚上" to Acc()
        )
        rows.forEach { r ->
            val hour = parseHour(r.drawTime) ?: return@forEach
            val name = when {
                hour < 6 -> "凌晨"
                hour < 12 -> "上午"
                hour < 18 -> "下午"
                else -> "晚上"
            }
            val a = map.getValue(name)
            a.total++
            if (r.dx == "大") a.big++
            if (r.ds == "单") a.odd++
        }
        return map.map { (k, v) -> PeriodStat(k, v.total, v.big, v.odd) }
    }

    private fun parseHour(time: String): Int? {
        val m = Regex("""(\d{1,2}):(\d{2})""").find(time) ?: return null
        return m.groupValues[1].toIntOrNull()
    }
}
