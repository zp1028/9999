package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun PlanScreen(vm: MainViewModel) {
    val rows = vm.planRows.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value
    var expandedId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16, bottom = CaiTokens.ScreenBottom),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
    ) {
        item {
            Text("计划大厅", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("每期随机生成 · 点击卡片展开计划内容 · 成功率跨期累计")
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                text = if (vm.backtestRunning.value) "生成/回测中…" else "重新随机生成本期计划并回测",
                onClick = { vm.runBacktest() },
                enabled = !vm.backtestRunning.value,
                modifier = Modifier.fillMaxWidth()
            )
            CaptionMuted(
                "计划数量可在设置中调整（当前 ${vm.prefs.value.planPoolCount} 条）" +
                    (pred?.let { " · 目标期 ${it.targetIssue}" } ?: "")
            )
        }

        items(consensus) { c ->
            GlobalCard {
                Text("${c.category} 共识 → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                Text("支持 ${(c.supportRatio * 100).roundToInt()}% · 分歧 ${"%.2f".format(c.disagreement)} · ${c.participatingPlans} 计划")
                LinearProgressIndicator(
                    progress = { c.supportRatio.toFloat() },
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        item {
            Text("本期计划列表（点按展开详情）", fontWeight = FontWeight.Bold)
        }

        if (rows.isEmpty()) {
            item {
                GlobalCard { Text("暂无计划。请先首页加载数据。") }
            }
        } else {
            items(rows, key = { it.first.planId }) { (def, rt) ->
                PlanCard(
                    def = def,
                    rt = rt,
                    expanded = expandedId == def.planId,
                    onToggle = {
                        expandedId = if (expandedId == def.planId) null else def.planId
                    }
                )
            }
        }
        item { Spacer(Modifier.height(CaiTokens.S24)) }
    }
}

@Composable
private fun PlanCard(
    def: PlanDefinition,
    rt: PlanRuntime,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    GlobalCard(onClick = onToggle) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(def.planName, fontWeight = FontWeight.Bold)
                CaptionMuted("${def.category} · ${def.algorithm} · 窗${def.window}" + if (def.randomGenerated) " · 随机" else "")
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text(
                    rt.hitRatePercent,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        rt.sampleCount == 0 -> MaterialTheme.colorScheme.onSurfaceVariant
                        rt.hitRate >= 0.55 -> MaterialTheme.colorScheme.secondary
                        rt.hitRate < 0.45 -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.onSurface
                    }
                )
                CaptionMuted(if (expanded) "收起 ▲" else "详情 ▼")
            }
        }
        if (rt.sampleCount > 0) {
            LinearProgressIndicator(
                progress = { rt.hitRate.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                color = MaterialTheme.colorScheme.secondary
            )
        }
        AnimatedVisibility(visible = expanded) {
            Column(Modifier.padding(top = CaiTokens.S12)) {
                Text("计划内容", fontWeight = FontWeight.SemiBold)
                DetailLine("计划 ID", def.planId)
                DetailLine("名称", def.planName)
                DetailLine("分类", def.category)
                DetailLine("算法", def.algorithm)
                DetailLine("回看窗口", "${def.window} 期")
                DetailLine("输出格式", def.outputFormat.name)
                DetailLine("命中规则", def.hitCriteria.name)
                DetailLine("参与共识", if (def.participateConsensus) "是" else "否")
                DetailLine("参与组合", if (def.participateCombo) "是" else "否")
                DetailLine("随机生成", if (def.randomGenerated) "是（本期）" else "模板抽取")
                DetailLine("绑定期号", def.seedIssue.ifBlank { "-" })
                Spacer(Modifier.height(CaiTokens.S8))
                Text("战绩统计", fontWeight = FontWeight.SemiBold)
                DetailLine("成功率", rt.hitRatePercent)
                DetailLine("命中 / 样本", "${rt.hitCount} / ${rt.sampleCount}")
                DetailLine("综合评分", "%.1f".format(rt.score))
                DetailLine("动态权重", "%.2f".format(rt.weight))
                DetailLine("连续未中", "${rt.consecutiveMiss}")
                DetailLine("状态", rt.status.name)
                DetailLine("最近预测", rt.lastPrediction ?: "-")
                DetailLine("预测目标期", rt.lastTargetIssue ?: "-")
                Spacer(Modifier.height(CaiTokens.S8))
                CaptionMuted("说明：成功率为历史已结算对错比；预测方向为模型相对支持，非中奖概率。")
            }
        }
    }
}

@Composable
private fun DetailLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
