package com.caifenxi.app.data.config

import android.content.Context
import com.caifenxi.app.domain.model.CategoryStats
import com.caifenxi.app.domain.model.StatRecord
import com.caifenxi.app.domain.model.StatsSummary
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class StatStore(context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val prefs = context.getSharedPreferences("caifenxi_stats", Context.MODE_PRIVATE)

    fun loadAll(lotteryKey: String? = null): List<StatRecord> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val list = json.decodeFromString<List<StatRecord>>(raw)
            if (lotteryKey == null) list else list.filter { it.lotteryKey == lotteryKey }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveAll(list: List<StatRecord>) {
        val trimmed = list.takeLast(800)
        prefs.edit().putString(KEY, json.encodeToString(trimmed)).apply()
    }

    fun upsert(record: StatRecord) {
        val list = loadAll().toMutableList()
        val idx = list.indexOfFirst { it.id == record.id }
        if (idx >= 0) list[idx] = record else list.add(record)
        saveAll(list)
    }

    fun clear(lotteryKey: String? = null) {
        if (lotteryKey == null) {
            prefs.edit().remove(KEY).apply()
        } else {
            saveAll(loadAll().filter { it.lotteryKey != lotteryKey })
        }
    }

    fun summary(lotteryKey: String): StatsSummary {
        val all = loadAll(lotteryKey)
        val settled = all.filter { it.result == "对" || it.result == "错" }
        val hit = settled.count { it.result == "对" }
        val miss = settled.count { it.result == "错" }
        val pending = all.count { it.result == "待开" }

        fun group(key: (StatRecord) -> String): Map<String, CategoryStats> {
            return settled.groupBy(key).mapValues { (_, rows) ->
                CategoryStats(
                    total = rows.size,
                    hit = rows.count { it.result == "对" },
                    miss = rows.count { it.result == "错" }
                )
            }
        }

        // 连对/连错（按时间倒序）
        val ordered = settled.sortedByDescending { it.settledAt ?: it.createdAt }
        var streak = 0
        if (ordered.isNotEmpty()) {
            val first = ordered.first().result
            for (r in ordered) {
                if (r.result == first) streak++ else break
            }
            if (first == "错") streak = -streak
        }
        var maxHit = 0
        var maxMiss = 0
        var curH = 0
        var curM = 0
        for (r in ordered.asReversed()) {
            if (r.result == "对") { curH++; curM = 0; maxHit = maxOf(maxHit, curH) }
            else { curM++; curH = 0; maxMiss = maxOf(maxMiss, curM) }
        }

        return StatsSummary(
            total = all.size,
            pending = pending,
            hit = hit,
            miss = miss,
            hitRate = if (hit + miss == 0) 0.0 else hit.toDouble() / (hit + miss),
            byCategory = group { it.category },
            byAlgo = group { it.algoId },
            recentStreak = streak,
            maxHitStreak = maxHit,
            maxMissStreak = maxMiss
        )
    }

    companion object {
        private const val KEY = "stat_records_json"
    }
}
