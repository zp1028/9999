package com.caifenxi.app.data.config

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.caifenxi.app.domain.model.UserPrefs
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class ConfigStore(context: Context) {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "caifenxi_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val plain = context.getSharedPreferences("caifenxi_prefs", Context.MODE_PRIVATE)

    fun loadPrefs(): UserPrefs {
        val raw = plain.getString(KEY_PREFS, null) ?: return UserPrefs()
        return try {
            json.decodeFromString<UserPrefs>(raw)
        } catch (_: Exception) {
            UserPrefs()
        }
    }

    fun savePrefs(p: UserPrefs) {
        plain.edit().putString(KEY_PREFS, json.encodeToString(p)).apply()
        // API Key 单独加密存
        if (p.aiApiKey.isNotBlank()) {
            prefs.edit().putString(KEY_AI, p.aiApiKey).apply()
        }
    }

    fun loadAiKey(): String = prefs.getString(KEY_AI, "") ?: ""

    companion object {
        private const val KEY_PREFS = "user_prefs_json"
        private const val KEY_AI = "ai_api_key"
    }
}
