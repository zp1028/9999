package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable

enum class PlanOutputFormat {
    DIRECTION,
    ZONE_DISTRIBUTION,
    NUMBER_SCORES,
    STRUCTURE_VALUE
}

enum class PlanHitCriteria {
    DIRECTION_MATCH,
    ZONE_DISTANCE,
    TOP20_HIT,
    STRUCTURE_RANGE
}

@Serializable
data class PlanDefinition(
    val planId: String,
    val planName: String,
    val category: String,
    val algorithm: String,
    val window: Int,
    val outputFormat: PlanOutputFormat = PlanOutputFormat.DIRECTION,
    val hitCriteria: PlanHitCriteria = PlanHitCriteria.DIRECTION_MATCH,
    val backtestWindows: List<Int> = listOf(10, 20, 50, 100, 200, 500),
    val baselineType: String = "uniform_50",
    val baselineValue: Double = 0.50,
    val weightCap: Double = 1.0,
    val participateConsensus: Boolean = true,
    val participateCombo: Boolean = false,
    /** 是否为本期随机生成的实例 */
    val randomGenerated: Boolean = false,
    val seedIssue: String = ""
)

@Serializable
data class PlanRuntime(
    val planId: String,
    val weight: Double = 1.0,
    val score: Double = 50.0,
    val sampleCount: Int = 0,
    val hitCount: Int = 0,
    val consecutiveMiss: Int = 0,
    val status: PlanStatus = PlanStatus.ACTIVE,
    val lastPrediction: String? = null,
    val lastTargetIssue: String? = null
) {
    /** 对错成功率 0~1（仅已结算样本） */
    val hitRate: Double
        get() = if (sampleCount <= 0) 0.0 else hitCount.toDouble() / sampleCount

    val hitRatePercent: String
        get() = if (sampleCount <= 0) "-" else "%.1f%%".format(hitRate * 100)
}

enum class PlanStatus {
    ACTIVE,
    PROMOTED,
    DEMOTED,
    HOLD,
    ELIMINATED
}

@Serializable
data class PlanPredictionRecord(
    val planId: String,
    val lotteryKey: String,
    val targetIssue: String,
    val cutoffIssue: String,
    val output: String,
    val scoreAtPredict: Double,
    val weightAtPredict: Double,
    val settled: Boolean = false,
    val hit: Boolean? = null,
    val settledAt: Long? = null,
    val planName: String = "",
    val category: String = ""
)

@Serializable
data class ModelConsensus(
    val lotteryKey: String,
    val targetIssue: String,
    val category: String,
    val leadingDirection: String,
    val supportRatio: Double,
    val disagreement: Double,
    val participatingPlans: Int,
    val detail: Map<String, Double> = emptyMap()
)

object ScoreWeights {
    const val RECENT_HIT = 30.0
    const val MID_HIT = 18.0
    const val LONG_HIT = 12.0
    const val STABILITY = 12.0
    const val SAMPLE = 8.0
    const val STREAK = 10.0
    const val BASELINE_BEAT = 10.0
}
