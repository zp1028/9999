package com.caifenxi.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** 设计令牌 —— 对齐你提供的全局规范（Compose 版） */
object CaiTokens {
    val Primary = Color(0xFF1A1A1A)
    val Accent = Color(0xFFC8A97E) // 香槟金
    val BgLight = Color(0xFFF8F8F8)
    val BgDark = Color(0xFF0D0D0D)
    val SurfaceLight = Color(0xFFFFFFFF)
    val SurfaceDark = Color(0xFF1C1C1C)
    val Muted = Color(0xFF999999)
    val Success = Color(0xFF2E7D32)
    val Danger = Color(0xFFC62828)
    val Warning = Color(0xFFF9A825)

    // 8pt 网格
    val Space = listOf(4, 8, 12, 16, 24, 32, 48, 64).map { it.dp }
    val S4 = 4.dp
    val S8 = 8.dp
    val S12 = 12.dp
    val S16 = 16.dp
    val S24 = 24.dp
    val S32 = 32.dp

    val RadiusCard = 20.dp
    val RadiusButton = 100.dp // 胶囊
    val RadiusIcon = 12.dp

    val ScreenHPadding = 24.dp
    val ScreenBottom = 34.dp
}

data class CaiElevation(
    val cardOffsetY: Dp = 4.dp,
    val cardBlur: Dp = 20.dp,
    val cardAlpha: Float = 0.06f,
    val cardElevation: Dp = 5.dp
)

val LocalCaiElevation = staticCompositionLocalOf { CaiElevation() }

private val LightColors = lightColorScheme(
    primary = CaiTokens.Primary,
    onPrimary = Color.White,
    secondary = CaiTokens.Accent,
    onSecondary = CaiTokens.Primary,
    background = CaiTokens.BgLight,
    onBackground = CaiTokens.Primary,
    surface = CaiTokens.SurfaceLight,
    onSurface = CaiTokens.Primary,
    surfaceVariant = Color(0xFFF0EDE8),
    onSurfaceVariant = Color(0xFF666666),
    secondaryContainer = Color(0xFFF3EBD9),
    onSecondaryContainer = CaiTokens.Primary,
    primaryContainer = Color(0xFFEEEEEE),
    onPrimaryContainer = CaiTokens.Primary,
    error = CaiTokens.Danger
)

private val DarkColors = darkColorScheme(
    primary = CaiTokens.Accent,
    onPrimary = CaiTokens.Primary,
    secondary = CaiTokens.Accent,
    onSecondary = CaiTokens.Primary,
    background = CaiTokens.BgDark,
    onBackground = Color(0xFFF5F5F5),
    surface = CaiTokens.SurfaceDark,
    onSurface = Color(0xFFF5F5F5),
    surfaceVariant = Color(0xFF2A2A2A),
    onSurfaceVariant = Color(0xFFAAAAAA),
    secondaryContainer = Color(0xFF3A342C),
    onSecondaryContainer = Color(0xFFF5F5F5),
    primaryContainer = Color(0xFF2A2A2A),
    onPrimaryContainer = Color(0xFFF5F5F5),
    error = Color(0xFFEF9A9A)
)

private val CaiTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = (28 * 1.6).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = (22 * 1.6).sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = (15 * 1.6).sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = (15 * 1.6).sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = (12 * 1.6).sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = (12 * 1.6).sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = (22 * 1.6).sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = (16 * 1.6).sp
    )
)

@Composable
fun CaiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalCaiElevation provides CaiElevation()) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkColors else LightColors,
            typography = CaiTypography,
            shapes = androidx.compose.material3.Shapes(
                extraSmall = RoundedCornerShape(CaiTokens.RadiusIcon),
                small = RoundedCornerShape(CaiTokens.RadiusIcon),
                medium = RoundedCornerShape(CaiTokens.RadiusCard),
                large = RoundedCornerShape(CaiTokens.RadiusCard),
                extraLarge = RoundedCornerShape(CaiTokens.RadiusButton)
            ),
            content = content
        )
    }
}
