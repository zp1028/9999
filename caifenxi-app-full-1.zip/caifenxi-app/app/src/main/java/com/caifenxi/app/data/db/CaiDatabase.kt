package com.caifenxi.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.entity.DrawEntity

@Database(
    entities = [DrawEntity::class],
    version = 1,
    exportSchema = false
)
abstract class CaiDatabase : RoomDatabase() {
    abstract fun drawDao(): DrawDao

    companion object {
        @Volatile private var instance: CaiDatabase? = null

        fun getInstance(context: Context): CaiDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CaiDatabase::class.java,
                    "caifenxi.db"
                ).build().also { instance = it }
            }
        }
    }
}
