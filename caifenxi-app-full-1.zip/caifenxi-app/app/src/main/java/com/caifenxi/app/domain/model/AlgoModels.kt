package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable

enum class AlgoMode(val id: String, val label: String, val icon: String) {
    EXPERIENCE("experience", "经验学习", "🎯"),
    PATTERN("pattern", "形态匹配", "📊"),
    MANUAL("manual", "手动标记", "✍️"),
    FUSION("fusion", "智能融合", "🔮"),
    LAB_BEST("lab_best", "实验室最优", "🏆"),
    COMPARE("compare", "多算法对比", "⚖️");

    companion object {
        fun fromId(id: String): AlgoMode = entries.find { it.id == id } ?: EXPERIENCE
    }
}

@Serializable
data class AlgoResult(
    val algoId: String,
    val algoLabel: String,
    val direction: String,
    val score: Double,
    val detail: String = "",
    val sample: Int = 0,
    val confidence: String = "中"
)

@Serializable
data class StatRecord(
    val id: String,
    val lotteryKey: String,
    val issue: String,
    val category: String,
    val lean: String,
    val actual: String? = null,
    val result: String = "待开",
    val algoId: String = "experience",
    val score: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val settledAt: Long? = null
)

@Serializable
data class StatsSummary(
    val total: Int = 0,
    val pending: Int = 0,
    val hit: Int = 0,
    val miss: Int = 0,
    val hitRate: Double = 0.0,
    val byCategory: Map<String, CategoryStats> = emptyMap(),
    val byAlgo: Map<String, CategoryStats> = emptyMap(),
    val recentStreak: Int = 0,
    val maxHitStreak: Int = 0,
    val maxMissStreak: Int = 0
)

@Serializable
data class CategoryStats(
    val total: Int = 0,
    val hit: Int = 0,
    val miss: Int = 0
) {
    val hitRate: Double get() = if (hit + miss == 0) 0.0 else hit.toDouble() / (hit + miss)
}

/** 手动标记：用户指定某期某类的方向 */
@Serializable
data class ManualMark(
    val lotteryKey: String,
    val category: String,   // 大小 / 单双 / 组合
    val direction: String,
    val updatedAt: Long = System.currentTimeMillis()
)

/** 分析页数据 */
data class FreqItem(val label: String, val count: Int, val rate: Double)
data class SumBucket(val range: String, val count: Int, val rate: Double)
data class LuzhuColumn(val value: String, val height: Int) // 连续同值柱
data class PeriodStat(val name: String, val total: Int, val dxBig: Int, val dsOdd: Int)

data class AnalysisBundle(
    val freqDx: List<FreqItem> = emptyList(),
    val freqDs: List<FreqItem> = emptyList(),
    val freqCombo: List<FreqItem> = emptyList(),
    val numberFreq: List<FreqItem> = emptyList(),
    val sumBuckets: List<SumBucket> = emptyList(),
    val sumAvg: Double = 0.0,
    val sumMin: Int = 0,
    val sumMax: Int = 0,
    val luzhuDx: List<LuzhuColumn> = emptyList(),
    val luzhuDs: List<LuzhuColumn> = emptyList(),
    val periodStats: List<PeriodStat> = emptyList(),
    val recentDx: List<String> = emptyList(),
    val recentDs: List<String> = emptyList()
)

data class LabRow(
    val name: String,
    val algo: String,
    val window: Int,
    val sample: Int,
    val hits: Int,
    val hitRate: Double,
    val score: Double
)
