package com.caifenxi.app.domain.engine

import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.AlgoResult
import com.caifenxi.app.domain.model.DirectionPrediction
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.NumberScore
import com.caifenxi.app.domain.model.PositionPrediction
import com.caifenxi.app.domain.model.PredictCategory
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.exp

/**
 * 多算法预测引擎（对齐原版：经验学习 / 形态匹配 / 智能融合 / 实验室最优）
 */
object PredictEngine {

    fun predict(
        history: List<DrawRecord>,
        lotteryType: LotteryType,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String,
        mode: AlgoMode = AlgoMode.fromId(prefs.currentAlgo)
    ): PredictionSnapshot {
        if (history.size < 5) {
            return PredictionSnapshot(
                lotteryKey = history.firstOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                createdAt = System.currentTimeMillis(),
                algoTag = mode.id
            )
        }
        val window = prefs.predictionWindow.coerceIn(20, 500)
        val recent = history.takeLast(window)
        val dxSeq = recent.mapNotNull { it.dx }
        val dsSeq = recent.mapNotNull { it.ds }
        val comboSeq = recent.mapNotNull { it.combo }

        val effective = when (mode) {
            AlgoMode.COMPARE -> AlgoMode.EXPERIENCE // 主展示用经验，对比另算
            AlgoMode.LAB_BEST -> pickLabBest(dxSeq, dsSeq, prefs)
            else -> mode
        }

        val dx = predictCategory(dxSeq, listOf("大", "小"), prefs, PredictCategory.DX, effective)
        val ds = predictCategory(dsSeq, listOf("单", "双"), prefs, PredictCategory.DS, effective)
        val comboLabels = listOf("大单", "大双", "小单", "小双")
        val combo = predictCategory(comboSeq, comboLabels, prefs, PredictCategory.COMBO, effective)
        val comboList = topDirections(comboSeq, comboLabels, prefs, effective, prefs.comboPredCount.coerceIn(1, 4))

        val numberScores = when (lotteryType) {
            LotteryType.LUCK20 -> numberFrequency(recent, 1..80, 20)
            LotteryType.PKS -> numberFrequency(recent, 1..10, 10)
        }
        val positions = when (lotteryType) {
            LotteryType.PKS -> positionPredict(recent, 10, prefs.positionTopN)
            LotteryType.LUCK20 -> positionPredict(recent, 5, prefs.positionTopN)
        }

        return PredictionSnapshot(
            lotteryKey = recent.last().lotteryKey,
            targetIssue = targetIssue,
            cutoffIssue = cutoffIssue,
            createdAt = System.currentTimeMillis(),
            frozen = false,
            dx = dx,
            ds = ds,
            combo = combo,
            comboList = comboList,
            numberScores = numberScores,
            positions = positions,
            algoTag = effective.id
        )
    }

    /** 多算法对比：每个类别返回全部算法结果 */
    fun compareAll(
        history: List<DrawRecord>,
        prefs: UserPrefs
    ): Map<String, List<AlgoResult>> {
        if (history.size < 5) return emptyMap()
        val recent = history.takeLast(prefs.predictionWindow.coerceIn(20, 500))
        val map = mutableMapOf<String, List<AlgoResult>>()
        val specs = listOf(
            Triple("大小", recent.mapNotNull { it.dx }, listOf("大", "小")),
            Triple("单双", recent.mapNotNull { it.ds }, listOf("单", "双")),
            Triple("组合", recent.mapNotNull { it.combo }, listOf("大单", "大双", "小单", "小双"))
        )
        for ((name, seq, labels) in specs) {
            map[name] = listOf(
                AlgoMode.EXPERIENCE, AlgoMode.PATTERN, AlgoMode.FUSION
            ).map { mode ->
                val r = runAlgo(seq, labels, prefs, mode)
                AlgoResult(
                    algoId = mode.id,
                    algoLabel = mode.label,
                    direction = r.first,
                    score = r.second,
                    detail = r.third,
                    sample = seq.size,
                    confidence = confLabel(r.second)
                )
            }
        }
        return map
    }

    private fun pickLabBest(dxSeq: List<String>, dsSeq: List<String>, prefs: UserPrefs): AlgoMode {
        // 简单：在短窗回测上选命中更高的算法
        fun score(mode: AlgoMode, seq: List<String>, labels: List<String>): Double {
            if (seq.size < 20) return 0.5
            var hit = 0
            var n = 0
            for (i in 15 until seq.size) {
                val sub = seq.subList(0, i)
                val (pred, _) = runAlgo(sub, labels, prefs, mode)
                if (pred == seq[i]) hit++
                n++
            }
            return if (n == 0) 0.5 else hit.toDouble() / n
        }
        val modes = listOf(AlgoMode.EXPERIENCE, AlgoMode.PATTERN, AlgoMode.FUSION)
        return modes.maxByOrNull {
            (score(it, dxSeq, listOf("大", "小")) + score(it, dsSeq, listOf("单", "双"))) / 2
        } ?: AlgoMode.EXPERIENCE
    }

    private fun predictCategory(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs,
        category: PredictCategory,
        mode: AlgoMode
    ): DirectionPrediction? {
        if (seq.isEmpty()) return null
        val (dir, score, detail) = runAlgo(seq, labels, prefs, mode)
        return DirectionPrediction(
            category = category,
            direction = dir,
            score = score,
            algo = mode.id,
            detail = detail
        )
    }

    /** @return Triple(direction, score 0~1, detail) */
    private fun runAlgo(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs,
        mode: AlgoMode
    ): Triple<String, Double, String> {
        val scores = when (mode) {
            AlgoMode.PATTERN -> patternScores(seq, labels)
            AlgoMode.MANUAL -> experienceScores(seq, labels, prefs) // 实际方向由 ViewModel 用手动标记覆盖
            AlgoMode.FUSION -> fusionScores(seq, labels, prefs)
            AlgoMode.LAB_BEST, AlgoMode.COMPARE, AlgoMode.EXPERIENCE ->
                experienceScores(seq, labels, prefs)
        }
        val norm = normalize(scores, prefs.ewmaWeightTemperature.toDouble())
        val best = norm.maxByOrNull { it.value } ?: return Triple(labels.first(), 0.5, "")
        val detail = norm.entries.sortedByDescending { it.value }
            .joinToString(" ") { "${it.key}:${"%.0f".format(it.value * 100)}%" }
        return Triple(best.key, best.value, detail)
    }

    /** 经验学习：多窗频率 + EWMA + 一阶转移 */
    private fun experienceScores(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs
    ): Map<String, Double> {
        val scores = labels.associateWith { 0.0 }.toMutableMap()
        listOf(10, 20, 50).forEachIndexed { i, w ->
            val slice = seq.takeLast(w.coerceAtMost(seq.size))
            val wt = when (i) { 0 -> 0.35; 1 -> 0.35; else -> 0.30 }
            labels.forEach { lab ->
                scores[lab] = scores.getValue(lab) +
                    slice.count { it == lab }.toDouble() / slice.size.coerceAtLeast(1) * wt
            }
        }
        if (prefs.ewmaEnabled && seq.isNotEmpty()) {
            val alpha = prefs.ewmaAlpha.toDouble().coerceIn(0.05, 0.5)
            val ewma = labels.associateWith { 1.0 / labels.size }.toMutableMap()
            seq.forEach { x ->
                labels.forEach { lab ->
                    val t = if (lab == x) 1.0 else 0.0
                    ewma[lab] = alpha * t + (1 - alpha) * ewma.getValue(lab)
                }
            }
            labels.forEach { lab ->
                scores[lab] = scores.getValue(lab) * 0.55 + ewma.getValue(lab) * 0.45
            }
        }
        if (seq.size >= 2) {
            val last = seq.last()
            val trans = labels.associateWith { 0.0 }.toMutableMap()
            var c = 0
            for (i in 1 until seq.size) {
                if (seq[i - 1] == last) {
                    trans[seq[i]] = trans.getValue(seq[i]) + 1
                    c++
                }
            }
            if (c > 0) {
                labels.forEach { lab ->
                    scores[lab] = scores.getValue(lab) * 0.7 + (trans.getValue(lab) / c) * 0.3
                }
            }
        }
        if (prefs.streakDecayEnabled && seq.isNotEmpty()) {
            val last = seq.last()
            var streak = 0
            for (i in seq.indices.reversed()) {
                if (seq[i] == last) streak++ else break
            }
            if (streak >= 3) {
                scores[last] = scores.getValue(last) * (1.0 - 0.08 * prefs.antiHerdStrength)
            }
        }
        return scores
    }

    /** 形态匹配：找历史中与近期尾部相同的片段，看下一期分布 */
    private fun patternScores(seq: List<String>, labels: List<String>): Map<String, Double> {
        val scores = labels.associateWith { 0.01 }.toMutableMap()
        if (seq.size < 6) return frequencyScores(seq, labels)
        for (len in listOf(2, 3, 4, 5)) {
            if (seq.size <= len) continue
            val pattern = seq.takeLast(len)
            var hits = 0
            for (i in 0 until seq.size - len) {
                val slice = seq.subList(i, i + len)
                if (slice == pattern) {
                    val next = seq.getOrNull(i + len) ?: continue
                    if (next in scores) {
                        scores[next] = scores.getValue(next) + 1.0 * (6 - len)
                        hits++
                    }
                }
            }
            if (hits == 0) {
                // 回退频率
                val freq = frequencyScores(seq.takeLast(20), labels)
                labels.forEach { scores[it] = scores.getValue(it) + freq.getValue(it) }
            }
        }
        return scores
    }

    /** 智能融合：经验 + 形态加权平均 */
    private fun fusionScores(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs
    ): Map<String, Double> {
        val a = experienceScores(seq, labels, prefs)
        val b = patternScores(seq, labels)
        val na = normalize(a, 0.1)
        val nb = normalize(b, 0.1)
        return labels.associateWith { lab ->
            na.getValue(lab) * 0.55 + nb.getValue(lab) * 0.45
        }
    }

    private fun frequencyScores(seq: List<String>, labels: List<String>): Map<String, Double> {
        if (seq.isEmpty()) return labels.associateWith { 1.0 / labels.size }
        return labels.associateWith { lab ->
            seq.count { it == lab }.toDouble() / seq.size
        }
    }

    private fun normalize(scores: Map<String, Double>, temp: Double): Map<String, Double> {
        val t = temp.coerceIn(0.02, 0.5)
        val maxS = scores.values.maxOrNull() ?: 1.0
        val expMap = scores.mapValues { (_, v) -> exp((v - maxS) / t) }
        val sum = expMap.values.sum().coerceAtLeast(1e-9)
        return expMap.mapValues { it.value / sum }
    }

    private fun confLabel(score: Double): String = when {
        score >= 0.62 -> "高"
        score >= 0.52 -> "中"
        else -> "低"
    }


    private fun topDirections(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs,
        mode: AlgoMode,
        topN: Int
    ): List<DirectionPrediction> {
        if (seq.isEmpty()) return emptyList()
        val scores = when (mode) {
            AlgoMode.PATTERN -> patternScores(seq, labels)
            AlgoMode.FUSION -> fusionScores(seq, labels, prefs)
            else -> experienceScores(seq, labels, prefs)
        }
        val norm = normalize(scores, prefs.ewmaWeightTemperature.toDouble())
        return norm.entries.sortedByDescending { it.value }.take(topN.coerceAtLeast(1)).map { (dir, sc) ->
            DirectionPrediction(
                category = PredictCategory.COMBO,
                direction = dir,
                score = sc,
                algo = mode.id,
                detail = "候选"
            )
        }
    }

    private fun numberFrequency(recent: List<DrawRecord>, range: IntRange, topN: Int): List<NumberScore> {
        val cnt = range.associateWith { 0 }.toMutableMap()
        recent.forEach { row ->
            row.numbers.forEach { n -> if (n in range) cnt[n] = cnt.getValue(n) + 1 }
        }
        val total = recent.size.coerceAtLeast(1).toDouble()
        return cnt.entries.sortedByDescending { it.value }
            .mapIndexed { idx, e -> NumberScore(e.key, e.value / total, idx + 1) }
            .take(topN)
    }

    private fun positionPredict(recent: List<DrawRecord>, posCount: Int, topN: Int): List<PositionPrediction> {
        return (0 until posCount).map { idx ->
            val seq = recent.mapNotNull { it.numbers.getOrNull(idx) }
            val cnt = seq.groupingBy { it }.eachCount()
            val total = seq.size.coerceAtLeast(1).toDouble()
            val tops = cnt.entries.sortedByDescending { it.value }.take(topN)
                .mapIndexed { r, e -> NumberScore(e.key, e.value / total, r + 1) }
            val name = when (idx) { 0 -> "冠军"; 1 -> "亚军"; else -> "第${idx + 1}" }
            PositionPrediction(idx, name, tops)
        }
    }

    fun suggestNextIssue(latest: String?): String {
        if (latest.isNullOrBlank()) return "-"
        val n = latest.toLongOrNull() ?: return latest
        return (n + 1).toString()
    }
}
