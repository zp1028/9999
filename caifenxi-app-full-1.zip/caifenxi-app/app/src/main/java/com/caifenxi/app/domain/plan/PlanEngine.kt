package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanStatus
import com.caifenxi.app.domain.model.ScoreWeights
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.min
import kotlin.random.Random

/**
 * 计划引擎：
 * - 每期自动随机生成一批预测计划（基于模板池）
 * - 结算后累计每个计划的对错成功率
 */
class PlanEngine {

    private val runtimes = mutableMapOf<String, PlanRuntime>()
    /** 模板 planId → 累计统计（跨期保留成功率） */
    private val careerStats = mutableMapOf<String, PlanRuntime>()
    private val historyPreds = mutableListOf<PlanPredictionRecord>()
    /** 当前期随机激活的计划定义 */
    private var activePlans: List<PlanDefinition> = emptyList()
    private var lastGenIssue: String = ""

    fun ensureCareerFromPool() {
        PlanPool.ALL.forEach { def ->
            if (!careerStats.containsKey(def.planId)) {
                careerStats[def.planId] = PlanRuntime(planId = def.planId)
            }
        }
    }

    /**
     * 每期随机生成预测计划。
     * @param count 生成本期计划数量，默认 12
     */
    fun generateRandomPlansForIssue(
        targetIssue: String,
        count: Int = 12,
        force: Boolean = false
    ): List<PlanDefinition> {
        if (!force && lastGenIssue == targetIssue && activePlans.isNotEmpty()) {
            return activePlans
        }
        ensureCareerFromPool()
        val seed = targetIssue.toLongOrNull() ?: targetIssue.hashCode().toLong()
        val rnd = Random(seed xor System.currentTimeMillis().and(0xFFFF))

        val templates = PlanPool.ALL
        val windows = listOf(5, 8, 10, 15, 20, 30, 50, 80, 100)
        val algos = listOf("FREQ", "EWMA", "MKV1", "MSF")
        val cats = listOf("大小", "单双", "组合")

        val generated = mutableListOf<PlanDefinition>()
        // 1) 从模板池随机抽若干
        val shuffled = templates.shuffled(rnd).take((count * 2 / 3).coerceAtLeast(4))
        generated.addAll(shuffled.map { it.copy(randomGenerated = false, seedIssue = targetIssue) })

        // 2) 再随机「新配方」计划：随机类别+算法+窗口
        val need = (count - generated.size).coerceAtLeast(3)
        repeat(need) { i ->
            val cat = cats.random(rnd)
            val algo = algos.random(rnd)
            val win = windows.random(rnd)
            val id = "RND-${targetIssue.takeLast(6)}-$i-$algo$win"
            generated.add(
                PlanDefinition(
                    planId = id,
                    planName = "随机$cat·$algo·${win}窗",
                    category = if (cat == "组合") "大小" else cat, // 运行时组合用 combo 序列
                    algorithm = algo,
                    window = win,
                    outputFormat = PlanOutputFormat.DIRECTION,
                    hitCriteria = PlanHitCriteria.DIRECTION_MATCH,
                    participateConsensus = true,
                    randomGenerated = true,
                    seedIssue = targetIssue
                )
            )
            // 组合类单独标记在 planName
            if (cat == "组合") {
                val last = generated.removeAt(generated.lastIndex)
                generated.add(last.copy(category = "组合", planName = "随机组合·$algo·${win}窗"))
            }
            if (!careerStats.containsKey(id)) {
                careerStats[id] = PlanRuntime(planId = id)
            }
        }

        activePlans = generated.distinctBy { it.planId }.take(count)
        lastGenIssue = targetIssue
        activePlans.forEach { def ->
            runtimes[def.planId] = careerStats[def.planId] ?: PlanRuntime(planId = def.planId)
        }
        return activePlans
    }

    fun getActivePlans(): List<PlanDefinition> = activePlans

    fun getRuntimes(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureCareerFromPool()
        val defs = if (activePlans.isNotEmpty()) activePlans else PlanPool.ALL
        return defs.map { def ->
            val rt = careerStats[def.planId] ?: runtimes[def.planId] ?: PlanRuntime(def.planId)
            def to rt
        }.sortedWith(
            compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.sampleCount > 0 }
                .thenByDescending { it.second.hitRate }
                .thenByDescending { it.second.score }
        )
    }

    /** 全模板职业成功率排行（含未激活） */
    
    /** 某计划的预测历史（含当期与已结算） */
    fun getPredictionHistory(planId: String, limit: Int = 30): List<PlanPredictionRecord> =
        historyPreds.filter { it.planId == planId }.takeLast(limit).reversed()

    /** 当期（未结算）全部计划预测 */
    fun getCurrentPredictions(targetIssue: String): List<PlanPredictionRecord> =
        historyPreds.filter { it.targetIssue == targetIssue && !it.settled }
            .ifEmpty {
                // 若尚未写入 history，从最近 predictAll 结果空则返回空
                emptyList()
            }

    fun getAllRecentPredictions(limit: Int = 80): List<PlanPredictionRecord> =
        historyPreds.takeLast(limit).reversed()

    fun getCareerLeaderboard(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureCareerFromPool()
        return PlanPool.ALL.map { it to (careerStats[it.planId] ?: PlanRuntime(it.planId)) }
            .sortedByDescending { it.second.hitRate }
    }

    fun backtest(history: List<DrawRecord>, prefs: UserPrefs, minWarm: Int = 30) {
        ensureCareerFromPool()
        if (history.size < minWarm + 5) return
        // 保留 career 不清零，只在回测过程中累加；若需重置可 clearCareer()
        for (i in minWarm until history.size) {
            val cutoff = history.subList(0, i)
            val actual = history[i]
            generateRandomPlansForIssue(actual.issue, count = prefs.planPoolCount.coerceIn(4, 30), force = true)
            val preds = predictAll(cutoff, prefs, actual.issue, cutoff.last().issue)
            preds.forEach { rec ->
                val hit = evaluateHit(rec, actual)
                val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
                historyPreds.add(settled)
                updateRuntime(settled)
            }
        }
    }

    fun clearCareer() {
        careerStats.clear()
        runtimes.clear()
        historyPreds.clear()
        activePlans = emptyList()
        lastGenIssue = ""
    }

    fun predictForNext(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        generateRandomPlansForIssue(targetIssue, count = prefs.planPoolCount.coerceIn(4, 30), force = false)
        return predictAll(history, prefs, targetIssue, cutoffIssue)
    }

    fun consensus(
        lotteryKey: String,
        targetIssue: String,
        preds: List<PlanPredictionRecord>
    ): List<ModelConsensus> {
        val byCat = preds.groupBy { it.category.ifBlank { planCategory(it.planId) } }
        return listOf("大小", "单双", "组合").mapNotNull { cat ->
            val list = byCat[cat] ?: return@mapNotNull null
            val weightSum = mutableMapOf<String, Double>()
            var totalW = 0.0
            list.forEach { rec ->
                val rt = careerStats[rec.planId] ?: runtimes[rec.planId] ?: return@forEach
                if (rt.status == PlanStatus.ELIMINATED) return@forEach
                // 成功率越高权重越大
                val wr = if (rt.sampleCount >= 5) 0.5 + rt.hitRate * 0.5 else 0.5
                val w = (rt.weight * wr).coerceIn(0.05, 1.5)
                weightSum[rec.output] = (weightSum[rec.output] ?: 0.0) + w
                totalW += w
            }
            if (totalW <= 0) return@mapNotNull null
            val leading = weightSum.maxByOrNull { it.value } ?: return@mapNotNull null
            val ratio = leading.value / totalW
            val second = weightSum.values.sortedDescending().getOrNull(1) ?: 0.0
            val disagreement = if (leading.value > 0) second / leading.value else 1.0
            ModelConsensus(
                lotteryKey = lotteryKey,
                targetIssue = targetIssue,
                category = cat,
                leadingDirection = leading.key,
                supportRatio = ratio,
                disagreement = disagreement,
                participatingPlans = list.size,
                detail = weightSum.mapValues { it.value / totalW }
            )
        }
    }

    private fun predictAll(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        val plans = if (activePlans.isNotEmpty()) activePlans else {
            generateRandomPlansForIssue(targetIssue, prefs.planPoolCount.coerceIn(4, 30), true)
            activePlans
        }
        return plans.mapNotNull { def ->
            val out = runPlan(def, history, prefs) ?: return@mapNotNull null
            val rt = careerStats[def.planId] ?: PlanRuntime(def.planId)
            val rec = PlanPredictionRecord(
                planId = def.planId,
                lotteryKey = history.lastOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                output = out,
                scoreAtPredict = rt.score,
                weightAtPredict = rt.weight,
                planName = def.planName,
                category = def.category
            )
            // 记录当期预测（同 plan+issue 替换未结算）
            historyPreds.removeAll { it.planId == def.planId && it.targetIssue == targetIssue && !it.settled }
            historyPreds.add(rec)
            if (historyPreds.size > 5000) {
                historyPreds.subList(0, historyPreds.size - 4000).clear()
            }
            // 同步 lastPrediction
            careerStats[def.planId] = rt.copy(lastPrediction = out, lastTargetIssue = targetIssue)
            runtimes[def.planId] = careerStats.getValue(def.planId)
            rec
        }
    }

    private fun runPlan(def: PlanDefinition, history: List<DrawRecord>, prefs: UserPrefs): String? {
        val slice = history.takeLast(def.window.coerceAtLeast(5).coerceAtMost(history.size))
        if (slice.size < 3) return null
        return when (def.category) {
            "大小" -> majority(slice.mapNotNull { it.dx }, def, prefs)
            "单双" -> majority(slice.mapNotNull { it.ds }, def, prefs)
            "组合" -> majority(slice.mapNotNull { it.combo }, def, prefs)
            "区间", "结构", "AI" -> majority(slice.mapNotNull { it.combo }, def, prefs)
            "号码" -> {
                val cnt = mutableMapOf<Int, Int>()
                slice.forEach { r -> r.numbers.forEach { n -> cnt[n] = (cnt[n] ?: 0) + 1 } }
                cnt.maxByOrNull { it.value }?.key?.toString()
            }
            else -> majority(slice.mapNotNull { it.dx }, def, prefs)
        }
    }

    private fun majority(seq: List<String>, def: PlanDefinition, prefs: UserPrefs): String? {
        if (seq.isEmpty()) return null
        return when (def.algorithm) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val ewma = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { lab ->
                        val t = if (lab == x) 1.0 else 0.0
                        ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                    }
                }
                ewma.maxByOrNull { it.value }?.key
            }
            "MKV1" -> {
                if (seq.size < 2) return seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                val last = seq.last()
                val next = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0) + 1
                }
                next.maxByOrNull { it.value }?.key
                    ?: seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            }
            else -> seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        }
    }


    /** 新开奖结算计划预测 */
    fun settlePendingWithDraw(draw: DrawRecord) {
        val pending = historyPreds.filter { !it.settled && issueReached(it.targetIssue, draw.issue) }
        pending.forEach { rec ->
            val hit = evaluateHit(rec, draw)
            val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
            val idx = historyPreds.indexOfFirst {
                it.planId == rec.planId && it.targetIssue == rec.targetIssue && !it.settled
            }
            if (idx >= 0) historyPreds[idx] = settled else historyPreds.add(settled)
            updateRuntime(settled)
        }
    }

    private fun issueReached(predIssue: String, drawIssue: String): Boolean {
        if (predIssue == drawIssue) return true
        val a = predIssue.toLongOrNull()
        val b = drawIssue.toLongOrNull()
        return a != null && b != null && a <= b
    }

    private fun evaluateHit(rec: PlanPredictionRecord, actual: DrawRecord): Boolean {
        val cat = rec.category.ifBlank { planCategory(rec.planId) }
        return when (cat) {
            "大小" -> rec.output == actual.dx
            "单双" -> rec.output == actual.ds
            "组合" -> rec.output == actual.combo
            "号码" -> rec.output.toIntOrNull()?.let { it in actual.numbers } ?: false
            else -> rec.output == actual.dx || rec.output == actual.ds
        }
    }

    private fun updateRuntime(rec: PlanPredictionRecord) {
        val prev = careerStats[rec.planId] ?: PlanRuntime(planId = rec.planId)
        val hit = rec.hit == true
        val sample = prev.sampleCount + 1
        val hits = prev.hitCount + if (hit) 1 else 0
        val miss = if (hit) 0 else prev.consecutiveMiss + 1
        val hitRate = hits.toDouble() / sample

        var score = hitRate * ScoreWeights.RECENT_HIT * 2.5
        score += min(sample / 100.0, 1.0) * ScoreWeights.SAMPLE
        if (miss >= 5) score -= ScoreWeights.STREAK * (miss - 4) * 0.15
        score = score.coerceIn(0.0, 100.0)

        var weight = 0.5 + (hitRate - 0.5) * 0.6
        weight = weight.coerceIn(0.35, 1.15)

        val status = when {
            miss >= 12 && sample >= 30 -> PlanStatus.DEMOTED
            sample >= 100 && hitRate < 0.42 -> PlanStatus.ELIMINATED
            score >= 65 && sample >= 50 -> PlanStatus.PROMOTED
            else -> PlanStatus.ACTIVE
        }

        val updated = prev.copy(
            weight = weight,
            score = score,
            sampleCount = sample,
            hitCount = hits,
            consecutiveMiss = miss,
            status = status,
            lastPrediction = rec.output,
            lastTargetIssue = rec.targetIssue
        )
        careerStats[rec.planId] = updated
        runtimes[rec.planId] = updated
    }

    private fun planCategory(planId: String): String =
        activePlans.find { it.planId == planId }?.category
            ?: PlanPool.ALL.find { it.planId == planId }?.category
            ?: ""
}
