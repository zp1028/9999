package com.caifenxi.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.ui.theme.CaiTokens
import com.caifenxi.app.ui.theme.LocalCaiElevation

/**
 * 页面容器：左右 24、底 34（对齐提示词 ScreenContainer）
 */
@Composable
fun ScreenContainer(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(
                start = CaiTokens.ScreenHPadding,
                end = CaiTokens.ScreenHPadding,
                top = CaiTokens.S16,
                bottom = CaiTokens.ScreenBottom
            ),
        content = content
    )
}

/** GlobalCard：20 圆角 + 柔和阴影 elevation 5 */
@Composable
fun GlobalCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    val elev = LocalCaiElevation.current
    val shape = RoundedCornerShape(CaiTokens.RadiusCard)
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = elev.cardElevation,
                shape = shape,
                ambientColor = Color.Black.copy(alpha = elev.cardAlpha),
                spotColor = Color.Black.copy(alpha = elev.cardAlpha)
            )
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            ),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(CaiTokens.S16), content = content)
    }
}

/** PrimaryButton：胶囊 + 按压缩放反馈 */
@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    ghost: Boolean = false,
    enabled: Boolean = true
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = tween(durationMillis = 180),
        label = "btnScale"
    )
    val shape = RoundedCornerShape(CaiTokens.RadiusButton)
    if (ghost) {
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.scale(scale),
            shape = shape,
            interactionSource = interaction,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(text, fontWeight = FontWeight.SemiBold)
        }
    } else {
        Button(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.scale(scale),
            shape = shape,
            interactionSource = interaction,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ),
            contentPadding = PaddingValues(horizontal = CaiTokens.S24, vertical = CaiTokens.S12)
        ) {
            Text(text, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = CaiTokens.S8, top = CaiTokens.S8)
    )
}

@Composable
fun CaptionMuted(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
fun AccentTag(text: String, danger: Boolean = false) {
    val bg = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
    val fg = if (danger) Color.White else MaterialTheme.colorScheme.onSecondary
    Box(
        Modifier
            .clip(RoundedCornerShape(CaiTokens.RadiusIcon))
            .background(bg)
            .padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S4)
    ) {
        Text(text, color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
    }
}
