package com.caifenxi.app.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.LotteryConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class DataSyncService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var lastIssue: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationHelper.buildForeground(this, "正在监听开奖…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this, 1001, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(1001, notification)
        }
        job?.cancel()
        job = scope.launch {
            val app = CaiFenXiApplication.instance
            val key = app.configStore.loadPrefs().selectedLotteryKey
            val cfg = LotteryConfig.findByKey(key) ?: LotteryConfig.CATALOG.first()
            while (isActive) {
                try {
                    val latest = app.apiClient.fetchLatest(cfg)
                    if (latest != null && latest.issue != lastIssue) {
                        if (lastIssue != null) {
                            val summary = listOfNotNull(latest.dx, latest.ds, latest.combo)
                                .joinToString(" ") + " " + latest.numbers.take(5).joinToString(",")
                            NotificationHelper.notifyNewDraw(this@DataSyncService, latest.issue, summary)
                        }
                        lastIssue = latest.issue
                    }
                } catch (_: Exception) {
                }
                delay(45_000)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }
}
