package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

private enum class StatsTab { OVERVIEW, PREDS, DRAWS, PLANS }

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val summary = vm.statsSummary.value
    val records = vm.statRecords.value
    val draws = vm.history.value.asReversed()
    val planRows = vm.planRows.value
    var tab by remember { mutableStateOf(StatsTab.OVERVIEW) }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16, bottom = CaiTokens.ScreenBottom),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
    ) {
        item {
            Text("战绩", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted(vm.currentLottery.value.name)
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
            ) {
                listOf(
                    StatsTab.OVERVIEW to "总览",
                    StatsTab.PREDS to "预测记录",
                    StatsTab.PLANS to "计划战绩",
                    StatsTab.DRAWS to "开奖历史"
                ).forEach { (t, lab) ->
                    FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(lab) })
                }
            }
        }

        when (tab) {
            StatsTab.OVERVIEW -> {
                item {
                    GlobalCard {
                        Text("预测战绩总览", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(CaiTokens.S12))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            BigStat("已结算", "${summary.hit + summary.miss}")
                            BigStat("对", "${summary.hit}", Color(0xFF2E7D32))
                            BigStat("错", "${summary.miss}", Color(0xFFC62828))
                            BigStat(
                                "命中率",
                                if (summary.hit + summary.miss == 0) "-" else "${(summary.hitRate * 100).roundToInt()}%",
                                MaterialTheme.colorScheme.secondary
                            )
                        }
                        Spacer(Modifier.height(CaiTokens.S8))
                        val streakText = when {
                            summary.recentStreak > 0 -> "当前连对 ${summary.recentStreak}"
                            summary.recentStreak < 0 -> "当前连错 ${-summary.recentStreak}"
                            else -> "暂无连续"
                        }
                        CaptionMuted("$streakText · 最长连对 ${summary.maxHitStreak} · 最长连错 ${summary.maxMissStreak} · 待开 ${summary.pending}")
                    }
                }
                if (summary.byCategory.isNotEmpty()) {
                    item {
                        GlobalCard {
                            Text("分类命中", fontWeight = FontWeight.Bold)
                            summary.byCategory.forEach { (cat, st) ->
                                val rate = if (st.hit + st.miss == 0) 0 else (st.hit * 100.0 / (st.hit + st.miss)).roundToInt()
                                StatBar(cat, st.hit, st.miss, rate)
                            }
                        }
                    }
                }
                if (summary.byAlgo.isNotEmpty()) {
                    item {
                        GlobalCard {
                            Text("算法命中", fontWeight = FontWeight.Bold)
                            summary.byAlgo.forEach { (algo, st) ->
                                val label = AlgoMode.fromId(algo).label
                                val rate = if (st.hit + st.miss == 0) 0 else (st.hit * 100.0 / (st.hit + st.miss)).roundToInt()
                                StatBar(label, st.hit, st.miss, rate)
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                        PrimaryButton("回填结算", onClick = { vm.backfillStats() }, ghost = true)
                        PrimaryButton("清空战绩", onClick = { vm.clearStats() }, ghost = true)
                        PrimaryButton("刷新", onClick = { vm.loadData() })
                    }
                }
            }
            StatsTab.PREDS -> {
                item {
                    Text("预测记录", fontWeight = FontWeight.Bold)
                    CaptionMuted("共 ${records.size} 条 · 开奖后自动结算对错")
                }
                if (records.isEmpty()) {
                    item { GlobalCard { Text("暂无记录。生成预测后将出现在这里。") } }
                } else {
                    items(records.take(100), key = { it.id }) { r ->
                        val color = when (r.result) {
                            "对" -> Color(0xFF2E7D32)
                            "错" -> Color(0xFFC62828)
                            else -> Color(0xFFF9A825)
                        }
                        GlobalCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier
                                        .background(color, RoundedCornerShape(CaiTokens.RadiusIcon))
                                        .padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S4)
                                ) {
                                    Text(r.result, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(Modifier.width(CaiTokens.S12))
                                Column(Modifier.weight(1f)) {
                                    Text("第 ${r.issue} 期 · ${r.category}", fontWeight = FontWeight.SemiBold)
                                    Text(
                                        buildString {
                                            if (r.candidates.size > 1) {
                                                append("候选「${r.candidates.joinToString(" / ")}」")
                                            } else {
                                                append("预测「${r.lean}」")
                                            }
                                            r.actual?.let { append(" → 开奖「$it」") } ?: append(" · 待开奖")
                                        },
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    CaptionMuted(
                                        "${AlgoMode.fromId(r.algoId).label} · " +
                                            (if (r.matchMode == "any_of") "命中任一即对 · " else "精确匹配 · ") +
                                            "支持度 ${"%.0f".format(r.score * 100)}%"
                                    )
                                }
                            }
                        }
                    }
                }
            }
            StatsTab.PLANS -> {
                item {
                    Text("计划战绩", fontWeight = FontWeight.Bold)
                    CaptionMuted("各计划成功率（点计划页可看详情）")
                }
                if (planRows.isEmpty()) {
                    item { GlobalCard { Text("暂无计划数据，请先加载并生成计划。") } }
                } else {
                    items(planRows, key = { it.first.planId }) { (def, rt) ->
                        GlobalCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text(def.planName, fontWeight = FontWeight.Bold)
                                    CaptionMuted("${def.category} · ${def.algorithm}")
                                }
                                Text(
                                    rt.hitRatePercent,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            Text("对 ${rt.hitCount} / ${rt.sampleCount} · 评分 ${"%.0f".format(rt.score)} · ${rt.status}")
                            if (rt.sampleCount > 0) {
                                androidx.compose.material3.LinearProgressIndicator(
                                    progress = { rt.hitRate.toFloat() },
                                    modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }
            StatsTab.DRAWS -> {
                item { Text("开奖历史", fontWeight = FontWeight.Bold) }
                items(draws.take(50), key = { it.issue }) { row ->
                    GlobalCard {
                        Text("第 ${row.issue} 期 · ${row.drawTime.take(19)}", fontWeight = FontWeight.SemiBold)
                        Text(row.numbers.joinToString(" "), style = MaterialTheme.typography.bodyMedium)
                        val tags = listOfNotNull(row.dx, row.ds, row.combo)
                        if (tags.isNotEmpty()) CaptionMuted(tags.joinToString(" · "))
                    }
                }
            }
        }
        item { Spacer(Modifier.height(CaiTokens.S24)) }
    }
}

@Composable
private fun StatBar(label: String, hit: Int, miss: Int, rate: Int) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text("对$hit 错$miss · $rate%")
        }
        androidx.compose.material3.LinearProgressIndicator(
            progress = { (rate / 100f).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.secondary
        )
    }
}

@Composable
private fun BigStat(label: String, value: String, color: Color = Color.Unspecified) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
        )
        CaptionMuted(label)
    }
}
