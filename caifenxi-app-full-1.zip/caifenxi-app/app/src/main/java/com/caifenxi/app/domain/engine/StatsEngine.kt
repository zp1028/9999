package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.config.StatStore
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.StatRecord

object StatsEngine {

    /** 写入本期预测为「待开」 */
    fun recordPending(store: StatStore, snap: PredictionSnapshot, algoId: String) {
        val key = snap.lotteryKey
        val issue = snap.targetIssue
        fun add(cat: String, lean: String?, score: Double) {
            if (lean.isNullOrBlank() || lean == "-") return
            val id = "$key|$issue|$cat|$algoId"
            // 不覆盖已结算
            val old = store.loadAll(key).find { it.id == id }
            if (old != null && old.result != "待开") return
            store.upsert(
                StatRecord(
                    id = id,
                    lotteryKey = key,
                    issue = issue,
                    category = cat,
                    lean = lean,
                    result = "待开",
                    algoId = algoId,
                    score = score
                )
            )
        }
        add("大小", snap.dx?.direction, snap.dx?.score ?: 0.0)
        add("单双", snap.ds?.direction, snap.ds?.score ?: 0.0)
        add("组合", snap.combo?.direction, snap.combo?.score ?: 0.0)
    }

    /** 用新开奖结算所有待开记录 */
    fun settleWithDraw(store: StatStore, lotteryKey: String, draw: DrawRecord) {
        val pending = store.loadAll(lotteryKey).filter { it.result == "待开" }
        for (r in pending) {
            val issueNum = r.issue.toLongOrNull()
            val drawNum = draw.issue.toLongOrNull()
            if (issueNum != null && drawNum != null && issueNum > drawNum) continue
            // 期号匹配或预测期已开
            if (r.issue != draw.issue && !(issueNum != null && drawNum != null && issueNum <= drawNum)) {
                // 若期号字符串不完全相等，仅当数字可比较且 <= 时结算
                if (r.issue != draw.issue) continue
            }
            val actual = when (r.category) {
                "大小" -> draw.dx
                "单双" -> draw.ds
                "组合" -> draw.combo
                else -> null
            } ?: continue
            val result = if (actual == r.lean) "对" else "错"
            store.upsert(
                r.copy(
                    actual = actual,
                    result = result,
                    settledAt = System.currentTimeMillis()
                )
            )
        }
    }

    /** 历史回填：对已有 history 逐期模拟结算（仅补空） */
    fun backfillFromHistory(
        store: StatStore,
        lotteryKey: String,
        history: List<DrawRecord>
    ) {
        val byIssue = history.associateBy { it.issue }
        val pending = store.loadAll(lotteryKey).filter { it.result == "待开" }
        for (r in pending) {
            val draw = byIssue[r.issue] ?: continue
            val actual = when (r.category) {
                "大小" -> draw.dx
                "单双" -> draw.ds
                "组合" -> draw.combo
                else -> null
            } ?: continue
            store.upsert(
                r.copy(
                    actual = actual,
                    result = if (actual == r.lean) "对" else "错",
                    settledAt = System.currentTimeMillis()
                )
            )
        }
    }
}
