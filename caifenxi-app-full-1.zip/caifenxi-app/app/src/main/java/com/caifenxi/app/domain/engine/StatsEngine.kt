package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.config.StatStore
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.StatRecord

object StatsEngine {

    /**
     * 写入待开记录：
     * - 大小/单双：单结果 exact
     * - 组合：comboList 多候选 any_of（命中任一即对）
     * - 位置：每个位置 TopN 号码 any_of
     */
    fun recordPending(store: StatStore, snap: PredictionSnapshot, algoId: String) {
        val key = snap.lotteryKey
        val issue = snap.targetIssue

        fun upsert(
            cat: String,
            lean: String,
            candidates: List<String>,
            score: Double,
            matchMode: String
        ) {
            if (lean.isBlank() && candidates.isEmpty()) return
            val id = "$key|$issue|$cat|$algoId"
            val old = store.loadAll(key).find { it.id == id }
            if (old != null && old.result != "待开") return
            val main = lean.ifBlank { candidates.firstOrNull() ?: return }
            store.upsert(
                StatRecord(
                    id = id,
                    lotteryKey = key,
                    issue = issue,
                    category = cat,
                    lean = main,
                    candidates = candidates.ifEmpty { listOf(main) },
                    result = "待开",
                    algoId = algoId,
                    score = score,
                    matchMode = matchMode
                )
            )
        }

        snap.dx?.let { upsert("大小", it.direction, listOf(it.direction), it.score, "exact") }
        snap.ds?.let { upsert("单双", it.direction, listOf(it.direction), it.score, "exact") }

        // 组合：按候选列表结算（任一命中即对）
        val comboCands = when {
            snap.comboList.isNotEmpty() -> snap.comboList.map { it.direction }
            snap.combo != null -> listOf(snap.combo.direction)
            else -> emptyList()
        }
        if (comboCands.isNotEmpty()) {
            val score = snap.comboList.firstOrNull()?.score ?: snap.combo?.score ?: 0.0
            upsert(
                cat = "组合",
                lean = comboCands.joinToString("/"),
                candidates = comboCands,
                score = score,
                matchMode = if (comboCands.size > 1) "any_of" else "exact"
            )
        }

        // 位置预测：每位 TopN
        snap.positions.forEach { pos ->
            val nums = pos.topNumbers.map { it.number.toString() }
            if (nums.isEmpty()) return@forEach
            upsert(
                cat = "位置-${pos.positionName}",
                lean = nums.joinToString("/"),
                candidates = nums,
                score = pos.topNumbers.firstOrNull()?.score ?: 0.0,
                matchMode = "any_of"
            )
        }
    }

    fun settleWithDraw(store: StatStore, lotteryKey: String, draw: DrawRecord) {
        val pending = store.loadAll(lotteryKey).filter { it.result == "待开" }
        for (r in pending) {
            if (!issueReached(r.issue, draw.issue)) continue
            val actual = resolveActual(r.category, draw) ?: continue
            val hit = isHit(r, actual)
            store.upsert(
                r.copy(
                    actual = actual,
                    result = if (hit) "对" else "错",
                    settledAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun backfillFromHistory(store: StatStore, lotteryKey: String, history: List<DrawRecord>) {
        val byIssue = history.associateBy { it.issue }
        val pending = store.loadAll(lotteryKey).filter { it.result == "待开" }
        for (r in pending) {
            val draw = byIssue[r.issue] ?: continue
            val actual = resolveActual(r.category, draw) ?: continue
            store.upsert(
                r.copy(
                    actual = actual,
                    result = if (isHit(r, actual)) "对" else "错",
                    settledAt = System.currentTimeMillis()
                )
            )
        }
    }

    private fun issueReached(predIssue: String, drawIssue: String): Boolean {
        if (predIssue == drawIssue) return true
        val a = predIssue.toLongOrNull()
        val b = drawIssue.toLongOrNull()
        return a != null && b != null && a <= b
    }

    private fun resolveActual(category: String, draw: DrawRecord): String? {
        return when {
            category == "大小" -> draw.dx
            category == "单双" -> draw.ds
            category == "组合" -> draw.combo
            category.startsWith("位置-") -> {
                val name = category.removePrefix("位置-")
                val idx = when (name) {
                    "冠军" -> 0
                    "亚军" -> 1
                    else -> Regex("""第(\d+)""").find(name)?.groupValues?.get(1)?.toIntOrNull()?.minus(1)
                } ?: return null
                draw.numbers.getOrNull(idx)?.toString()
            }
            else -> null
        }
    }

    /** exact：lean==actual；any_of：candidates 含 actual */
    private fun isHit(r: StatRecord, actual: String): Boolean {
        return when (r.matchMode) {
            "any_of" -> {
                val cands = r.candidates.ifEmpty {
                    r.lean.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                }
                cands.any { it == actual }
            }
            else -> r.lean == actual || r.candidates.any { it == actual }
        }
    }
}
