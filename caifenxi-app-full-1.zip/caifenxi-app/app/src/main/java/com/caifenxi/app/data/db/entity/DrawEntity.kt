package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "draws",
    indices = [Index(value = ["lotteryKey", "issue"], unique = true)]
)
data class DrawEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lotteryKey: String,
    val issue: String,
    val drawTime: String,
    val numbersJson: String,   // JSON array of ints
    val sum: Int? = null,
    val dx: String? = null,
    val ds: String? = null,
    val combo: String? = null,
    val extra: Int? = null,
    val nextIssue: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
