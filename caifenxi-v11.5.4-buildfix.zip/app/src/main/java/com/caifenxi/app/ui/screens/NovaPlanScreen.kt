package com.caifenxi.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.CustomPlan
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.NovaPlanWorkbench
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Nova 新计划池：完整可视化入口。
 * 重点解决：计划打不开、没有排行榜/胜率、没有大小单双/组合/数字/位置分类、
 * 没有一期/二期/三期周期、无法筛选、无法切换到预测/驾驶舱的问题。
 */
@Composable
fun NovaPlanScreen(vm: MainViewModel) {
    var page by remember { mutableStateOf("总览") }
    var playType by remember { mutableStateOf("全部") }
    var group by remember { mutableStateOf("全部") }
    var position by remember { mutableStateOf("全部") }
    var cycle by remember { mutableStateOf(1) }
    var search by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var backtestPeriods by remember { mutableStateOf(200) }
    var arenaRows by remember { mutableStateOf<List<NovaPlanWorkbench.ArenaRow>>(emptyList()) }
    var selectedReport by remember { mutableStateOf<NovaPlanAnalytics.BacktestReport?>(null) }
    var running by remember { mutableStateOf(false) }
    var explanation by remember { mutableStateOf<NovaPlanWorkbench.Explanation?>(null) }
    var ensemble by remember { mutableStateOf<NovaPlanWorkbench.Ensemble?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var customName by remember { mutableStateOf("") }
    var customTemplateId by remember { mutableStateOf(NovaPlanPool.ALL.firstOrNull()?.planId.orEmpty()) }
    var customWindow by remember { mutableStateOf(30) }
    var customCycle by remember { mutableStateOf(1) }
    val scope = rememberCoroutineScope()
    val history = vm.history.value
    val cockpitId = vm.prefs.value.cockpitPlanId
    val novaCustomPlans = vm.customPlans.value.map { it.toDefinition() }.filter { it.planId.startsWith("NOVA-CUSTOM-") }
    val allNovaPlans = (NovaPlanPool.ALL + novaCustomPlans).distinctBy { it.planId }
    val allGroups = (NovaPlanPool.GROUPS + novaCustomPlans.map { it.category.removePrefix("Nova-") }).distinct()
    val filtered = allNovaPlans.filter { p ->
        (playType == "全部" || p.playType == playType) &&
            (group == "全部" || p.category == "Nova-$group") &&
            (position == "全部" || (p.positionIndex >= 0 && NovaPlanPool.meta(p).positionLabel == position)) &&
            (search.isBlank() || p.planId.contains(search, true) || p.planName.contains(search, true))
    }
    val selected = filtered.firstOrNull { it.planId == selectedId }
        ?: NovaPlanPool.find(selectedId.orEmpty())
        ?: filtered.firstOrNull()

    LaunchedEffect(page, history.size, backtestPeriods, allNovaPlans.size) {
        if (page == "排行榜" && history.size >= 10) {
            running = true
            arenaRows = withContext(Dispatchers.Default) { NovaPlanWorkbench.arena(history, backtestPeriods, allNovaPlans) }
            running = false
        }
    }

    if (showCreateDialog) {
        val template = allNovaPlans.firstOrNull { it.planId == customTemplateId } ?: NovaPlanPool.ALL.first()
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("新增 Nova 计划", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(customName, { customName = it }, label = { Text("计划名称") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("复制模板：${template.planName}", fontWeight = FontWeight.SemiBold)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        allNovaPlans.take(30).forEach { p ->
                            FilterChip(selected = p.planId == customTemplateId, onClick = { customTemplateId = p.planId }, label = { Text(p.planName.take(8), fontSize = 10.sp) })
                        }
                    }
                    Text("玩法：${template.playType}${if (template.positionIndex >= 0) " · ${NovaPlanPool.meta(template).positionLabel}" else ""}")
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf(10,20,30,50,100,200,500).forEach { n -> FilterChip(selected = customWindow == n, onClick = { customWindow = n }, label = { Text("${n}期") }) }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        NovaPlanPool.CYCLE_OPTIONS.forEach { n -> FilterChip(selected = customCycle == n, onClick = { customCycle = n }, label = { Text("${n}期") }) }
                    }
                    CaptionMuted("新增计划会持久化到本彩种，立即进入 Nova 计划库、战绩、排行榜、回测和驾驶舱选择。")
                }
            },
            confirmButton = {
                Button(onClick = {
                    val name = customName.trim().ifBlank { "${template.planName}·自定义" }
                    val id = "NOVA-CUSTOM-${System.currentTimeMillis()}"
                    val encoded = "NovaCustom|${template.playType}|${template.positionIndex}|${template.category.removePrefix("Nova-")}"
                    vm.saveCustomPlan(CustomPlan(
                        planId = id, lotteryKey = vm.currentLottery.value.key, planName = name, category = encoded,
                        algorithm = template.algorithm, window = customWindow, cyclePeriods = customCycle,
                        outputFormat = template.outputFormat.name, hitCriteria = template.hitCriteria.name, enabled = true, participateConsensus = true
                    ))
                    customName = ""
                    customWindow = 30
                    customCycle = 1
                    showCreateDialog = false
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("取消") } }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
    ) {
        item {
            Text("新计划池", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("NovaPlan ${NovaPlanPool.VERSION} · 独立新算法池，但预测、驾驶舱、挂机、悬浮窗统一互通")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("总览", "计划库", "排行榜", "战绩", "回测", "计划组合").forEach { p ->
                    FilterChip(selected = page == p, onClick = { page = p }, label = { Text(p) })
                }
            }
        }

        item {
            GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                Text("统一来源", fontWeight = FontWeight.Bold)
                Text(if (cockpitId.isBlank()) "当前：算法/计划池自动模式" else "当前驾驶舱：$cockpitId · 周期${vm.prefs.value.cockpitPlanCyclePeriods}期")
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(
                        if (selected != null) "将当前计划切到预测/驾驶舱" else "请选择计划",
                        onClick = { selected?.let { vm.selectCockpitPlan(it.planId, cycle) } },
                        enabled = selected != null,
                        modifier = Modifier.weight(1f)
                    )
                    PrimaryButton("恢复自动", onClick = { vm.selectCockpitPlan("") }, ghost = true, modifier = Modifier.weight(1f))
                }
            }
        }

        item {
            GlobalCard {
                Text("计划筛选", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    singleLine = true,
                    label = { Text("搜索计划名称 / ID") }
                )
                FilterRow("玩法", listOf("全部") + NovaPlanPool.PLAY_TYPES, playType) { playType = it }
                FilterRow("算法组", listOf("全部") + allGroups, group) { group = it }
                FilterRow("位置", listOf("全部", "冠军", "亚军", "第3", "第4", "第5", "第6", "第7", "第8", "第9", "第10"), position) { position = it }
                FilterRow("执行周期", NovaPlanPool.CYCLE_OPTIONS.map { "${it}期" }, "${cycle}期") { cycle = it.removeSuffix("期").toInt() }
                CaptionMuted("当前筛选 ${filtered.size} 个计划 · 周期只控制本次执行/追踪窗口，不改变历史回测数据")
            }
        }

        when (page) {
            "总览" -> renderOverview(this, history, filtered, selected, backtestPeriods) { page = it }
            "计划库" -> renderPlanLibrary(this, history, vm.planHistory.value, filtered, selected, cycle, vm.prefs.value, onSelect = { selectedId = it }, onExplain = { p -> explanation = NovaPlanWorkbench.explain(p, history) }, onAdd = { showCreateDialog = true })
            "排行榜" -> {
                item {
                    ArenaHeader(
                        periods = backtestPeriods,
                        onPeriods = { backtestPeriods = it },
                        running = running,
                        onRun = {
                            scope.launch {
                                running = true
                                arenaRows = withContext(Dispatchers.Default) { NovaPlanWorkbench.arena(history, backtestPeriods, allNovaPlans) }
                                running = false
                            }
                        }
                    )
                }
                items(arenaRows.filter { filtered.any { p -> p.planId == it.plan.planId } }.take(100), key = { it.plan.planId }) { row ->
                    RankingRow(row, row.plan.planId == selected?.planId) { selectedId = row.plan.planId }
                }
                if (arenaRows.isEmpty()) item { CaptionMuted("点击“开始排行榜回测”生成胜率、连中、连错、Edge、稳定性排行") }
            }
            "战绩" -> renderRecords(this, history, vm.planHistory.value, selected, cycle)
            "回测" -> {
                item {
                    ArenaHeader(
                        periods = backtestPeriods,
                        onPeriods = { backtestPeriods = it },
                        running = running,
                        onRun = {
                            selected?.let { plan ->
                                scope.launch {
                                    running = true
                                    selectedReport = withContext(Dispatchers.Default) { NovaPlanAnalytics.backtest(plan, history, backtestPeriods) }
                                    running = false
                                }
                            }
                        }
                    )
                }
                selected?.let { plan -> item { BacktestCard(plan, selectedReport) } }
            }
            "计划组合" -> {
                item {
                    GlobalCard {
                        Text("NovaPlan Ensemble", fontWeight = FontWeight.Bold)
                        CaptionMuted("按排行榜评分生成低相关计划组合；组合仍需单独回测")
                        PrimaryButton("生成组合", onClick = { ensemble = NovaPlanWorkbench.diverseEnsemble(arenaRows) }, modifier = Modifier.fillMaxWidth())
                        ensemble?.let { e ->
                            Spacer(Modifier.height(8.dp))
                            e.planIds.forEachIndexed { index, id -> Text("${index + 1}. $id · 权重 ${"%.1f".format((e.weights[id] ?: 0.0) * 100)}%") }
                        }
                    }
                }
            }
        }

        selected?.let { plan ->
            item {
                PlanDetailCard(
                    plan = plan,
                    history = history,
                    records = vm.planHistory.value,
                    prefs = vm.prefs.value,
                    cycle = cycle,
                    runtime = vm.planVM.runtimeForPlan(plan.planId),
                    currentPrediction = vm.currentPredictions.value.firstOrNull { it.planId == plan.planId && it.targetIssue == vm.planVM.planTargetIssue.value },
                    selected = plan.planId == cockpitId,
                    onUse = { vm.selectCockpitPlan(plan.planId, cycle) },
                    onExplain = { explanation = NovaPlanWorkbench.explain(plan, history) },
                    onViewRecords = { page = "战绩" }
                )
            }
        }
        explanation?.let { e ->
            item {
                GlobalCard(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                    Text("计划解释", fontWeight = FontWeight.Bold)
                    Text(e.title, style = MaterialTheme.typography.titleMedium)
                    CaptionMuted("${e.planId} · 输入 ${e.inputWindow}期 · 输出 ${e.output}")
                    e.factors.forEach { (name, value) -> Text("$name · ${(value * 100).toInt()}/100") }
                }
            }
        }
    }
}

@Composable
private fun FilterRow(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Text("$title", modifier = Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        options.forEach { value -> FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(value, fontSize = 11.sp) }) }
    }
}

private fun renderOverview(
    scope: LazyListScope,
    history: List<DrawRecord>,
    plans: List<PlanDefinition>,
    selected: PlanDefinition?,
    periods: Int,
    go: (String) -> Unit
) {
    scope.item {
        GlobalCard {
            Text("新计划池驾驶舱", fontWeight = FontWeight.Bold)
            Text("${plans.size} 个计划 · 回测窗口 ${periods} 期 · 支持大小/单双/组合/数字/位置")
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SummaryBox("大小", plans.count { it.playType == "大小" }.toString(), Modifier.weight(1f))
                SummaryBox("单双", plans.count { it.playType == "单双" }.toString(), Modifier.weight(1f))
                SummaryBox("组合", plans.count { it.playType == "组合" }.toString(), Modifier.weight(1f))
                SummaryBox("数字", plans.count { it.playType == "数字" }.toString(), Modifier.weight(1f))
                SummaryBox("位置", plans.count { it.playType == "位置" }.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            CaptionMuted("竞品常见的“计划→周期→结果→胜率→排行”链路已经统一到 Nova；历史开奖与回测数据继续由原数据层提供。")
            if (selected != null) Text("当前计划：${selected.planName} · ${selected.playType}${if (selected.positionIndex >= 0) " · ${NovaPlanPool.meta(selected).positionLabel}" else ""}")
            Spacer(Modifier.height(6.dp))
            PrimaryButton("打开计划库", onClick = { go("计划库") }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SummaryBox(label: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 10.sp)
    }
}

private fun renderPlanLibrary(
    scope: LazyListScope,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    plans: List<PlanDefinition>,
    selected: PlanDefinition?,
    cycle: Int,
    prefs: com.caifenxi.app.domain.model.UserPrefs,
    onSelect: (String) -> Unit,
    onExplain: (PlanDefinition) -> Unit,
    onAdd: () -> Unit
) {
    scope.item {
        GlobalCard {
            Text("计划记录", fontWeight = FontWeight.Bold)
            CaptionMuted("按竞品式表格查看：计划周期 / 最终截止 / 计划结果 / 推荐号；点击任意计划即可打开详情、回测和战绩。")
            PrimaryButton("＋ 新增计划", onClick = onAdd, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("计划周期", fontWeight = FontWeight.Bold)
                Text("最终截止", fontWeight = FontWeight.Bold)
                Text("计划结果", fontWeight = FontWeight.Bold)
                Text("推荐号", fontWeight = FontWeight.Bold)
            }
        }
    }
    // 不使用 LazyListScope.items(List) 扩展，避免不同 Compose 版本下的泛型/作用域解析问题。
    // 所有计划仍作为独立的 LazyList item 渲染，不改变原有 UI 和交互。
    plans.forEach { plan ->
        scope.item {
            val outputCount = when (plan.playType) {
                "组合" -> prefs.comboPredCount
                "数字" -> prefs.zuheTopN
                "位置" -> prefs.positionTopN
                else -> 1
            }
            val result = NovaPlanAnalytics.predict(plan.copy(cyclePeriods = cycle), history, outputCount)
            GlobalCard(containerColor = if (selected?.planId == plan.planId) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1.1f)) {
                        Text("第1/$cycle期", fontWeight = FontWeight.SemiBold)
                        Text("执行周期", fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("窗口${plan.window}期")
                        Text("截止${history.lastOrNull()?.issue ?: "-"}", fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1.2f)) {
                        val latest = records.firstOrNull { record -> record.planId == plan.planId }
                        Text(if (latest?.settled == true) if (latest.hit == true) "中" else "错" else "待开")
                        Text(plan.playType, fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1.6f)) {
                        Text(result?.output ?: "—", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(selected = selected?.planId == plan.planId, onClick = { onSelect(plan.planId) }, label = { Text("查看") })
                            FilterChip(selected = false, onClick = { onExplain(plan) }, label = { Text("解释") })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RankingRow(row: NovaPlanWorkbench.ArenaRow, selected: Boolean, onSelect: () -> Unit) {
    GlobalCard(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(row.plan.planName, fontWeight = FontWeight.SemiBold)
                CaptionMuted("${row.plan.planId} · ${row.plan.playType}${if (row.plan.positionIndex >= 0) " · ${NovaPlanPool.meta(row.plan).positionLabel}" else ""}")
                Text("胜率 ${(row.report.hitRate * 100).toInt()}% · 样本 ${row.report.periods} · 连中 ${row.report.maxHitStreak} · 连错 ${row.report.maxMissStreak}")
                Text("Edge ${(row.report.edge * 100).toInt()}% · 稳定性 ${(row.report.stability * 100).toInt()}% · ${row.lifecycle}", fontSize = 11.sp)
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("${row.rankScore.toInt()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TextButton(onClick = onSelect) { Text("查看") }
            }
        }
    }
}

private fun renderRecords(
    scope: LazyListScope,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    selected: PlanDefinition?,
    cycle: Int
) {
    val rows = if (selected == null) records else records.filter { it.planId == selected.planId }
    scope.item {
        GlobalCard {
            Text("计划战绩", fontWeight = FontWeight.Bold)
            CaptionMuted("只统计已结算预测；完整数据不限制500期，当前页面按最近记录分页展示。")
            Text("${selected?.planName ?: "全部计划"} · 周期 ${cycle}期 · 记录 ${rows.size}")
        }
    }
    scope.items(rows.take(200), key = { "${it.planId}-${it.targetIssue}-${it.cutoffIssue}" }) { r ->
        GlobalCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("${r.targetIssue} · ${r.planName}", fontWeight = FontWeight.SemiBold)
                    Text("${r.category} · 预测 ${r.output}", fontSize = 12.sp)
                    Text(if (r.settled) "已结算 · ${if (r.hit == true) "中" else "错"}" else "待开", fontSize = 12.sp)
                }
                Text(if (r.hit == true) "中" else if (r.settled) "错" else "?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun BacktestCard(plan: PlanDefinition, report: NovaPlanAnalytics.BacktestReport?) {
    GlobalCard {
        Text("${plan.planName} · 回测结果", fontWeight = FontWeight.Bold)
        if (report == null) CaptionMuted("正在计算或历史样本不足") else {
            Text("样本 ${report.periods} · 对 ${report.hits} · 错 ${report.misses}")
            Text("胜率 ${(report.hitRate * 100).toInt()}% · 随机基准 ${(report.randomBaseline * 100).toInt()}% · Edge ${(report.edge * 100).toInt()}%")
            Text("最大连中 ${report.maxHitStreak} · 最大连错 ${report.maxMissStreak} · 稳定性 ${(report.stability * 100).toInt()}%")
        }
    }
}

@Composable
private fun PlanDetailCard(
    plan: PlanDefinition,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    prefs: com.caifenxi.app.domain.model.UserPrefs,
    cycle: Int,
    runtime: com.caifenxi.app.domain.model.PlanRuntime,
    currentPrediction: PlanPredictionRecord?,
    selected: Boolean,
    onUse: () -> Unit,
    onExplain: () -> Unit,
    onViewRecords: () -> Unit
) {
    val count = when (plan.playType) {
        "组合" -> prefs.comboPredCount
        "数字" -> prefs.zuheTopN
        "位置" -> prefs.positionTopN
        else -> 1
    }
    val result = NovaPlanAnalytics.predict(plan.copy(cyclePeriods = cycle), history, count)
    val historyRows = records.filter { it.planId == plan.planId }.take(10)
    GlobalCard(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
        Text("计划详情 · ${plan.planName}", fontWeight = FontWeight.Bold)
        CaptionMuted("${plan.planId} · ${plan.algorithm} · ${plan.playType}${if (plan.positionIndex >= 0) " · ${NovaPlanPool.meta(plan).positionLabel}" else ""} · 窗口${plan.window}期 · 执行${cycle}期")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            SummaryBox("胜率", runtime.hitRatePercent, Modifier.weight(1f))
            SummaryBox("样本", runtime.sampleCount.toString(), Modifier.weight(1f))
            SummaryBox("连中", runtime.maxConsecutiveHit.toString(), Modifier.weight(1f))
            SummaryBox("连错", runtime.maxConsecutiveMiss.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Text("当期预测：${currentPrediction?.output ?: result?.output ?: "暂无"}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        CaptionMuted("目标期 ${currentPrediction?.targetIssue ?: "-"} · 输出数量按设置：组合${prefs.comboPredCount} / 号码${prefs.zuheTopN} / 位置${prefs.positionTopN}")
        if (historyRows.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("最近战绩", fontWeight = FontWeight.SemiBold)
            historyRows.forEach { r -> Text("${r.targetIssue} · ${r.output} · ${if (!r.settled) "待开" else if (r.hit == true) "中" else "错"}", fontSize = 12.sp) }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PrimaryButton(if (selected) "已用于驾驶舱" else "用于驾驶舱", onClick = onUse, modifier = Modifier.weight(1f), enabled = !selected)
            PrimaryButton("全部战绩", onClick = onViewRecords, ghost = true, modifier = Modifier.weight(1f))
            PrimaryButton("解释", onClick = onExplain, ghost = true, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun ArenaHeader(periods: Int, onPeriods: (Int) -> Unit, running: Boolean, onRun: () -> Unit) {
    GlobalCard {
        Text("排行榜 / 回测窗口", fontWeight = FontWeight.Bold)
        CaptionMuted("回测期数手动调整；支持20～10000期。历史战绩和回测窗口不再固定500期。")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onPeriods((periods - 50).coerceAtLeast(20)) }) { Text("−") }
            Text("${periods}期", modifier = Modifier.padding(top = 12.dp))
            OutlinedButton(onClick = { onPeriods((periods + 50).coerceAtMost(10000)) }) { Text("+") }
        }
        PrimaryButton(if (running) "计算中…" else "开始回测 / 更新排行榜", onClick = onRun, modifier = Modifier.fillMaxWidth(), enabled = !running)
    }
}
