package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition

/** NovaPlan v1.2: 实例生成、版本和生命周期元数据。 */
object NovaPlanRegistry {
    data class VersionedPlan(val definition: PlanDefinition, val version: Int = 1, val createdAt: Long = System.currentTimeMillis(), val enabled: Boolean = true)

    private val versions = mutableMapOf<String, MutableList<VersionedPlan>>()

    @Synchronized
    fun register(plan: PlanDefinition): VersionedPlan {
        val next = (versions[plan.planId]?.maxOfOrNull { it.version } ?: 0) + 1
        val item = VersionedPlan(plan, next)
        versions.getOrPut(plan.planId) { mutableListOf() }.add(item)
        return item
    }

    @Synchronized
    fun version(planId: String, version: Int? = null): VersionedPlan? {
        val list = versions[planId] ?: return null
        return if (version == null) list.maxByOrNull { it.version } else list.firstOrNull { it.version == version }
    }

    @Synchronized
    fun generate(template: PlanDefinition, windows: List<Int>, cycles: List<Int>): List<VersionedPlan> =
        windows.distinct().filter { it >= 5 }.flatMap { w ->
            cycles.distinct().filter { it >= 1 }.map { c ->
                register(template.copy(planId = "${template.planId}-$w-$c", window = w, cyclePeriods = c))
            }
        }

    @Synchronized
    fun allVersions(): List<VersionedPlan> = versions.values.flatten().toList()
}
