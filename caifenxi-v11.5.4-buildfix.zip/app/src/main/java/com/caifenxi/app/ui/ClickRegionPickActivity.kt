package com.caifenxi.app.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.util.RuntimeLog
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 全屏自由框选点击区域。
 * 手指拖出矩形 → 点「确认」写入 UserPrefs（相对屏幕 0～1）。
 */
class ClickRegionPickActivity : ComponentActivity() {

    private lateinit var pickView: RegionPickView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT

        val root = FrameLayout(this)
        pickView = RegionPickView(this)
        // 预填当前区域
        try {
            val p = CaiFenXiApplication.instance.configStore.loadPrefs()
            pickView.setNormalized(
                p.autoClickRegionLeft,
                p.autoClickRegionTop,
                p.autoClickRegionRight,
                p.autoClickRegionBottom
            )
        } catch (_: Exception) {
        }
        root.addView(
            pickView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)

        pickView.onConfirm = { l, t, r, b ->
            try {
                val store = CaiFenXiApplication.instance.configStore
                val prefs = store.loadPrefs()
                store.savePrefs(
                    prefs.copy(
                        autoClickRegionEnabled = true,
                        autoClickRegionLeft = l,
                        autoClickRegionTop = t,
                        autoClickRegionRight = r,
                        autoClickRegionBottom = b
                    )
                )
                RuntimeLog.info(
                    "AutoBet",
                    "框选区域已保存 L=${pct(l)} T=${pct(t)} R=${pct(r)} B=${pct(b)}"
                )
            } catch (e: Exception) {
                RuntimeLog.warn("AutoBet", "保存框选区域失败: ${e.message}")
            }
            finish()
        }
        pickView.onCancel = { finish() }
    }

    private fun pct(v: Float) = "${(v * 100).toInt()}%"

    private class RegionPickView(context: android.content.Context) : View(context) {
        var onConfirm: ((Float, Float, Float, Float) -> Unit)? = null
        var onCancel: (() -> Unit)? = null

        private val dimPaint = Paint().apply {
            color = Color.argb(140, 0, 0, 0)
            style = Paint.Style.FILL
        }
        private val boxPaint = Paint().apply {
            color = Color.argb(80, 76, 175, 80)
            style = Paint.Style.FILL
        }
        private val borderPaint = Paint().apply {
            color = Color.rgb(76, 175, 80)
            style = Paint.Style.STROKE
            strokeWidth = 4f
            isAntiAlias = true
        }
        private val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 40f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        private val btnPaint = Paint().apply {
            color = Color.rgb(46, 125, 50)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val btnTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 36f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        private var startX = 0f
        private var startY = 0f
        private var curX = 0f
        private var curY = 0f
        private var dragging = false
        private var hasBox = false

        private val box = RectF()
        private val confirmBtn = RectF()
        private val cancelBtn = RectF()
        private val fullBtn = RectF()

        fun setNormalized(l: Float, t: Float, r: Float, b: Float) {
            post {
                val w = width.toFloat().coerceAtLeast(1f)
                val h = height.toFloat().coerceAtLeast(1f)
                box.set(l * w, t * h, r * w, b * h)
                hasBox = box.width() > 20 && box.height() > 20
                invalidate()
            }
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawRect(0f, 0f, w, h, dimPaint)

            if (hasBox || dragging) {
                val rect = if (dragging) {
                    RectF(
                        min(startX, curX),
                        min(startY, curY),
                        max(startX, curX),
                        max(startY, curY)
                    )
                } else box
                // 挖空高亮：先画绿半透明再描边
                canvas.drawRect(rect, boxPaint)
                canvas.drawRect(rect, borderPaint)
                val info = "区域 ${rect.width().toInt()}×${rect.height().toInt()}"
                canvas.drawText(info, rect.centerX(), max(48f, rect.top - 16f), textPaint)
            } else {
                canvas.drawText("在屏幕上拖动框选点击范围（可全屏）", w / 2f, h / 2f - 80f, textPaint)
            }

            // 底部按钮
            val btnH = 120f
            val gap = 24f
            val btnW = (w - gap * 4) / 3f
            val top = h - btnH - 48f
            cancelBtn.set(gap, top, gap + btnW, top + btnH)
            fullBtn.set(gap * 2 + btnW, top, gap * 2 + btnW * 2, top + btnH)
            confirmBtn.set(gap * 3 + btnW * 2, top, w - gap, top + btnH)

            drawBtn(canvas, cancelBtn, "取消", Color.rgb(90, 90, 90))
            drawBtn(canvas, fullBtn, "全屏", Color.rgb(33, 150, 243))
            drawBtn(canvas, confirmBtn, "确认", Color.rgb(46, 125, 50))
        }

        private fun drawBtn(canvas: Canvas, r: RectF, label: String, color: Int) {
            btnPaint.color = color
            canvas.drawRoundRect(r, 16f, 16f, btnPaint)
            canvas.drawText(label, r.centerX(), r.centerY() + 12f, btnTextPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val x = event.x
            val y = event.y
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (confirmBtn.contains(x, y) || cancelBtn.contains(x, y) || fullBtn.contains(x, y)) {
                        return true
                    }
                    // 避开底部按钮区开始拖
                    if (y > confirmBtn.top - 8f) return true
                    startX = x
                    startY = y
                    curX = x
                    curY = y
                    dragging = true
                    hasBox = false
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        curX = x
                        curY = y
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (confirmBtn.contains(x, y)) {
                        commitBox(false)
                        return true
                    }
                    if (cancelBtn.contains(x, y)) {
                        onCancel?.invoke()
                        return true
                    }
                    if (fullBtn.contains(x, y)) {
                        box.set(0f, 0f, width.toFloat(), height.toFloat())
                        hasBox = true
                        dragging = false
                        invalidate()
                        return true
                    }
                    if (dragging) {
                        val l = min(startX, curX)
                        val t = min(startY, curY)
                        val r = max(startX, curX)
                        val b = max(startY, curY)
                        if (abs(r - l) > 24 && abs(b - t) > 24) {
                            box.set(l, t, r, b)
                            hasBox = true
                        }
                        dragging = false
                        invalidate()
                    }
                    return true
                }
            }
            return super.onTouchEvent(event)
        }

        private fun commitBox(full: Boolean) {
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            if (full) {
                onConfirm?.invoke(0f, 0f, 1f, 1f)
                return
            }
            if (!hasBox && !dragging) {
                // 未框选则按全屏
                onConfirm?.invoke(0f, 0f, 1f, 1f)
                return
            }
            val rect = if (dragging) {
                RectF(min(startX, curX), min(startY, curY), max(startX, curX), max(startY, curY))
            } else box
            val l = (rect.left / w).coerceIn(0f, 1f)
            val t = (rect.top / h).coerceIn(0f, 1f)
            val r = (rect.right / w).coerceIn(0f, 1f)
            val b = (rect.bottom / h).coerceIn(0f, 1f)
            if (r - l < 0.05f || b - t < 0.05f) {
                onConfirm?.invoke(0f, 0f, 1f, 1f)
            } else {
                onConfirm?.invoke(l, t, r, b)
            }
        }
    }
}
