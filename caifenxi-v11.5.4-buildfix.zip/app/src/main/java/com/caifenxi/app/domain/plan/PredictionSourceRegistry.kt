package com.caifenxi.app.domain.plan

/**
 * Keeps the currently selected prediction source in one place.
 * UI/Service layers can bind to this later without coupling the plan engine
 * to the floating-window/accessibility implementation.
 */
class PredictionSourceRegistry {
    @Volatile
    private var selection: PredictionSourceSelection =
        PredictionSourceSelection()

    fun get(): PredictionSourceSelection = selection

    @Synchronized
    fun set(value: PredictionSourceSelection) {
        require(value.isValid()) { "SPECIFIC_PLAN requires a non-empty planId" }
        selection = value
    }

    @Synchronized
    fun selectSpecificPlan(
        planId: String,
        planVersion: String? = null,
        analysisWindow: Int? = null,
        cyclePeriods: Int? = null
    ) {
        set(
            PredictionSourceSelection(
                type = PredictionSourceType.SPECIFIC_PLAN,
                planId = planId,
                planVersion = planVersion,
                analysisWindow = analysisWindow,
                cyclePeriods = cyclePeriods
            )
        )
    }

    fun selectCockpit() = set(
        PredictionSourceSelection(type = PredictionSourceType.COCKPIT)
    )

    fun selectAutoBest() = set(
        PredictionSourceSelection(type = PredictionSourceType.AUTO_BEST)
    )

    fun selectConsensus() = set(
        PredictionSourceSelection(type = PredictionSourceType.CONSENSUS)
    )
}
