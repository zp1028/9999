package com.caifenxi.app.domain.plan

/**
 * v10.3: precise prediction-source selection.
 *
 * A source can point to the exact plan ID rather than only an algorithm category.
 * This object is deliberately dependency-free so it can be adopted by existing
 * ViewModels/services without changing their current APIs.
 */
enum class PredictionSourceType {
    COCKPIT,
    SPECIFIC_PLAN,
    AUTO_BEST,
    CONSENSUS
}

data class PredictionSourceSelection(
    val type: PredictionSourceType = PredictionSourceType.COCKPIT,
    val planId: String? = null,
    val planVersion: String? = null,
    val analysisWindow: Int? = null,
    val cyclePeriods: Int? = null
) {
    fun isValid(): Boolean =
        type != PredictionSourceType.SPECIFIC_PLAN || !planId.isNullOrBlank()
}
