# 彩析 (CaiFenXi) — Android 原生版

Kotlin + Jetpack Compose，模仿 quant-app 结构，对接原网页版 `cai_fused` 的数据源与核心能力。

## 功能（Phase 1–5）

- 多彩种开奖拉取（api16868 / api68）+ Room 缓存
- 大小 / 单双 / 组合预测（频率 + EWMA + 一阶转移）
- 号码热度与位置 TopN
- 计划池（PLAN-POOL 精简版）回测、评分、权重、共识
- 首页策略驾驶舱
- 设置：档位 / 自动刷新 / 深色 / AI Key / 后台监听
- 前台服务 + 新开奖通知

## 打开

Android Studio 打开本目录 → Sync → Run。

若缺少 Gradle Wrapper：`gradle wrapper --gradle-version 8.9`

## 包名

`com.caifenxi.app`

## 说明

继续使用现有第三方开奖 API；产品定位与原文案一致。  
「共识/评分」为模型加权支持度，不是真实中奖概率。仅供学习研究，请理性购彩。
