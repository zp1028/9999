package com.caifenxi.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RedPrimary = Color(0xFF8B0000)
private val CreamBg = Color(0xFFFDF8EF)
private val DarkBg = Color(0xFF1A1A1A)

private val LightColors = lightColorScheme(
    primary = RedPrimary,
    onPrimary = Color.White,
    secondary = Color(0xFFB8860B),
    background = CreamBg,
    surface = Color.White,
    onBackground = Color(0xFF1C1B1F),
    onSurface = Color(0xFF1C1B1F),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFE57373),
    onPrimary = Color.Black,
    secondary = Color(0xFFFFD54F),
    background = DarkBg,
    surface = Color(0xFF2C2C2C),
    onBackground = Color(0xFFE8E8E8),
    onSurface = Color(0xFFE8E8E8),
)

@Composable
fun CaiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
