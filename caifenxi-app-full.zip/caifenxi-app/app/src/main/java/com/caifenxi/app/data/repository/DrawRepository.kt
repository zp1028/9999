package com.caifenxi.app.data.repository

import com.caifenxi.app.data.api.LotteryApiClient
import com.caifenxi.app.data.config.ConfigStore
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.entity.DrawEntity
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class DrawRepository(
    private val api: LotteryApiClient,
    private val drawDao: DrawDao,
    private val configStore: ConfigStore
) {
    private val json = Json { encodeDefaults = true }

    suspend fun fetchAndCacheHistory(config: LotteryConfig, days: Int = 3): List<DrawRecord> {
        val remote = api.fetchHistory(config, days)
        if (remote.isNotEmpty()) {
            val entities = remote.map { it.toEntity() }
            drawDao.upsertAll(entities)
        }
        // 以本地为准返回完整列表
        val local = drawDao.getByLottery(config.key).map { it.toDomain() }
        return if (local.isNotEmpty()) local else remote
    }

    suspend fun getLocalHistory(key: String): List<DrawRecord> =
        drawDao.getByLottery(key).map { it.toDomain() }

    private fun DrawRecord.toEntity() = DrawEntity(
        lotteryKey = lotteryKey,
        issue = issue,
        drawTime = drawTime,
        numbersJson = json.encodeToString(numbers),
        sum = sum,
        dx = dx,
        ds = ds,
        combo = combo,
        extra = extra,
        nextIssue = nextIssue
    )

    private fun DrawEntity.toDomain(): DrawRecord {
        val nums = try {
            json.decodeFromString<List<Int>>(numbersJson)
        } catch (_: Exception) {
            emptyList()
        }
        return DrawRecord(
            lotteryKey = lotteryKey,
            issue = issue,
            drawTime = drawTime,
            numbers = nums,
            sum = sum,
            dx = dx,
            ds = ds,
            combo = combo,
            extra = extra,
            nextIssue = nextIssue
        )
    }
}
