package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.domain.plan.PlanEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val repo get() = app.drawRepository
    private val configStore get() = app.configStore
    private val planEngine = PlanEngine()

    val prefs = mutableStateOf(configStore.loadPrefs())
    val currentLottery = mutableStateOf(
        LotteryConfig.findByKey(prefs.value.selectedLotteryKey) ?: LotteryConfig.CATALOG.first()
    )
    val history = mutableStateOf<List<DrawRecord>>(emptyList())
    val latest = mutableStateOf<DrawRecord?>(null)
    val loading = mutableStateOf(false)
    val errorMessage = mutableStateOf<String?>(null)
    val prediction = mutableStateOf<PredictionSnapshot?>(null)
    val consensus = mutableStateOf<List<ModelConsensus>>(emptyList())
    val planRows = mutableStateOf<List<Pair<PlanDefinition, PlanRuntime>>>(emptyList())
    val backtestRunning = mutableStateOf(false)
    val statusText = mutableStateOf("")

    private var refreshJob: Job? = null

    init {
        loadData()
        startAutoRefreshIfNeeded()
    }

    fun selectLottery(config: LotteryConfig) {
        currentLottery.value = config
        val p = prefs.value.copy(selectedLotteryKey = config.key)
        prefs.value = p
        configStore.savePrefs(p)
        loadData()
    }

    fun updatePrefs(transform: (UserPrefs) -> UserPrefs) {
        val p = transform(prefs.value)
        prefs.value = p
        configStore.savePrefs(p)
        if (p.autoRefresh) startAutoRefreshIfNeeded() else stopAutoRefresh()
    }

    fun loadData() {
        viewModelScope.launch {
            loading.value = true
            errorMessage.value = null
            statusText.value = "拉取开奖…"
            try {
                val rows = repo.fetchAndCacheHistory(currentLottery.value, days = 3)
                history.value = rows
                latest.value = rows.lastOrNull()
                statusText.value = "生成预测与计划…"
                runPredictAndPlans(rows)
                statusText.value = "就绪 · ${rows.size} 期"
            } catch (e: Exception) {
                errorMessage.value = e.message ?: "数据加载失败，请检查网络"
                statusText.value = "失败"
            } finally {
                loading.value = false
            }
        }
    }

    fun runBacktest() {
        viewModelScope.launch {
            val rows = history.value
            if (rows.size < 40) {
                errorMessage.value = "历史不足，至少约 40 期再回测"
                return@launch
            }
            backtestRunning.value = true
            statusText.value = "回测中…"
            try {
                withContext(Dispatchers.Default) {
                    planEngine.backtest(rows, prefs.value, minWarm = 30)
                }
                planRows.value = planEngine.getRuntimes()
                val target = PredictEngine.suggestNextIssue(rows.lastOrNull()?.issue)
                val preds = planEngine.predictForNext(rows, prefs.value, target, rows.last().issue)
                consensus.value = planEngine.consensus(currentLottery.value.key, target, preds)
                statusText.value = "回测完成"
            } catch (e: Exception) {
                errorMessage.value = e.message
            } finally {
                backtestRunning.value = false
            }
        }
    }

    private suspend fun runPredictAndPlans(rows: List<DrawRecord>) {
        if (rows.isEmpty()) return
        val cfg = currentLottery.value
        val cutoff = rows.last().issue
        val target = rows.last().nextIssue?.takeIf { it.isNotBlank() }
            ?: PredictEngine.suggestNextIssue(cutoff)

        val snap = withContext(Dispatchers.Default) {
            PredictEngine.predict(rows, cfg.type, prefs.value, target, cutoff)
        }
        prediction.value = snap

        withContext(Dispatchers.Default) {
            if (rows.size >= 40) {
                planEngine.backtest(rows, prefs.value, minWarm = 30)
            }
            val preds = planEngine.predictForNext(rows, prefs.value, target, cutoff)
            consensus.value = planEngine.consensus(cfg.key, target, preds)
            planRows.value = planEngine.getRuntimes()
        }
    }

    private fun startAutoRefreshIfNeeded() {
        stopAutoRefresh()
        if (!prefs.value.autoRefresh) return
        refreshJob = viewModelScope.launch {
            while (isActive) {
                delay(30_000)
                try {
                    val one = app.apiClient.fetchLatest(currentLottery.value)
                    if (one != null) {
                        val exists = history.value.any { it.issue == one.issue }
                        if (!exists) {
                            val merged = (history.value + one)
                                .distinctBy { it.issue }
                                .sortedBy { it.issue.toLongOrNull() ?: 0L }
                            history.value = merged
                            latest.value = one
                            runPredictAndPlans(merged)
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun stopAutoRefresh() {
        refreshJob?.cancel()
        refreshJob = null
    }

    override fun onCleared() {
        stopAutoRefresh()
        super.onCleared()
    }
}
