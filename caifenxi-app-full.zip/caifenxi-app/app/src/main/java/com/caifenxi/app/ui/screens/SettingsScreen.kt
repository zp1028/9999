package com.caifenxi.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.caifenxi.app.service.DataSyncService
import com.caifenxi.app.ui.MainViewModel

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs.value
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("设置", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))

        Text("参数档位", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.padding(vertical = 8.dp)) {
            listOf("simple" to "简单", "balanced" to "均衡", "pro" to "专业").forEach { (key, label) ->
                FilterChip(
                    selected = p.sensitivityMode == key,
                    onClick = { vm.updatePrefs { it.copy(sensitivityMode = key) } },
                    label = { Text(label) },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        SettingSwitch("自动刷新", p.autoRefresh) { v ->
            vm.updatePrefs { it.copy(autoRefresh = v) }
        }
        SettingSwitch("深色模式", p.darkMode) { v ->
            vm.updatePrefs { it.copy(darkMode = v) }
        }
        SettingSwitch("EWMA 自适应", p.ewmaEnabled) { v ->
            vm.updatePrefs { it.copy(ewmaEnabled = v) }
        }

        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            context.startForegroundService(Intent(context, DataSyncService::class.java))
        }) { Text("启动后台开奖监听") }

        Spacer(Modifier.height(16.dp))
        Text("AI（可选）", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            value = p.aiApiKey,
            onValueChange = { key -> vm.updatePrefs { it.copy(aiApiKey = key) } },
            label = { Text("API Key（本机保存）") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Text(
            "仅保存在本机，用于可选 AI 计划；留空则使用本地规则。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(24.dp))
        Text(
            "彩析 v1.0.0 · Phase 1–5 骨架完成 · 仅供学习研究，请理性购彩",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
