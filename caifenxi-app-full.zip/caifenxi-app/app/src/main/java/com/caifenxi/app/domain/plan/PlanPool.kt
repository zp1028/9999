package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/**
 * PLAN-POOL-40-V1 精简版：保留核心计划定义（大小/单双/号码/结构）
 * 完整 40 条可后续从原 plan_config 继续补全。
 */
object PlanPool {

    val STRATEGY_VERSION = "PLAN-POOL-40-V1"

    val ALL: List<PlanDefinition> = buildList {
        // 大小 6
        add(bin("S-FREQ-010", "大小10期频率", "大小", "FREQ", 10))
        add(bin("S-FREQ-020", "大小20期频率", "大小", "FREQ", 20))
        add(bin("S-FREQ-050", "大小50期频率", "大小", "FREQ", 50))
        add(bin("S-EWMA", "大小EWMA", "大小", "EWMA", 30))
        add(bin("S-MKV1", "大小一阶转移", "大小", "MKV1", 50))
        add(bin("S-MULTI", "大小多周期融合", "大小", "MSF", 100))
        // 单双 6
        add(bin("D-FREQ-010", "单双10期频率", "单双", "FREQ", 10))
        add(bin("D-FREQ-020", "单双20期频率", "单双", "FREQ", 20))
        add(bin("D-FREQ-050", "单双50期频率", "单双", "FREQ", 50))
        add(bin("D-EWMA", "单双EWMA", "单双", "EWMA", 30))
        add(bin("D-MKV1", "单双一阶转移", "单双", "MKV1", 50))
        add(bin("D-MULTI", "单双多周期融合", "单双", "MSF", 100))
        // 号码
        add(num("N-FREQ-010", "号码10期频率", 10))
        add(num("N-FREQ-020", "号码20期频率", 20))
        add(num("N-FREQ-050", "号码50期频率", 50))
        add(num("N-FREQ-100", "号码100期频率", 100))
        add(num("N-EWMA", "号码EWMA", 50, "EWMA"))
        add(num("N-OMIT", "号码遗漏", 80, "OMIT"))
        add(num("N-MULTI", "号码多周期融合", 100, "MSF"))
    }

    private fun bin(
        id: String, name: String, cat: String, algo: String, window: Int
    ) = PlanDefinition(
        planId = id,
        planName = name,
        category = cat,
        algorithm = algo,
        window = window,
        outputFormat = PlanOutputFormat.DIRECTION,
        hitCriteria = PlanHitCriteria.DIRECTION_MATCH,
        participateConsensus = true,
        participateCombo = false
    )

    private fun num(id: String, name: String, window: Int, algo: String = "FREQ") = PlanDefinition(
        planId = id,
        planName = name,
        category = "号码",
        algorithm = algo,
        window = window,
        outputFormat = PlanOutputFormat.NUMBER_SCORES,
        hitCriteria = PlanHitCriteria.TOP20_HIT,
        participateConsensus = false,
        participateCombo = true,
        baselineValue = 0.25,
        weightCap = 1.0
    )
}
