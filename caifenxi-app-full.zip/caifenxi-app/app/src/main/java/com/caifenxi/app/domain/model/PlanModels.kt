package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 计划输出格式（与 plan_config.js 对齐）
 */
enum class PlanOutputFormat {
    DIRECTION,          // 方向（大小/单双）
    ZONE_DISTRIBUTION,  // 区间分布
    NUMBER_SCORES,      // 号码评分
    STRUCTURE_VALUE     // 结构值
}

enum class PlanHitCriteria {
    DIRECTION_MATCH,
    ZONE_DISTANCE,
    TOP20_HIT,
    STRUCTURE_RANGE
}

/**
 * 计划静态配置（40 计划池中的一条）
 */
@Serializable
data class PlanDefinition(
    val planId: String,
    val planName: String,
    val category: String,           // 大小 / 单双 / 区间 / 号码 / 结构 / AI
    val algorithm: String,          // FREQ / EWMA / MKV1 / MSF / OMIT / CHOT ...
    val window: Int,
    val outputFormat: PlanOutputFormat = PlanOutputFormat.DIRECTION,
    val hitCriteria: PlanHitCriteria = PlanHitCriteria.DIRECTION_MATCH,
    val backtestWindows: List<Int> = listOf(10, 20, 50, 100, 200, 500),
    val baselineType: String = "uniform_50",
    val baselineValue: Double = 0.50,
    val weightCap: Double = 1.0,
    val participateConsensus: Boolean = true,
    val participateCombo: Boolean = false
)

/**
 * 计划运行时状态
 */
@Serializable
data class PlanRuntime(
    val planId: String,
    val weight: Double = 1.0,
    val score: Double = 50.0,
    val sampleCount: Int = 0,
    val hitCount: Int = 0,
    val consecutiveMiss: Int = 0,
    val status: PlanStatus = PlanStatus.ACTIVE,
    val lastPrediction: String? = null,
    val lastTargetIssue: String? = null
)

enum class PlanStatus {
    ACTIVE,
    PROMOTED,
    DEMOTED,
    HOLD,
    ELIMINATED
}

/**
 * 单期计划预测记录
 */
@Serializable
data class PlanPredictionRecord(
    val planId: String,
    val lotteryKey: String,
    val targetIssue: String,
    val cutoffIssue: String,
    val output: String,             // 方向或序列化结果
    val scoreAtPredict: Double,
    val weightAtPredict: Double,
    val settled: Boolean = false,
    val hit: Boolean? = null,
    val settledAt: Long? = null
)

/**
 * 模型共识（加权支持度，非真实概率）
 */
@Serializable
data class ModelConsensus(
    val lotteryKey: String,
    val targetIssue: String,
    val category: String,           // 大小 / 单双 / 组合
    val leadingDirection: String,
    val supportRatio: Double,       // 加权支持占比 0~1
    val disagreement: Double,       // 分歧度
    val participatingPlans: Int,
    val detail: Map<String, Double> = emptyMap() // direction -> weight sum
)

/**
 * 评分公式权重（对应原 30/18/12/12/8/10/10）
 * 可在后续版本调整
 */
object ScoreWeights {
    const val RECENT_HIT = 30.0
    const val MID_HIT = 18.0
    const val LONG_HIT = 12.0
    const val STABILITY = 12.0
    const val SAMPLE = 8.0
    const val STREAK = 10.0
    const val BASELINE_BEAT = 10.0
}
