package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.ui.MainViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel) {
    val lottery = vm.currentLottery.value
    val latest = vm.latest.value
    val history = vm.history.value
    val loading = vm.loading.value
    val error = vm.errorMessage.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "⚠️ 重要声明：开奖为随机事件，历史无法预测未来。本工具只做统计可视化与策略回测，不提供中奖保证。「共识/评分」是模型加权支持度与相对评分，不是下一期真实中奖概率。请理性对待。",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(12.dp)
            )
        }

        Spacer(Modifier.height(12.dp))

        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            TextField(
                value = lottery.name,
                onValueChange = {},
                readOnly = true,
                label = { Text("当前彩种") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                LotteryConfig.CATALOG.forEach { item ->
                    DropdownMenuItem(
                        text = { Text(item.name) },
                        onClick = {
                            vm.selectLottery(item)
                            expanded = false
                        }
                    )
                }
            }
        }

        if (vm.statusText.value.isNotBlank()) {
            Text(
                vm.statusText.value,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Spacer(Modifier.height(12.dp))

        if (loading && history.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator()
                Spacer(Modifier.height(8.dp))
                Text("加载中…")
            }
            return
        }

        if (error != null) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("数据加载失败", fontWeight = FontWeight.Bold)
                    Text(error, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.loadData() }) { Text("重新加载") }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("已加载期数", history.size.toString(), Modifier.weight(1f))
            StatCard("最新期号", latest?.issue ?: "-", Modifier.weight(1f))
            StatCard("开奖时间", latest?.drawTime?.take(16) ?: "-", Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("实时开奖", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (latest == null) {
                    Text("暂无数据", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Text("第 ${latest.issue} 期", style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        latest.numbers.joinToString("  "),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    val tags = listOfNotNull(latest.dx, latest.ds, latest.combo, latest.sum?.let { "和值$it" })
                    if (tags.isNotEmpty()) {
                        Text(tags.joinToString(" · "), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // 策略驾驶舱
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("策略驾驶舱", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (consensus.isEmpty() && pred == null) {
                    Text(
                        "加载数据后显示模型共识与参考预测",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    if (pred != null) {
                        Text("目标期 ${pred.targetIssue}（截止 ${pred.cutoffIssue}）", style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(6.dp))
                        pred.dx?.let {
                            Text("大小：${it.direction}  支持度 ${(it.score * 100).roundToInt()}%  · ${it.detail}")
                        }
                        pred.ds?.let {
                            Text("单双：${it.direction}  支持度 ${(it.score * 100).roundToInt()}%  · ${it.detail}")
                        }
                        pred.combo?.let {
                            Text("组合：${it.direction}  支持度 ${(it.score * 100).roundToInt()}%")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    consensus.forEach { c ->
                        Text(
                            "${c.category}共识 → ${c.leadingDirection}（加权支持 ${(c.supportRatio * 100).roundToInt()}%，分歧 ${"%.2f".format(c.disagreement)}，${c.participatingPlans} 计划）",
                            style = MaterialTheme.typography.bodySmall
                        )
                        LinearProgressIndicator(
                            progress = { c.supportRatio.toFloat() },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { vm.loadData() }) { Text("刷新数据") }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}
