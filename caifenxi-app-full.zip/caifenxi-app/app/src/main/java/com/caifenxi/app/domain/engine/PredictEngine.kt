package com.caifenxi.app.domain.engine

import com.caifenxi.app.domain.model.DirectionPrediction
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.NumberScore
import com.caifenxi.app.domain.model.PositionPrediction
import com.caifenxi.app.domain.model.PredictCategory
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.exp
import kotlin.math.ln

/**
 * 原生预测引擎：频率 / EWMA / 一阶转移 / 多周期融合
 * 输出为模型支持度（相对评分），不是真实中奖概率。
 */
object PredictEngine {

    fun predict(
        history: List<DrawRecord>,
        lotteryType: LotteryType,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): PredictionSnapshot {
        if (history.size < 5) {
            return PredictionSnapshot(
                lotteryKey = history.firstOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                createdAt = System.currentTimeMillis()
            )
        }
        val window = prefs.predictionWindow.coerceIn(20, 500)
        val recent = history.takeLast(window)

        val dxSeq = recent.mapNotNull { it.dx }
        val dsSeq = recent.mapNotNull { it.ds }
        val comboSeq = recent.mapNotNull { it.combo }

        val dx = predictBinary(dxSeq, listOf("大", "小"), prefs, PredictCategory.DX)
        val ds = predictBinary(dsSeq, listOf("单", "双"), prefs, PredictCategory.DS)
        val combo = predictBinary(
            comboSeq,
            listOf("大单", "大双", "小单", "小双"),
            prefs,
            PredictCategory.COMBO
        )

        val numberScores = when (lotteryType) {
            LotteryType.LUCK20 -> numberFrequency(recent, 1..80, prefs.zuheTopN.coerceAtLeast(10))
            LotteryType.PKS -> numberFrequency(recent, 1..10, 10)
        }

        val positions = when (lotteryType) {
            LotteryType.PKS -> positionPredict(recent, 10, prefs.positionTopN)
            LotteryType.LUCK20 -> positionPredict(recent, 5, prefs.positionTopN) // 前5位参考
        }

        return PredictionSnapshot(
            lotteryKey = recent.last().lotteryKey,
            targetIssue = targetIssue,
            cutoffIssue = cutoffIssue,
            createdAt = System.currentTimeMillis(),
            frozen = false,
            dx = dx,
            ds = ds,
            combo = combo,
            numberScores = numberScores,
            positions = positions,
            algoTag = if (prefs.ewmaEnabled) "ewma+freq" else "freq"
        )
    }

    private fun predictBinary(
        seq: List<String>,
        labels: List<String>,
        prefs: UserPrefs,
        category: PredictCategory
    ): DirectionPrediction? {
        if (seq.isEmpty()) return null
        val scores = mutableMapOf<String, Double>()
        labels.forEach { scores[it] = 0.0 }

        // 频率
        val freqW = listOf(10, 20, 50).map { w ->
            val slice = seq.takeLast(w.coerceAtMost(seq.size))
            labels.associateWith { lab -> slice.count { it == lab }.toDouble() / slice.size.coerceAtLeast(1) }
        }
        freqW.forEachIndexed { i, m ->
            val weight = when (i) { 0 -> 0.35; 1 -> 0.35; else -> 0.30 }
            m.forEach { (k, v) -> scores[k] = scores.getValue(k) + v * weight }
        }

        // EWMA
        if (prefs.ewmaEnabled && seq.isNotEmpty()) {
            val alpha = prefs.ewmaAlpha.toDouble().coerceIn(0.05, 0.5)
            val ewma = labels.associateWith { 1.0 / labels.size }.toMutableMap()
            seq.forEach { x ->
                labels.forEach { lab ->
                    val target = if (lab == x) 1.0 else 0.0
                    ewma[lab] = alpha * target + (1 - alpha) * ewma.getValue(lab)
                }
            }
            ewma.forEach { (k, v) -> scores[k] = scores.getValue(k) * 0.55 + v * 0.45 }
        }

        // 一阶转移
        if (seq.size >= 2) {
            val last = seq.last()
            val trans = labels.associateWith { 0.0 }.toMutableMap()
            var count = 0
            for (i in 1 until seq.size) {
                if (seq[i - 1] == last) {
                    trans[seq[i]] = trans.getValue(seq[i]) + 1.0
                    count++
                }
            }
            if (count > 0) {
                labels.forEach { lab ->
                    val p = trans.getValue(lab) / count
                    scores[lab] = scores.getValue(lab) * 0.7 + p * 0.3
                }
            }
        }

        // 连错衰减 / 动量
        if (prefs.streakDecayEnabled && seq.isNotEmpty()) {
            val last = seq.last()
            var streak = 0
            for (i in seq.indices.reversed()) {
                if (seq[i] == last) streak++ else break
            }
            if (streak >= 3) {
                // 反羊群：略降当前热门
                scores[last] = scores.getValue(last) * (1.0 - 0.08 * prefs.antiHerdStrength)
            }
        }

        // 归一 + softmax 温度
        val temp = prefs.ewmaWeightTemperature.toDouble().coerceIn(0.02, 0.3)
        val maxS = scores.values.maxOrNull() ?: 1.0
        val expScores = scores.mapValues { (_, v) -> exp((v - maxS) / temp) }
        val sumExp = expScores.values.sum().coerceAtLeast(1e-9)
        val norm = expScores.mapValues { it.value / sumExp }

        val best = norm.maxByOrNull { it.value } ?: return null
        return DirectionPrediction(
            category = category,
            direction = best.key,
            score = best.value,
            algo = if (prefs.ewmaEnabled) "MSF" else "FREQ",
            detail = norm.entries.joinToString(" ") { "${it.key}:${"%.0f".format(it.value * 100)}%" }
        )
    }

    private fun numberFrequency(
        recent: List<DrawRecord>,
        range: IntRange,
        topN: Int
    ): List<NumberScore> {
        val cnt = range.associateWith { 0 }.toMutableMap()
        recent.forEach { row ->
            row.numbers.forEach { n ->
                if (n in range) cnt[n] = cnt.getValue(n) + 1
            }
        }
        val total = recent.size.coerceAtLeast(1).toDouble()
        return cnt.entries
            .sortedByDescending { it.value }
            .mapIndexed { idx, e ->
                NumberScore(number = e.key, score = e.value / total, rank = idx + 1)
            }
            .take(topN.coerceAtLeast(5))
    }

    private fun positionPredict(
        recent: List<DrawRecord>,
        posCount: Int,
        topN: Int
    ): List<PositionPrediction> {
        return (0 until posCount).map { idx ->
            val seq = recent.mapNotNull { it.numbers.getOrNull(idx) }
            val cnt = seq.groupingBy { it }.eachCount()
            val total = seq.size.coerceAtLeast(1).toDouble()
            val tops = cnt.entries
                .sortedByDescending { it.value }
                .take(topN)
                .mapIndexed { r, e -> NumberScore(e.key, e.value / total, r + 1) }
            val name = when (idx) {
                0 -> "冠军"
                1 -> "亚军"
                else -> "第${idx + 1}"
            }
            PositionPrediction(idx, name, tops)
        }
    }

    /** 下一期期号简单 +1（字符串数字） */
    fun suggestNextIssue(latest: String?): String {
        if (latest.isNullOrBlank()) return "-"
        val n = latest.toLongOrNull() ?: return latest
        return (n + 1).toString()
    }
}
