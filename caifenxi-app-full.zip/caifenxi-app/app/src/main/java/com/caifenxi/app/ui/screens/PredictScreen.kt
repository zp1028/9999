package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.ui.MainViewModel
import kotlin.math.roundToInt

@Composable
fun PredictScreen(vm: MainViewModel) {
    val pred = vm.prediction.value
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("预测面板", style = MaterialTheme.typography.titleLarge)
        Text(
            "模型支持度 / 相对评分，非真实中奖概率",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        if (pred == null) {
            Text("请先在首页加载数据")
            return
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("目标期 ${pred.targetIssue}", fontWeight = FontWeight.Bold)
                Text("算法 ${pred.algoTag} · 截止 ${pred.cutoffIssue}", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                pred.dx?.let { Text("大小 → ${it.direction}（${(it.score * 100).roundToInt()}%） ${it.detail}") }
                pred.ds?.let { Text("单双 → ${it.direction}（${(it.score * 100).roundToInt()}%） ${it.detail}") }
                pred.combo?.let { Text("组合 → ${it.direction}（${(it.score * 100).roundToInt()}%）") }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (pred.numberScores.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("号码热度 Top", fontWeight = FontWeight.Bold)
                    pred.numberScores.take(15).forEach { ns ->
                        Text("#${ns.rank}  号码 ${ns.number}  相对分 ${"%.3f".format(ns.score)}")
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (pred.positions.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("位置预测", fontWeight = FontWeight.Bold)
                    pred.positions.forEach { pos ->
                        val tops = pos.topNumbers.joinToString(" ") { "${it.number}" }
                        Text("${pos.positionName}: $tops")
                    }
                }
            }
        }
    }
}
