package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanStatus
import com.caifenxi.app.domain.model.ScoreWeights
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.max
import kotlin.math.min

/**
 * 计划执行：预测 → 结算 → 评分 → 权重 → 共识
 */
class PlanEngine {

    private val runtimes = mutableMapOf<String, PlanRuntime>()
    private val historyPreds = mutableListOf<PlanPredictionRecord>()

    fun ensureRuntimes() {
        PlanPool.ALL.forEach { def ->
            if (!runtimes.containsKey(def.planId)) {
                runtimes[def.planId] = PlanRuntime(planId = def.planId)
            }
        }
    }

    fun getRuntimes(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureRuntimes()
        return PlanPool.ALL.map { it to (runtimes[it.planId] ?: PlanRuntime(it.planId)) }
            .sortedByDescending { it.second.score }
    }

    /**
     * 对历史做简单回测结算（从第 minWarm 期开始）
     */
    fun backtest(history: List<DrawRecord>, prefs: UserPrefs, minWarm: Int = 30) {
        ensureRuntimes()
        if (history.size < minWarm + 5) return
        // 重置
        PlanPool.ALL.forEach {
            runtimes[it.planId] = PlanRuntime(planId = it.planId)
        }
        historyPreds.clear()

        for (i in minWarm until history.size) {
            val cutoff = history.subList(0, i)
            val actual = history[i]
            val preds = predictAll(cutoff, prefs, actual.issue, cutoff.last().issue)
            preds.forEach { rec ->
                val hit = evaluateHit(rec, actual)
                val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
                historyPreds.add(settled)
                updateRuntime(settled)
            }
        }
    }

    fun predictForNext(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        ensureRuntimes()
        return predictAll(history, prefs, targetIssue, cutoffIssue)
    }

    fun consensus(
        lotteryKey: String,
        targetIssue: String,
        preds: List<PlanPredictionRecord>
    ): List<ModelConsensus> {
        val byCat = preds.groupBy { planCategory(it.planId) }
        return listOf("大小", "单双").mapNotNull { cat ->
            val list = byCat[cat] ?: return@mapNotNull null
            val weightSum = mutableMapOf<String, Double>()
            var totalW = 0.0
            list.forEach { rec ->
                val rt = runtimes[rec.planId] ?: return@forEach
                if (rt.status == PlanStatus.ELIMINATED || rt.status == PlanStatus.HOLD) return@forEach
                val w = rt.weight.coerceIn(0.05, 1.5)
                weightSum[rec.output] = (weightSum[rec.output] ?: 0.0) + w
                totalW += w
            }
            if (totalW <= 0) return@mapNotNull null
            val leading = weightSum.maxByOrNull { it.value } ?: return@mapNotNull null
            val ratio = leading.value / totalW
            val second = weightSum.values.sortedDescending().getOrNull(1) ?: 0.0
            val disagreement = if (leading.value > 0) second / leading.value else 1.0
            ModelConsensus(
                lotteryKey = lotteryKey,
                targetIssue = targetIssue,
                category = cat,
                leadingDirection = leading.key,
                supportRatio = ratio,
                disagreement = disagreement,
                participatingPlans = list.size,
                detail = weightSum.mapValues { it.value / totalW }
            )
        }
    }

    private fun predictAll(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        return PlanPool.ALL.mapNotNull { def ->
            val out = runPlan(def, history, prefs) ?: return@mapNotNull null
            val rt = runtimes[def.planId] ?: PlanRuntime(def.planId)
            PlanPredictionRecord(
                planId = def.planId,
                lotteryKey = history.lastOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                output = out,
                scoreAtPredict = rt.score,
                weightAtPredict = rt.weight
            )
        }
    }

    private fun runPlan(def: PlanDefinition, history: List<DrawRecord>, prefs: UserPrefs): String? {
        val slice = history.takeLast(def.window.coerceAtLeast(5).coerceAtMost(history.size))
        if (slice.size < 3) return null
        return when (def.category) {
            "大小" -> majority(slice.mapNotNull { it.dx }, def, prefs)
            "单双" -> majority(slice.mapNotNull { it.ds }, def, prefs)
            "号码" -> {
                val cnt = mutableMapOf<Int, Int>()
                slice.forEach { r -> r.numbers.forEach { n -> cnt[n] = (cnt[n] ?: 0) + 1 } }
                cnt.maxByOrNull { it.value }?.key?.toString()
            }
            else -> null
        }
    }

    private fun majority(seq: List<String>, def: PlanDefinition, prefs: UserPrefs): String? {
        if (seq.isEmpty()) return null
        return when (def.algorithm) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val ewma = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { lab ->
                        val t = if (lab == x) 1.0 else 0.0
                        ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                    }
                }
                ewma.maxByOrNull { it.value }?.key
            }
            "MKV1" -> {
                if (seq.size < 2) return seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                val last = seq.last()
                val next = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0) + 1
                }
                next.maxByOrNull { it.value }?.key
                    ?: seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            }
            else -> seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        }
    }

    private fun evaluateHit(rec: PlanPredictionRecord, actual: DrawRecord): Boolean {
        val def = PlanPool.ALL.find { it.planId == rec.planId } ?: return false
        return when (def.hitCriteria) {
            PlanHitCriteria.DIRECTION_MATCH -> when (def.category) {
                "大小" -> rec.output == actual.dx
                "单双" -> rec.output == actual.ds
                else -> false
            }
            PlanHitCriteria.TOP20_HIT -> {
                val n = rec.output.toIntOrNull() ?: return false
                n in actual.numbers
            }
            else -> false
        }
    }

    private fun updateRuntime(rec: PlanPredictionRecord) {
        val rt = runtimes[rec.planId] ?: return
        val hit = rec.hit == true
        val sample = rt.sampleCount + 1
        val hits = rt.hitCount + if (hit) 1 else 0
        val miss = if (hit) 0 else rt.consecutiveMiss + 1
        val hitRate = hits.toDouble() / sample

        // 简化评分：命中率为主 + 样本 + 连错惩罚
        var score = hitRate * ScoreWeights.RECENT_HIT * 2.5
        score += min(sample / 100.0, 1.0) * ScoreWeights.SAMPLE
        if (miss >= 5) score -= ScoreWeights.STREAK * (miss - 4) * 0.15
        score = score.coerceIn(0.0, 100.0)

        // 权重：相对 baseline 0.5，波动 ±15%
        var weight = 0.5 + (hitRate - 0.5) * 0.6
        weight = weight.coerceIn(0.35, 1.15)

        val status = when {
            miss >= 12 && sample >= 30 -> PlanStatus.DEMOTED
            sample >= 100 && hitRate < 0.42 -> PlanStatus.ELIMINATED
            score >= 65 && sample >= 50 -> PlanStatus.PROMOTED
            else -> PlanStatus.ACTIVE
        }

        runtimes[rec.planId] = rt.copy(
            weight = weight,
            score = score,
            sampleCount = sample,
            hitCount = hits,
            consecutiveMiss = miss,
            status = status,
            lastPrediction = rec.output,
            lastTargetIssue = rec.targetIssue
        )
    }

    private fun planCategory(planId: String): String =
        PlanPool.ALL.find { it.planId == planId }?.category ?: ""
}
