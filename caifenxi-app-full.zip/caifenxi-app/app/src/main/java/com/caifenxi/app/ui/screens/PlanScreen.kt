package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.ui.MainViewModel
import kotlin.math.roundToInt

@Composable
fun PlanScreen(vm: MainViewModel) {
    val rows = vm.planRows.value
    val consensus = vm.consensus.value

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("计划大厅", style = MaterialTheme.typography.titleLarge)
        Text("加权共识 · 回测评分 · 非真实概率", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { vm.runBacktest() },
            enabled = !vm.backtestRunning.value
        ) {
            Text(if (vm.backtestRunning.value) "回测中…" else "强制全量回测")
        }
        Spacer(Modifier.height(8.dp))
        consensus.forEach { c ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("${c.category} 共识 → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                    Text("支持 ${(c.supportRatio * 100).roundToInt()}% · 分歧 ${"%.2f".format(c.disagreement)} · ${c.participatingPlans} 计划")
                    LinearProgressIndicator(progress = { c.supportRatio.toFloat() }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(rows, key = { it.first.planId }) { (def, rt) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${def.planName}（${def.planId}）", fontWeight = FontWeight.Bold)
                        Text(
                            "分类 ${def.category} · ${def.algorithm} · 窗 ${def.window} · 状态 ${rt.status}",
                            style = MaterialTheme.typography.labelSmall
                        )
                        Text(
                            "评分 ${"%.1f".format(rt.score)} · 权重 ${"%.2f".format(rt.weight)} · 样本 ${rt.sampleCount} · 命中 ${rt.hitCount} · 连错 ${rt.consecutiveMiss}"
                        )
                        rt.lastPrediction?.let { Text("最近预测: $it → 目标 ${rt.lastTargetIssue ?: "-"}") }
                    }
                }
            }
        }
    }
}
