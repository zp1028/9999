package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun PlanScreen(vm: MainViewModel) {
    val rows = vm.planRows.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16, bottom = CaiTokens.ScreenBottom),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
    ) {
        item {
            Text("计划大厅", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("每期自动随机生成预测计划 · 展示对错成功率")
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                text = if (vm.backtestRunning.value) "生成/回测中…" else "重新随机生成本期计划并回测",
                onClick = { vm.runBacktest() },
                enabled = !vm.backtestRunning.value,
                modifier = Modifier.fillMaxWidth()
            )
            if (pred != null) {
                CaptionMuted("当前目标期 ${pred.targetIssue} · 本期激活 ${rows.size} 条计划")
            }
        }

        item {
            if (consensus.isNotEmpty()) {
                Text("加权共识（成功率加权）", fontWeight = FontWeight.SemiBold)
            }
        }
        items(consensus) { c ->
            GlobalCard {
                Text("${c.category} → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                Text("支持 ${(c.supportRatio * 100).roundToInt()}% · 分歧 ${"%.2f".format(c.disagreement)} · ${c.participatingPlans} 计划")
                LinearProgressIndicator(
                    progress = { c.supportRatio.toFloat() },
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        item {
            Spacer(Modifier.height(CaiTokens.S8))
            Text("本期计划 · 成功率排行", fontWeight = FontWeight.Bold)
            CaptionMuted("成功率 = 历史命中 / 已结算次数（跨期累计）")
        }

        if (rows.isEmpty()) {
            item {
                GlobalCard {
                    Text("暂无计划。请先首页加载数据，将自动按期随机生成。")
                }
            }
        } else {
            items(rows, key = { it.first.planId }) { (def, rt) ->
                GlobalCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            def.planName,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            rt.hitRatePercent,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                rt.sampleCount == 0 -> MaterialTheme.colorScheme.onSurfaceVariant
                                rt.hitRate >= 0.55 -> MaterialTheme.colorScheme.secondary
                                rt.hitRate < 0.45 -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                    CaptionMuted(
                        buildString {
                            append(def.category)
                            append(" · ")
                            append(def.algorithm)
                            append(" · 窗")
                            append(def.window)
                            if (def.randomGenerated) append(" · 随机生成")
                            append(" · ")
                            append(rt.status)
                        }
                    )
                    Spacer(Modifier.height(CaiTokens.S4))
                    Text(
                        "对 ${rt.hitCount} / 共 ${rt.sampleCount} · 评分 ${"%.1f".format(rt.score)} · 权重 ${"%.2f".format(rt.weight)} · 连错 ${rt.consecutiveMiss}"
                    )
                    if (rt.sampleCount > 0) {
                        LinearProgressIndicator(
                            progress = { rt.hitRate.toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    rt.lastPrediction?.let {
                        CaptionMuted("最近预测: $it → 目标 ${rt.lastTargetIssue ?: "-"}")
                    }
                }
            }
        }
        item { Spacer(Modifier.height(CaiTokens.S24)) }
    }
}
