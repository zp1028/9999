package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.caifenxi.app.ui.MainViewModel

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val history = vm.history.value.asReversed()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("开奖记录 / 战绩", style = MaterialTheme.typography.titleLarge)
        Text(
            "共 ${history.size} 期（后续将加入命中统计）",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        LazyColumn {
            items(history.take(100), key = { it.issue }) { row ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("第 ${row.issue} 期 · ${row.drawTime.take(19)}", style = MaterialTheme.typography.labelMedium)
                        Text(row.numbers.joinToString(" "), style = MaterialTheme.typography.bodyLarge)
                        val tags = listOfNotNull(row.dx, row.ds, row.combo)
                        if (tags.isNotEmpty()) {
                            Text(tags.joinToString(" "), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
