package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.ui.MainViewModel
import kotlin.math.roundToInt

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val summary = vm.statsSummary.value
    val records = vm.statRecords.value
    val draws = vm.history.value.asReversed()

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            Text("📈 我的战绩", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "自动结算对错 · 当前 ${vm.currentLottery.value.name}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
        }

        item {
            // 总览卡片
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("战绩总览", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        BigStat("已结算", "${summary.hit + summary.miss}")
                        BigStat("对", "${summary.hit}", Color(0xFF2E7D32))
                        BigStat("错", "${summary.miss}", Color(0xFFC62828))
                        BigStat(
                            "命中率",
                            if (summary.hit + summary.miss == 0) "-" else "${(summary.hitRate * 100).roundToInt()}%",
                            MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    val streakText = when {
                        summary.recentStreak > 0 -> "当前连对 ${summary.recentStreak}"
                        summary.recentStreak < 0 -> "当前连错 ${-summary.recentStreak}"
                        else -> "暂无连续"
                    }
                    Text(
                        "$streakText · 最长连对 ${summary.maxHitStreak} · 最长连错 ${summary.maxMissStreak} · 待开 ${summary.pending}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            if (summary.byCategory.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("分类命中", fontWeight = FontWeight.Bold)
                        summary.byCategory.forEach { (cat, st) ->
                            val rate = if (st.hit + st.miss == 0) 0 else (st.hit * 100.0 / (st.hit + st.miss)).roundToInt()
                            Text("$cat：对 ${st.hit} / 错 ${st.miss} · 命中率 $rate%")
                        }
                    }
                }
            }
        }

        item {
            if (summary.byAlgo.isNotEmpty()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("算法命中", fontWeight = FontWeight.Bold)
                        summary.byAlgo.forEach { (algo, st) ->
                            val label = AlgoMode.fromId(algo).label
                            val rate = if (st.hit + st.miss == 0) 0 else (st.hit * 100.0 / (st.hit + st.miss)).roundToInt()
                            Text("$label：对 ${st.hit} / 错 ${st.miss} · $rate%")
                        }
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.backfillStats() }) { Text("回填结算") }
                OutlinedButton(onClick = { vm.clearStats() }) { Text("清空战绩") }
                Button(onClick = { vm.loadData() }) { Text("刷新") }
            }
        }

        item {
            Text("预测记录", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        }

        if (records.isEmpty()) {
            item {
                Text("暂无战绩。生成预测后，开奖将自动结算对错。", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            items(records.take(80), key = { it.id }) { r ->
                val color = when (r.result) {
                    "对" -> Color(0xFF2E7D32)
                    "错" -> Color(0xFFC62828)
                    else -> Color(0xFFF9A825)
                }
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .background(color, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(r.result, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("第 ${r.issue} 期 · ${r.category}", fontWeight = FontWeight.SemiBold)
                            Text(
                                "预测 ${r.lean}" + (r.actual?.let { " → 实际 $it" } ?: "") +
                                    " · ${AlgoMode.fromId(r.algoId).label}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(8.dp))
            Text("开奖历史（最近）", fontWeight = FontWeight.Bold)
        }
        items(draws.take(30), key = { it.issue }) { row ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("第 ${row.issue} 期 · ${row.drawTime.take(19)}", style = MaterialTheme.typography.labelMedium)
                    Text(row.numbers.joinToString(" "), fontWeight = FontWeight.Medium)
                    val tags = listOfNotNull(row.dx, row.ds, row.combo)
                    if (tags.isNotEmpty()) Text(tags.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun BigStat(label: String, value: String, color: Color = Color.Unspecified) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
        )
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}
