package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel

@Composable
fun LabScreen(vm: MainViewModel) {
    val rows = vm.planRows.value
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("模型实验室", style = MaterialTheme.typography.titleLarge)
        Text("计划池 ${PlanPool.STRATEGY_VERSION} · 共 ${PlanPool.ALL.size} 条", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("滚动验证摘要", fontWeight = FontWeight.Bold)
                if (rows.isEmpty()) {
                    Text("加载数据并回测后显示各算法评分")
                } else {
                    val top = rows.take(5)
                    top.forEach { (def, rt) ->
                        val rate = if (rt.sampleCount > 0) rt.hitCount * 100.0 / rt.sampleCount else 0.0
                        Text("${def.planName}: 分 ${"%.1f".format(rt.score)} · 命中率 ${"%.1f".format(rate)}% · n=${rt.sampleCount}")
                    }
                    Text(
                        "说明：综合分用于相对排序，不是未来中奖概率。",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("算法清单", fontWeight = FontWeight.Bold)
                PlanPool.ALL.groupBy { it.category }.forEach { (cat, list) ->
                    Text("$cat（${list.size}）", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                    list.forEach { Text(" · ${it.planName} [${it.algorithm}/${it.window}]") }
                }
            }
        }
    }
}
