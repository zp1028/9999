# GitHub Actions 打包工作流兼容说明

本工程已整理为可直接配合“根目录 ZIP 自动解压并寻找 settings.gradle(.kts)”的结构。

- ZIP 解压后，`settings.gradle.kts`、`build.gradle.kts`、`gradlew` 和 `app/` 直接位于仓库根目录。
- 保留 Gradle Wrapper 8.9，与你提供的 `gradle-version: '8.9'` 一致。
- Android `compileSdk/targetSdk` 为 35，与工作流安装的 SDK 组件一致。
- JDK 目标为 17，与工作流一致。
- app 版本更新为 `1.1.2`。
- 没有把项目内部 `.github/workflows` 打进这个发布 ZIP，避免覆盖你仓库里提供的打包工作流。

注意：你提供的工作流中的 `find . -maxdepth 3 -path "*/app/src/main/java/com/quant/app/ui/QuantApp.kt"` 对标准 Android 源码路径实际上达不到该文件的深度，因此它通常不会执行 QuantApp.kt 覆盖步骤；这不影响本工程正常构建，但如果必须覆盖该文件，建议把 `-maxdepth 3` 改成 `-maxdepth 10` 或直接按 `find . -path ...` 搜索。
