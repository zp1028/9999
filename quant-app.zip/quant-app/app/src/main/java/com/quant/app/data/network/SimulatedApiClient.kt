package com.quant.app.data.network

import com.quant.app.data.config.ConfigStore
import com.quant.app.data.network.dto.AccountDto
import com.quant.app.data.network.dto.ExchangeInfoDto
import com.quant.app.data.network.dto.KlineDto
import com.quant.app.data.network.dto.OrderResponseDto
import com.quant.app.data.network.dto.PositionDto
import com.quant.app.data.network.dto.UserTradeDto
import com.quant.app.domain.model.OrderRequest
import com.quant.app.util.runCatchingS
import java.util.concurrent.atomic.AtomicLong

/**
 * 模拟盘交易所实现(本地撮合,无需币安 Key)。
 * - 行情(klines/exchangeInfo/hotSymbols)复用真实币安公开接口,保证模拟价格真实;
 * - 账户/持仓/下单/止损全部走本地 [SimulatedAccount];
 * - 开仓以最新 K 线收盘价成交,止损/止盈由 TradingService 的 K 线流检测触发。
 */
class SimulatedApiClient(
    private val account: SimulatedAccount,
    private val market: BinanceApiClient,   // 仅用于公开行情
    private val configStore: ConfigStore,
) : ExchangeApi {

    private val orderSeq = AtomicLong(1_000_000L)

    // ---------- 公开行情(复用真实币安) ----------

    override suspend fun klines(symbol: String, interval: String, limit: Int): List<KlineDto> =
        market.klines(symbol, interval, limit)

    override suspend fun exchangeInfo(): ExchangeInfoDto = market.exchangeInfo()

    override suspend fun hotSymbols(limit: Int): List<String> = market.hotSymbols(limit)

    override suspend fun serverTime(): Long = market.serverTime()

    // ---------- 账户与交易(本地) ----------

    override suspend fun account(): AccountDto = account.toAccountDto(latestPrices())

    override suspend fun positionRisk(): List<PositionDto> = account.toPositionDtos(latestPrices())

    override suspend fun placeOrder(request: OrderRequest): OrderResponseDto {
        val price = latestPrice(request.symbol) ?: throw BinanceApiException(-1, "无法获取 ${request.symbol} 行情")
        val qty = request.quantity.toDoubleOrNull() ?: 0.0
        val side = if (request.side == "BUY") "LONG" else "SHORT"
        val ok = account.openPosition(
            symbol = request.symbol,
            side = side,
            qty = qty,
            entryPrice = price,
            leverage = configStore.load().leverage,
            stopLossPrice = request.stopPrice?.toDoubleOrNull(),
            takeProfitPrice = null,
        )
        if (!ok) throw BinanceApiException(-2, "模拟开仓失败:保证金不足或已有持仓")
        val orderId = orderSeq.getAndIncrement()
        return OrderResponseDto(
            orderId = orderId,
            symbol = request.symbol,
            side = request.side,
            positionSide = request.positionSide,
            type = request.type,
            status = "FILLED",
            price = "%.2f".format(price),
            origQty = request.quantity,
            executedQty = request.quantity,
            avgPrice = "%.2f".format(price),
        )
    }

    override suspend fun placeStopLoss(symbol: String, positionSide: String, quantity: String, stopPrice: String): OrderResponseDto {
        // 模拟盘止损由 K 线流检测触发,此处把止损价写入本地持仓
        account.setStopLoss(symbol, stopPrice.toDoubleOrNull())
        return OrderResponseDto(
            orderId = orderSeq.getAndIncrement(),
            symbol = symbol,
            side = if (positionSide == "LONG") "SELL" else "BUY",
            positionSide = positionSide,
            type = "STOP_MARKET",
            status = "NEW",
            price = stopPrice,
            origQty = quantity,
            executedQty = "",
            avgPrice = "",
            stopPrice = stopPrice,
            reduceOnly = true,
        )
    }

    override suspend fun cancelOrder(symbol: String, orderId: Long) = Unit

    /** 模拟平仓:按最新价平掉指定数量(<=0 全平),返回成交价。 */
    override suspend fun closePosition(symbol: String, positionSide: String, quantity: String): Double {
        val price = latestPrice(symbol) ?: throw BinanceApiException(-1, "无法获取 ${symbol} 行情")
        val pos = account.position(symbol) ?: throw BinanceApiException(-2, "无 ${symbol} 持仓")
        val qty = quantity.toDoubleOrNull() ?: pos.qty
        if (qty <= 0.0 || qty >= pos.qty) {
            // 全平
            account.closePosition(symbol, price)
        } else {
            // 部分平仓:缩减数量(SimulatedAccount 目前按整体持仓模型,MVP 支持全平与按比例部分平)
            account.reducePosition(symbol, qty)
        }
        return price
    }

    /** 模拟止盈:写入本地持仓止盈价,由 K 线流检测触发。 */
    override suspend fun placeTakeProfit(symbol: String, positionSide: String, quantity: String, stopPrice: String): OrderResponseDto {
        account.setTakeProfit(symbol, stopPrice.toDoubleOrNull())
        return OrderResponseDto(
            orderId = orderSeq.getAndIncrement(),
            symbol = symbol,
            side = if (positionSide == "LONG") "SELL" else "BUY",
            positionSide = positionSide,
            type = "TAKE_PROFIT_MARKET",
            status = "NEW",
            price = stopPrice,
            origQty = quantity,
            executedQty = "",
            avgPrice = "",
            stopPrice = stopPrice,
            reduceOnly = true,
        )
    }

    override suspend fun setTakeProfit(symbol: String, takeProfitPrice: Double?) {
        account.setTakeProfit(symbol, takeProfitPrice)
    }

    override suspend fun getOrder(symbol: String, orderId: Long): OrderResponseDto =
        OrderResponseDto(
            orderId = orderId,
            symbol = symbol,
            side = "BUY",
            positionSide = "BOTH",
            type = "MARKET",
            status = "FILLED",
            price = "0",
            origQty = "0",
            executedQty = "0",
            avgPrice = "0",
        )

    override suspend fun setLeverage(symbol: String, leverage: Int) = Unit

    override suspend fun userTrades(symbol: String, limit: Int): List<UserTradeDto> = emptyList()

    // ---------- 用户数据流(模拟无真实流) ----------

    override suspend fun createListenKey(): String = "simulated-listen-key"

    override suspend fun extendListenKey() = Unit

    override suspend fun testConnection(): String = "%.2f USDT".format(account.balance)

    override suspend fun publicIp(): String = "本地模拟(无外网)"

    /** 模拟盘无币安档位,返回本地配置杠杆作为上限。 */
    override suspend fun leverageBrackets(): List<com.quant.app.data.network.dto.LeverageBracketDto> {
        val lev = configStore.load().leverage
        return listOf(
            com.quant.app.data.network.dto.LeverageBracketDto(
                symbol = "",
                brackets = listOf(
                    com.quant.app.data.network.dto.LeverageBracketDto.Bracket(
                        bracket = 1,
                        initialLeverage = lev,
                        notionalCap = Double.MAX_VALUE,
                        notionalFloor = 0.0,
                        maintenanceMarginRate = 0.005,
                    )
                ),
            )
        )
    }

    /**
     * 按最新价检测止损/止盈是否触发,触发则平仓并返回平仓信息。
     * 由 TradingService 在每根 K 线收盘时调用。
     * (suspend 函数不能加 @Synchronized;调用方 TradingService 已串行触发)
     */
    suspend fun checkAndTrigger(symbol: String, price: Double): ClosedSimTrade? {
        val pos = account.position(symbol) ?: return null
        val hit = when {
            pos.side == "LONG" && pos.stopLossPrice != null && price <= pos.stopLossPrice!! -> "STOPPED"
            pos.side == "LONG" && pos.takeProfitPrice != null && price >= pos.takeProfitPrice!! -> "TP"
            pos.side == "SHORT" && pos.stopLossPrice != null && price >= pos.stopLossPrice!! -> "STOPPED"
            pos.side == "SHORT" && pos.takeProfitPrice != null && price <= pos.takeProfitPrice!! -> "TP"
            else -> null
        } ?: return null
        val pnl = account.closePosition(symbol, price)
        return ClosedSimTrade(symbol, pos.side, pos.qty, pos.entryPrice, price, pnl ?: 0.0, hit)
    }

    /** 模拟平仓结果。 */
    data class ClosedSimTrade(
        val symbol: String,
        val side: String,
        val qty: Double,
        val entryPrice: Double,
        val closePrice: Double,
        val realizedPnl: Double,
        val reason: String,   // STOPPED / TP
    )

    // ---------- 内部 ----------

    private suspend fun latestPrices(): Map<String, Double> {
        val symbols = account.allPositions().map { it.symbol }.distinct()
        return symbols.associateWith { latestPrice(it) ?: 0.0 }
    }

    private suspend fun latestPrice(symbol: String): Double? =
        runCatchingS { market.klines(symbol, "1m", 1).firstOrNull()?.close }.getOrNull()
}
