package com.quant.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.quant.app.ui.screens.BacktestScreen
import com.quant.app.ui.screens.CockpitScreen
import com.quant.app.ui.screens.HistoryScreen
import com.quant.app.ui.screens.IntelligenceScreen
import com.quant.app.ui.screens.ReportScreen
import com.quant.app.ui.screens.SettingsScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "驾驶舱", Icons.Filled.AccountBalanceWallet),
    Report("report", "AI报告", Icons.Filled.Insights),
    Intelligence("intelligence", "情报", Icons.Filled.Newspaper),
    History("history", "历史", Icons.Filled.History),
    Settings("settings", "设置", Icons.Filled.Settings),
}

@Composable
fun QuantApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                    )
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Tab.Home.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(Tab.Home.route) {
                CockpitScreen(
                    viewModel = viewModel,
                    onOpenBacktest = { navController.navigate("backtest") },
                    onOpenSettings = { navController.navigate(Tab.Settings.route) },
                )
            }
            composable(Tab.Report.route) { ReportScreen(viewModel) }
            composable(Tab.Intelligence.route) { IntelligenceScreen(viewModel) }
            composable(Tab.History.route) { HistoryScreen(viewModel) }
            composable(Tab.Settings.route) { SettingsScreen(viewModel) }
            composable("backtest") { BacktestScreen(viewModel, onBack = { navController.popBackStack() }) }
        }
    }
}
