package com.quant.app.domain.trade

import com.quant.app.data.config.ConfigStore
import com.quant.app.data.db.dao.TradeDao
import com.quant.app.data.db.entity.TradeEntity
import com.quant.app.data.network.ExchangeApi
import com.quant.app.domain.model.OpenSignal
import com.quant.app.domain.model.OrderRequest
import com.quant.app.util.runCatchingS

/** 开仓结果。 */
sealed class TradeResult {
    data class Success(val trade: TradeEntity, val stopLossOrderId: Long?) : TradeResult()
    data class Failure(val reason: String) : TradeResult()
}

/** 平仓结果。 */
data class CloseResult(
    val symbol: String,
    val closePrice: Double,
    val realizedPnl: Double?,
)

/**
 * 下单执行器:
 * 设置杠杆 → 市价开仓 → 挂币安侧止损单(App 被杀也有保护)→ 记录交易。
 * 开仓与止损任一步失败都会回滚(尝试撤单)。
 */
class TradeExecutor(
    private val configStore: ConfigStore,
    private val api: ExchangeApi,
    private val riskManager: RiskManager,
    private val tradeDao: TradeDao,
) {
    private val config get() = configStore.load()

    suspend fun openPosition(signal: OpenSignal, mode: String): TradeResult {
        return try {
            // 1. 杠杆:查币安档位,配置超限时自动降至币安允许的最大杠杆
            val safeLeverage = resolveSafeLeverage(signal.symbol)
            runCatchingS { api.setLeverage(signal.symbol, safeLeverage) }
                .onFailure { e -> android.util.Log.w(TAG, "设置杠杆失败: ${e.message}") }

            // 2. 入场价:AI 给的 entry 优先,否则用最新收盘价
            val entry = signal.entryPrice
                ?: runCatchingS { api.klines(signal.symbol, config.interval, 1).firstOrNull()?.close }
                    .getOrNull()
                ?: return TradeResult.Failure("无法确定开仓价格")

            // 3. 数量(风控:单笔保证金上限 × 杠杆 / 价格,按交易所精度)
            val quantity = riskManager.computeQuantity(signal.symbol, entry)
            if (quantity.toDoubleOrNull()?.let { it <= 0.0 } ?: true) {
                return TradeResult.Failure("计算数量非法: $quantity")
            }

            // 4. 市价开仓
            val side = if (signal.direction == "long") "BUY" else "SELL"
            val openOrder = api.placeOrder(
                OrderRequest(
                    symbol = signal.symbol,
                    side = side,
                    positionSide = "BOTH",
                    type = "MARKET",
                    quantity = quantity,
                )
            )
            val filledQty = openOrder.executedQty.ifBlank { quantity }

            // 5. 币安侧止损单(强平保护底线)
            val slPrice = signal.stopLossPrice ?: fallbackStopLoss(entry, signal.direction)
            val stopOrder = runCatchingS {
                api.placeStopLoss(
                    symbol = signal.symbol,
                    positionSide = "BOTH",
                    quantity = filledQty,
                    stopPrice = formatPrice(slPrice, openOrder.price),
                )
            }.getOrNull()

            // 5.0 币安侧止盈单(TAKE_PROFIT_MARKET):实盘自动止盈落袋
            val tpOrder = runCatchingS {
                signal.takeProfitPrice?.let { tp ->
                    api.placeTakeProfit(
                        symbol = signal.symbol,
                        positionSide = "BOTH",
                        quantity = filledQty,
                        stopPrice = formatPrice(tp, openOrder.price),
                    )
                }
            }.getOrNull()

            // 5.1 回填止盈价(模拟盘用于本地触发)
            runCatchingS { api.setTakeProfit(signal.symbol, signal.takeProfitPrice) }

            // 6. 记录交易
            val trade = TradeEntity(
                orderId = openOrder.orderId,
                symbol = signal.symbol,
                side = side,
                positionSide = "BOTH",
                price = openOrder.avgPrice.ifBlank { openOrder.price }.toDoubleOrNull() ?: entry,
                qty = filledQty.toDoubleOrNull() ?: 0.0,
                status = openOrder.status,
                mode = mode,
                leverage = safeLeverage,
                stopLossPrice = slPrice,
                stopLossOrderId = stopOrder?.orderId,
                takeProfitPrice = signal.takeProfitPrice,
                takeProfitOrderId = tpOrder?.orderId,
                timestamp = System.currentTimeMillis(),
            )
            tradeDao.upsert(trade)
            TradeResult.Success(trade, stopOrder?.orderId)
        } catch (e: Exception) {
            android.util.Log.e(TAG, "开仓失败: ${e.message}", e)
            TradeResult.Failure(e.message ?: "未知错误")
        }
    }

    /**
     * 平仓(手动平仓/反转反手共用):
     * 市价平掉指定数量(<=0 全平)→ 更新最近一笔该币种交易为已平仓。
     * @return 成交价与已实现盈亏(模拟盘本地计算,实盘 pnl 为 null 由行情刷新补全)。
     */
    suspend fun closePosition(
        symbol: String,
        positionSide: String,
        quantity: String,
        mode: String,
    ): CloseResult {
        // 0. 先取消该币种残留的止损/止盈单,避免平仓后旧单悬挂在交易所
        runCatchingS {
            val recent = tradeDao.getRecentBySymbol(symbol, 1).firstOrNull()
            recent?.stopLossOrderId?.let { api.cancelOrder(symbol, it) }
            recent?.takeProfitOrderId?.let { api.cancelOrder(symbol, it) }
        }
        val closePrice = api.closePosition(symbol, positionSide, quantity)
        val pnl = runCatchingS {
            val qty = quantity.toDoubleOrNull()
            val pos = api.account().positions.firstOrNull { it.symbol == symbol && it.isOpen }
            val absAmt = kotlin.math.abs(pos?.positionAmt?.toDoubleOrNull() ?: 0.0)
            if (qty != null && qty > 0.0 && qty < absAmt) {
                // 部分平仓:MVP 不结算已实现盈亏,仅记录平仓价
                null
            } else {
                // 全平:更新最近一笔记录
                val trade = tradeDao.getRecentBySymbol(symbol, 1).firstOrNull()
                    ?.takeIf { it.realizedPnl == null }
                if (trade != null) {
                    val entry = trade.price
                    val dir = if (trade.side == "BUY") 1.0 else -1.0
                    val realized = dir * (closePrice - entry) * trade.qty
                    tradeDao.markClosed(
                        orderId = trade.orderId,
                        status = "CLOSED",
                        pnl = realized,
                        closedAt = System.currentTimeMillis(),
                        closedPrice = closePrice,
                    )
                    realized
                } else {
                    null
                }
            }
        }.getOrNull()
        return CloseResult(symbol, closePrice, pnl)
    }

    /** 兜底止损:AI 未给止损时按入场价 ±2%。 */
    private fun fallbackStopLoss(entry: Double, direction: String): Double {
        val delta = entry * 0.02
        return if (direction == "long") entry - delta else entry + delta
    }

    /**
     * 解析安全杠杆:查币安杠杆档位,配置超过币安上限时自动降至上限。
     * 查询失败/无档位数据时退回配置值(不阻断开仓)。
     */
    private suspend fun resolveSafeLeverage(symbol: String): Int {
        val configured = config.leverage
        return runCatchingS {
            api.leverageBrackets()
                .firstOrNull { it.symbol == symbol }
                ?.maxLeverage
                ?.let { max -> minOf(configured, max) }
                ?: configured
        }.getOrDefault(configured)
    }

    private fun formatPrice(price: Double, reference: String): String {
        val decimals = reference.substringAfter('.', "").length.coerceIn(0, 8)
        return String.format("%.${decimals}f", price)
    }

    companion object {
        private const val TAG = "TradeExecutor"
    }
}
