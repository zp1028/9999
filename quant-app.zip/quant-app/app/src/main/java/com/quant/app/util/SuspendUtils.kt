package com.quant.app.util

/**
 * 挂起安全版 runCatching:block 可为挂起 lambda。
 * 标准库 runCatching 的 block 是 `() -> R`(非挂起),在其内部调用挂起函数
 * 会编译报错 "Suspend function should be called only from a coroutine"。
 * 凡是在协程/挂起函数中需要捕获挂起调用异常的代码,统一使用本函数。
 */
suspend fun <T> runCatchingS(block: suspend () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (e: Throwable) {
        Result.failure(e)
    }
