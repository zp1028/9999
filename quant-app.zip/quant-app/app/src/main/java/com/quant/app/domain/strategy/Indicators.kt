package com.quant.app.domain.strategy

import com.quant.app.data.db.entity.KlineEntity

/**
 * 技术指标纯函数库(无状态,输入 K线序列,输出指标值)。
 * 供各策略复用,避免重复实现。
 */
object Indicators {

    /** 简单移动平均。返回最近 period 根收盘价的均值;数据不足返回 null。 */
    fun ma(klines: List<KlineEntity>, period: Int): Double? {
        if (klines.size < period) return null
        return klines.takeLast(period).map { it.close }.average()
    }

    /** 均线序列(从 index 起每根计算 MA)。 */
    fun maSeries(klines: List<KlineEntity>, period: Int): List<Double> {
        if (klines.size < period) return emptyList()
        return (period - 1 until klines.size).map { i ->
            klines.subList(i - period + 1, i + 1).map { it.close }.average()
        }
    }

    /** RSI(相对强弱指标),默认 14 周期。返回 0~100;数据不足返回 null。 */
    fun rsi(klines: List<KlineEntity>, period: Int = 14): Double? {
        if (klines.size < period + 1) return null
        var gain = 0.0
        var loss = 0.0
        for (i in klines.size - period until klines.size) {
            val diff = klines[i].close - klines[i - 1].close
            if (diff >= 0) gain += diff else loss -= diff
        }
        val avgGain = gain / period
        val avgLoss = loss / period
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - 100.0 / (1.0 + rs)
    }

    /** 布林带。返回 (中轨, 上轨, 下轨);数据不足返回 null。 */
    fun bollinger(klines: List<KlineEntity>, period: Int = 20, k: Double = 2.0): Triple<Double, Double, Double>? {
        if (klines.size < period) return null
        val closes = klines.takeLast(period).map { it.close }
        val mid = closes.average()
        val variance = closes.map { (it - mid) * (it - mid) }.average()
        val std = kotlin.math.sqrt(variance)
        return Triple(mid, mid + k * std, mid - k * std)
    }

    /** MACD。返回 (DIF, DEA, 柱)。数据不足返回 null。 */
    fun macd(klines: List<KlineEntity>, fast: Int = 12, slow: Int = 26, signal: Int = 9): Triple<Double, Double, Double>? {
        val closes = klines.map { it.close }
        if (closes.size < slow + signal) return null
        val emaFast = ema(closes, fast)
        val emaSlow = ema(closes, slow)
        val dif = emaFast - emaSlow
        // 用最近 signal 个 DIF 的 EMA 作为 DEA(简化)
        val difSeries = (signal - 1 until closes.size).map { i ->
            ema(closes.subList(0, i + 1), fast) - ema(closes.subList(0, i + 1), slow)
        }
        val dea = difSeries.takeLast(signal).average()
        return Triple(dif, dea, (dif - dea) * 2.0)
    }

    /** EMA 序列最后一个值。 */
    private fun ema(values: List<Double>, period: Int): Double {
        if (values.size < period) return values.average()
        val multiplier = 2.0 / (period + 1)
        var ema = values.take(period).average()
        for (i in period until values.size) {
            ema = (values[i] - ema) * multiplier + ema
        }
        return ema
    }

    /** 最近 N 根的最高价。 */
    fun highest(klines: List<KlineEntity>, period: Int): Double? {
        if (klines.isEmpty()) return null
        return klines.takeLast(period).maxOfOrNull { it.high }
    }

    /** 最近 N 根的最低价。 */
    fun lowest(klines: List<KlineEntity>, period: Int): Double? {
        if (klines.isEmpty()) return null
        return klines.takeLast(period).minOfOrNull { it.low }
    }
}
