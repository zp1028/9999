package com.quant.app.domain.strategy

import com.quant.app.data.db.entity.KlineEntity
import com.quant.app.domain.model.AppConfig

/**
 * 均值回归策略:物极必反。
 * 规则:
 * - RSI < 超卖阈值 且价格触及布林带下轨 → 做多(押注回归);
 * - RSI > 超买阈值 且价格触及布林带上轨 → 做空;
 * - 否则观望。
 * RSI 周期/阈值/止损止盈均可通过设置页配置。
 */
class MeanReversionStrategy(
    private val configProvider: () -> AppConfig,
) : Strategy {
    override val id = "mean_reversion"
    override val label = "均值回归"
    override val needsAi = false

    override suspend fun evaluate(symbol: String, interval: String, klines: List<KlineEntity>): StrategySignal {
        if (klines.size < 20) return StrategySignal("neutral", 0.0, reason = "K线不足")
        val cfg = configProvider()
        val last = klines.last()
        val rsi = Indicators.rsi(klines, cfg.meanRsiPeriod) ?: return neutral()
        val (mid, upper, lower) = Indicators.bollinger(klines, 20, 2.0) ?: return neutral()
        val slPct = cfg.strategySlPct / 100.0
        val tpPct = cfg.strategyTpPct / 100.0

        return when {
            rsi < cfg.meanOversold && last.close <= lower -> {
                val entry = last.close
                StrategySignal(
                    direction = "long",
                    confidence = 0.7,
                    entry = entry,
                    stopLoss = entry * (1 - slPct),
                    takeProfit = entry * (1 + tpPct),
                    reason = "RSI超卖(${"%.0f".format(rsi)}),触及布林下轨",
                )
            }
            rsi > cfg.meanOverbought && last.close >= upper -> {
                val entry = last.close
                StrategySignal(
                    direction = "short",
                    confidence = 0.7,
                    entry = entry,
                    stopLoss = entry * (1 + slPct),
                    takeProfit = entry * (1 - tpPct),
                    reason = "RSI超买(${"%.0f".format(rsi)}),触及布林上轨",
                )
            }
            else -> neutral("RSI ${"%.0f".format(rsi)},未到极值")
        }
    }

    private fun neutral(reason: String = "观望") = StrategySignal("neutral", 0.0, reason = reason)
}
