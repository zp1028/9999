package com.quant.app.data.network

import com.quant.app.data.network.dto.AccountDto
import com.quant.app.data.network.dto.ExchangeInfoDto
import com.quant.app.data.network.dto.KlineDto
import com.quant.app.data.network.dto.OrderResponseDto
import com.quant.app.data.network.dto.PositionDto
import com.quant.app.data.network.dto.UserTradeDto
import com.quant.app.domain.model.OrderRequest

/**
 * 交易所接口抽象。
 * 真实实现 [BinanceApiClient](币安 REST),模拟实现 [SimulatedApiClient](本地撮合)。
 * 引擎层(TradeExecutor/SignalEngine/RiskManager/PnlTracker)只依赖此接口,
 * 由 QuantApplication 按 TradingMode 装配,实现"模拟盘无需币安 Key"。
 */
interface ExchangeApi {

    // ---------- 公开行情(无需签名) ----------

    suspend fun klines(symbol: String, interval: String, limit: Int): List<KlineDto>

    suspend fun exchangeInfo(): ExchangeInfoDto

    suspend fun hotSymbols(limit: Int): List<String>

    suspend fun serverTime(): Long

    // ---------- 账户与交易(需签名) ----------

    suspend fun account(): AccountDto

    suspend fun positionRisk(): List<PositionDto>

    suspend fun placeOrder(request: OrderRequest): OrderResponseDto

    suspend fun placeStopLoss(symbol: String, positionSide: String, quantity: String, stopPrice: String): OrderResponseDto

    /**
     * 市价平仓(手动平仓/反转反手用)。
     * 真实实现:下 reduceOnly MARKET 单,方向与持仓相反;模拟实现:本地按最新价平仓。
     * @param quantity 平仓数量(<=0 表示全平)
     * @return 平仓成交价
     */
    suspend fun closePosition(symbol: String, positionSide: String, quantity: String): Double

    /**
     * 挂止盈单(TAKE_PROFIT_MARKET,实盘自动止盈)。
     * 模拟实现:本地记录止盈价(由 K 线流检测触发)。
     */
    suspend fun placeTakeProfit(symbol: String, positionSide: String, quantity: String, stopPrice: String): OrderResponseDto

    /** 为持仓设置止盈价(开仓后回填)。真实实现可挂 TAKE_PROFIT 单,模拟实现本地记录。 */
    suspend fun setTakeProfit(symbol: String, takeProfitPrice: Double?)

    suspend fun cancelOrder(symbol: String, orderId: Long)

    suspend fun getOrder(symbol: String, orderId: Long): OrderResponseDto

    suspend fun setLeverage(symbol: String, leverage: Int)

    suspend fun userTrades(symbol: String, limit: Int): List<UserTradeDto>

    // ---------- 用户数据流(listenKey) ----------

    suspend fun createListenKey(): String

    suspend fun extendListenKey()

    /**
     * 连接测试:验证当前环境凭据是否有效。
     * 真实实现调用 account() 校验 Key;模拟实现恒成功。
     * @return 成功时返回账户权益字符串(如 "1,234.56 USDT"),失败抛异常。
     */
    suspend fun testConnection(): String

    /** 获取当前出口公网 IP(用于排查币安地区限制)。模拟盘返回本地标识。 */
    suspend fun publicIp(): String

    /** 查询币安杠杆档位(含最大杠杆/维持保证金率)。模拟盘返回本地默认。 */
    suspend fun leverageBrackets(): List<com.quant.app.data.network.dto.LeverageBracketDto>
}
