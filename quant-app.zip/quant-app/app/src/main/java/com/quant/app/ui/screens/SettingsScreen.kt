package com.quant.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.quant.app.domain.model.AppConfig
import com.quant.app.domain.model.PositionMode
import com.quant.app.domain.model.TradingMode
import com.quant.app.ui.MainViewModel
import com.quant.app.util.BatteryOptimizationHelper

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val config by viewModel.configState.collectAsState()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val publicIp by viewModel.publicIp.collectAsState()
    val testResult by viewModel.testResult.collectAsState()

    var testnetApiKey by remember { mutableStateOf(config.testnetApiKey) }
    var testnetSecret by remember { mutableStateOf(config.testnetSecretKey) }
    var liveApiKey by remember { mutableStateOf(config.liveApiKey) }
    var liveSecret by remember { mutableStateOf(config.liveSecretKey) }
    var deepseekKey by remember { mutableStateOf(config.deepseekApiKey) }
    var mode by remember { mutableStateOf(config.mode) }
    var simulatedBalance by remember { mutableStateOf(config.simulatedBalance.toString()) }
    var autoTrade by remember { mutableStateOf(config.autoTrade) }
    var showLiveConfirm by remember { mutableStateOf(false) }
    var threshold by remember { mutableStateOf(config.confidenceThreshold.toString()) }
    var leverage by remember { mutableStateOf(config.leverage.toString()) }
    var maxPosition by remember { mutableStateOf(config.maxPositionUsd.toString()) }
    var positionMode by remember { mutableStateOf(config.positionMode) }
    var positionPercent by remember { mutableStateOf(config.positionPercent.toString()) }
    var maxLoss by remember { mutableStateOf(config.maxDailyLossPct.toString()) }
    var cooldown by remember { mutableStateOf(config.cooldownMinutes.toString()) }
    var interval by remember { mutableStateOf(config.interval) }
    var symbols by remember { mutableStateOf(config.symbols.joinToString(",")) }
    var strategyId by remember { mutableStateOf(config.strategyId) }
    var showMarketDialog by remember { mutableStateOf(false) }

    // 策略参数
    var trendMaFast by remember { mutableStateOf(config.trendMaFast.toString()) }
    var trendMaSlow by remember { mutableStateOf(config.trendMaSlow.toString()) }
    var trendConfidence by remember { mutableStateOf(config.trendConfidence.toString()) }
    var meanRsiPeriod by remember { mutableStateOf(config.meanRsiPeriod.toString()) }
    var meanOversold by remember { mutableStateOf(config.meanOversold.toString()) }
    var meanOverbought by remember { mutableStateOf(config.meanOverbought.toString()) }
    var gridCount by remember { mutableStateOf(config.gridCount.toString()) }
    var slPct by remember { mutableStateOf(config.strategySlPct.toString()) }
    var tpPct by remember { mutableStateOf(config.strategyTpPct.toString()) }
    var maxPositions by remember { mutableStateOf(config.maxOpenPositions.toString()) }
    var liveGuard by remember { mutableStateOf(config.liveAutoTradeGuard) }

    val message by viewModel.message.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
        Text("设置", style = MaterialTheme.typography.titleLarge)

        // ---- 密钥 ----
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("API 密钥(加密存储,按模式隔离)", style = MaterialTheme.typography.titleSmall)
                if (mode == TradingMode.SIMULATED) {
                    Text(
                        "模拟盘无需币安 Key,仅需下方 AI Key。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    val isLive = mode == TradingMode.LIVE
                    Text(
                        if (isLive) "实盘 Key(fapi.binance.com)" else "测试网 Key(testnet.binancefuture.com)",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    OutlinedTextField(
                        value = if (isLive) liveApiKey else testnetApiKey,
                        onValueChange = { if (isLive) liveApiKey = it else testnetApiKey = it },
                        label = { Text("API Key") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = if (isLive) liveSecret else testnetSecret,
                        onValueChange = { if (isLive) liveSecret = it else testnetSecret = it },
                        label = { Text("Secret Key") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                OutlinedTextField(
                    value = deepseekKey,
                    onValueChange = { deepseekKey = it },
                    label = { Text("AI API Key(共享)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(
                    onClick = { viewModel.testConnection() },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (mode == TradingMode.SIMULATED) "测试模拟账户" else "测试币安连接")
                }
                publicIp?.let { ip ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                clipboard.setText(AnnotatedString(ip))
                                viewModel.setMessage("已复制 IP: $ip")
                            },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                    ) {
                        Text(
                            "出口IP: $ip",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            "📋 点击复制",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }

        // ---- 交易模式 ----
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("交易模式", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChip("模拟盘", TradingMode.SIMULATED, mode) { mode = TradingMode.SIMULATED }
                    ModeChip("测试网", TradingMode.TESTNET, mode) { mode = TradingMode.TESTNET }
                    ModeChip("实盘", TradingMode.LIVE, mode) { showLiveConfirm = true }
                }
                if (mode == TradingMode.SIMULATED) {
                    Text(
                        "模拟盘无需币安 Key,本地撮合真实行情,可自由调整初始资金。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = simulatedBalance,
                        onValueChange = { simulatedBalance = it },
                        label = { Text("模拟初始资金 USDT") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedButton(
                        onClick = { viewModel.resetSimulatedAccount() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("重置模拟账户(清空持仓)")
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text("自动下单", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "关闭=仅出建议人工确认(推荐);开启=AI 信号自动下单",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = autoTrade, onCheckedChange = { autoTrade = it })
                }
            }
        }

        // ---- 策略选择 ----
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("交易策略", style = MaterialTheme.typography.titleSmall)
                Text(
                    "选择引擎使用的策略,驾驶舱首页也可快速切换。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StrategyChip("AI智能", "ai", strategyId) { strategyId = "ai" }
                    StrategyChip("趋势跟踪", "trend", strategyId) { strategyId = "trend" }
                    StrategyChip("均值回归", "mean_reversion", strategyId) { strategyId = "mean_reversion" }
                    StrategyChip("网格", "grid", strategyId) { strategyId = "grid" }
                }
            }
        }

        // ---- 策略参数 ----
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("策略参数(按当前策略生效)", style = MaterialTheme.typography.titleSmall)
                when (strategyId) {
                    "trend" -> {
                        Text("趋势跟踪:均线周期与置信度", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = trendMaFast,
                                onValueChange = { trendMaFast = it },
                                label = { Text("快线 MA 周期") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                            OutlinedTextField(
                                value = trendMaSlow,
                                onValueChange = { trendMaSlow = it },
                                label = { Text("慢线 MA 周期") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                        }
                        OutlinedTextField(
                            value = trendConfidence,
                            onValueChange = { trendConfidence = it },
                            label = { Text("置信度(0~1)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    "mean_reversion" -> {
                        Text("均值回归:RSI 周期与阈值", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = meanRsiPeriod,
                                onValueChange = { meanRsiPeriod = it },
                                label = { Text("RSI 周期") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                            OutlinedTextField(
                                value = meanOversold,
                                onValueChange = { meanOversold = it },
                                label = { Text("超卖阈值") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                            OutlinedTextField(
                                value = meanOverbought,
                                onValueChange = { meanOverbought = it },
                                label = { Text("超买阈值") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                    "grid" -> {
                        Text("网格:区间等分格数", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = gridCount,
                            onValueChange = { gridCount = it },
                            label = { Text("网格格数(≥2)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    else -> {
                        Text(
                            "AI 策略使用上方「置信度阈值」,无专属参数。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Text("规则策略通用止损/止盈(%)", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = slPct,
                        onValueChange = { slPct = it },
                        label = { Text("止损 %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = tpPct,
                        onValueChange = { tpPct = it },
                        label = { Text("止盈 %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        // ---- 策略参数 ----
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("策略与风控参数", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = threshold,
                    onValueChange = { threshold = it },
                    label = { Text("置信度阈值(0~1,默认0.7)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = leverage,
                    onValueChange = { leverage = it },
                    label = { Text("杠杆倍数(1~125)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("仓位模式(决定开仓金额/数量)", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChip("固定金额", PositionMode.FIXED_USD, positionMode) { positionMode = PositionMode.FIXED_USD }
                    ModeChip("账户百分比", PositionMode.PERCENT, positionMode) { positionMode = PositionMode.PERCENT }
                }
                if (positionMode == PositionMode.FIXED_USD) {
                    OutlinedTextField(
                        value = maxPosition,
                        onValueChange = { maxPosition = it },
                        label = { Text("单笔开仓保证金 USDT(开仓金额)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    OutlinedTextField(
                        value = positionPercent,
                        onValueChange = { positionPercent = it },
                        label = { Text("单笔开仓占账户权益 %(仓位比例)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                OutlinedTextField(
                    value = maxLoss,
                    onValueChange = { maxLoss = it },
                    label = { Text("当日亏损熔断 %") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = cooldown,
                    onValueChange = { cooldown = it },
                    label = { Text("同币种冷却(分钟)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = interval,
                    onValueChange = { interval = it },
                    label = { Text("K线周期(如 15m/1h/4h/1d)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = symbols,
                    onValueChange = { symbols = it },
                    label = { Text("监控币种(逗号分隔,如 BTCUSDT,ETHUSDT)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = maxPositions,
                    onValueChange = { maxPositions = it },
                    label = { Text("最大同时持仓数(1~20)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (mode == TradingMode.LIVE) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text("实盘自动交易确认", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "实盘+自动下单 需开启此开关,防止误配真钱裸跑",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(checked = liveGuard, onCheckedChange = { liveGuard = it })
                    }
                }
                OutlinedButton(
                    onClick = { showMarketDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("🔍 搜索市场交易对(标注合约类型)")
                }
            }
        }

        // ---- 保存与系统设置 ----
        Button(
            onClick = {
                val saved = config.copy(
                    testnetApiKey = testnetApiKey.trim(),
                    testnetSecretKey = testnetSecret.trim(),
                    liveApiKey = liveApiKey.trim(),
                    liveSecretKey = liveSecret.trim(),
                    deepseekApiKey = deepseekKey.trim(),
                    mode = mode,
                    simulatedBalance = simulatedBalance.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 1000.0,
                    autoTrade = autoTrade,
                    confidenceThreshold = threshold.toDoubleOrNull()?.coerceIn(0.0, 1.0) ?: 0.7,
                    leverage = leverage.toIntOrNull()?.coerceIn(1, 125) ?: 3,
                    maxPositionUsd = maxPosition.toDoubleOrNull() ?: 100.0,
                    positionMode = positionMode,
                    positionPercent = positionPercent.toDoubleOrNull()?.coerceIn(0.1, 100.0) ?: 20.0,
                    maxDailyLossPct = maxLoss.toDoubleOrNull() ?: 5.0,
                    cooldownMinutes = cooldown.toIntOrNull() ?: 30,
                    interval = interval.trim().ifBlank { "15m" },
                    symbols = symbols.split(",").map { it.trim() }.filter { it.isNotBlank() }
                        .ifEmpty { listOf("BTCUSDT") },
                    strategyId = strategyId,
                    trendMaFast = trendMaFast.toIntOrNull()?.coerceIn(2, 200) ?: 5,
                    trendMaSlow = trendMaSlow.toIntOrNull()?.coerceIn(3, 300) ?: 20,
                    trendConfidence = trendConfidence.toDoubleOrNull()?.coerceIn(0.0, 1.0) ?: 0.75,
                    meanRsiPeriod = meanRsiPeriod.toIntOrNull()?.coerceIn(2, 100) ?: 14,
                    meanOversold = meanOversold.toDoubleOrNull()?.coerceIn(1.0, 49.0) ?: 30.0,
                    meanOverbought = meanOverbought.toDoubleOrNull()?.coerceIn(51.0, 99.0) ?: 70.0,
                    gridCount = gridCount.toIntOrNull()?.coerceIn(2, 20) ?: 5,
                    strategySlPct = slPct.toDoubleOrNull()?.coerceIn(0.1, 20.0) ?: 2.0,
                    strategyTpPct = tpPct.toDoubleOrNull()?.coerceIn(0.1, 100.0) ?: 4.0,
                    maxOpenPositions = maxPositions.toIntOrNull()?.coerceIn(1, 20) ?: 3,
                    liveAutoTradeGuard = liveGuard,
                )
                viewModel.saveConfig(saved)
            },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("保存配置")
        }

        OutlinedButton(
            onClick = {
                BatteryOptimizationHelper.requestIgnoreBatteryOptimizations(context)
            },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("引导加入电池白名单(保活)")
        }

        val ignoring = remember {
            BatteryOptimizationHelper.isIgnoringBatteryOptimizations(context)
        }
        Text(
            "电池优化状态:${if (ignoring) "已忽略" else "未忽略(建议开启)"}",
            style = MaterialTheme.typography.bodySmall,
        )
        Text(
            "安全提醒:币安 API Key 请勿开通提现权限;更换设备需重新填写密钥。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        }
        SnackbarHost(hostState = snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))
    }

    if (showLiveConfirm) {
        AlertDialog(
            onDismissRequest = { showLiveConfirm = false },
            title = { Text("切换到实盘?") },
            text = {
                Text(
                    "实盘模式将使用真实资金交易(fapi.binance.com)。\n\n" +
                        "请确认:\n" +
                        "1. 已填写实盘 API Key 且未开通提现权限;\n" +
                        "2. 已理解强平、资金费率与本金亏损风险;\n" +
                        "3. 建议先在测试网充分验证后小资金实盘。"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    mode = TradingMode.LIVE
                    showLiveConfirm = false
                }) {
                    Text("确认切换")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLiveConfirm = false }) { Text("取消") }
            },
        )
    }

    // 连接测试结果弹窗
    testResult?.let { result ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissTestResult() },
            title = {
                Text(
                    if (result.success) "✅ 连接成功" else "❌ 连接失败",
                    color = if (result.success) Color(0xFF22C55E) else Color(0xFFEF4444),
                )
            },
            text = {
                Text(result.message, style = MaterialTheme.typography.bodyMedium)
            },
            confirmButton = {
                TextButton(onClick = { viewModel.dismissTestResult() }) {
                    Text("确定")
                }
            },
        )
    }

    // 市场交易对搜索弹窗
    if (showMarketDialog) {
        MarketSearchDialog(
            viewModel = viewModel,
            currentSymbols = symbols.split(",").map { it.trim() }.filter { it.isNotBlank() },
            onAdd = { sym ->
                val list = symbols.split(",").map { it.trim() }.filter { it.isNotBlank() }
                if (sym !in list) {
                    symbols = (list + sym).joinToString(",")
                }
            },
            onDismiss = { showMarketDialog = false },
        )
    }
}

@Composable
private fun <T> ModeChip(
    label: String,
    mode: T,
    current: T,
    onSelect: () -> Unit,
) {
    val selected = current == mode
    if (selected) {
        Button(onClick = onSelect) { Text(label) }
    } else {
        OutlinedButton(onClick = onSelect) { Text(label) }
    }
}

@Composable
private fun StrategyChip(
    label: String,
    id: String,
    current: String,
    onSelect: () -> Unit,
) {
    val selected = current == id
    if (selected) {
        Button(onClick = onSelect) { Text(label) }
    } else {
        OutlinedButton(onClick = onSelect) { Text(label) }
    }
}

/** 市场交易对搜索弹窗:从币安 exchangeInfo 拉取 USDT 合约,支持搜索并标注合约类型。 */
@Composable
private fun MarketSearchDialog(
    viewModel: MainViewModel,
    currentSymbols: List<String>,
    onAdd: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val marketSymbols by viewModel.marketSymbols.collectAsState()
    val marketLoading by viewModel.marketLoading.collectAsState()
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        if (marketSymbols.isEmpty()) viewModel.refreshMarket()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("搜索市场交易对(USDT 合约)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("搜索: BTC / ETH / SOL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (marketLoading) {
                    Text("从币安加载中...", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                } else {
                    val result = viewModel.searchMarket(query)
                    if (result.isEmpty()) {
                        Text("无匹配交易对(或拉取失败,点重试)", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    } else {
                        androidx.compose.foundation.lazy.LazyColumn(
                            modifier = Modifier.height(360.dp),
                        ) {
                            androidx.compose.foundation.lazy.items(result, key = { it.symbol }) { m ->
                                val added = m.symbol in currentSymbols
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { if (!added) onAdd(m.symbol) }
                                        .padding(vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                                ) {
                                    Column {
                                        Text(m.symbol, style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            m.contractLabel,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    Text(
                                        if (added) "已添加 ✓" else "+ 添加",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (added) Color(0xFF22C55E) else MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("完成") }
        },
        dismissButton = {
            TextButton(onClick = { viewModel.refreshMarket() }) { Text("刷新") }
        },
    )
}
