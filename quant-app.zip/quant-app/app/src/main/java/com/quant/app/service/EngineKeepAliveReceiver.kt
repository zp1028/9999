package com.quant.app.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * 心跳保活:AlarmManager 每 30 分钟检查一次引擎。
 * 若引擎曾运行但当前进程已死(isRunning=false) → 自动重启前台服务。
 * 说明:Android 12+ 后台启动前台服务受限,若本次启动被系统拒绝,
 * 等下一轮心跳或下次用户打开 App 时恢复(START_STICKY 兜底)。
 */
class EngineKeepAliveReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_KEEPALIVE) return
        if (TradingService.wasRunning(context) && !TradingService.isRunning) {
            runCatching { TradingService.start(context) }
                .onFailure { e -> android.util.Log.w(TAG, "心跳重启引擎失败: ${e.message}") }
        }
        // 继续下一轮心跳
        schedule(context)
    }

    companion object {
        private const val TAG = "EngineKeepAliveReceiver"
        private const val ACTION_KEEPALIVE = "com.quant.app.action.KEEPALIVE"
        private const val INTERVAL_MS = 30 * 60 * 1000L

        fun schedule(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                context,
                0,
                Intent(context, EngineKeepAliveReceiver::class.java).setAction(ACTION_KEEPALIVE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            // setAndAllowWhileIdle:Doze 模式下仍可唤醒,允许一定延迟
            am.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + INTERVAL_MS,
                pi,
            )
        }

        fun cancel(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                context,
                0,
                Intent(context, EngineKeepAliveReceiver::class.java).setAction(ACTION_KEEPALIVE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            am.cancel(pi)
        }
    }
}
