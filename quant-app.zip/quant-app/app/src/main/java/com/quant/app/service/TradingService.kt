package com.quant.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import com.quant.app.QuantApplication
import com.quant.app.data.network.websocket.KlineStreamEvent
import com.quant.app.util.runCatchingS
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * 量化引擎前台服务(保活核心):
 * - 前台服务 + 常驻通知,降低被系统杀死的概率;
 * - 启动 K线订阅 → 每根 K线收盘触发 AI 分析 → 按模式(建议/自动)处理;
 * - START_STICKY:被系统回收后自动重启。
 */
class TradingService : Service() {

    private val app get() = application as QuantApplication
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var engineStarted = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            setRunning(this, false)
            EngineKeepAliveReceiver.cancel(this)
            stopEngine()
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(
            NOTIFICATION_ID,
            NotificationHelper.statusNotification(this, "初始化中..."),
        )
        startEngine()
        return START_STICKY
    }

    override fun onDestroy() {
        val wasRunningBefore = engineStarted
        stopEngine()
        scope.cancel()
        // 被系统回收(引擎曾运行) → 保留运行标志,供开机/心跳恢复;手动停止则清除
        setRunning(this, wasRunningBefore)
        super.onDestroy()
    }

    private fun startEngine() {
        if (engineStarted) return
        val config = app.configStore.load()
        val missing = config.missingConfigHint
        if (missing != null) {
            NotificationHelper.notifyAlert(this, "配置缺失", missing)
            updateStatus(missing)
            return
        }
        // 实盘安全:实盘 + 自动下单 必须开启保护确认(开机自启/心跳恢复同样受此保护)
        if (config.mode == com.quant.app.domain.model.TradingMode.LIVE &&
            config.autoTrade &&
            !config.liveAutoTradeGuard
        ) {
            NotificationHelper.notifyAlert(
                this,
                "实盘保护未开启",
                "实盘自动交易需先在设置页开启「实盘自动交易确认」",
            )
            updateStatus("实盘保护未开启,已拒绝启动")
            return
        }
        engineStarted = true

        app.klineRepository.onKlineClosed = { event -> handleKlineClosed(event) }
        app.predictionAlertEngine.onAlert = { title, text ->
            NotificationHelper.notifyAlert(this@TradingService, title, text)
        }
        app.userDataStreamer.onStopLossTriggered = { symbol, orderId ->
            NotificationHelper.notifyAlert(
                this@TradingService,
                "止损已触发",
                "$symbol 止损单已成交(orderId=$orderId)",
            )
        }
        app.klineRepository.start(config.symbols, config.interval)
        // 模拟盘无真实用户数据流,止损/止盈由 K 线流检测触发
        if (config.mode != com.quant.app.domain.model.TradingMode.SIMULATED) {
            app.userDataStreamer.start()
        }
        app.pnlTracker.start()
        setRunning(this, true)
        updateStatus("监控 ${config.symbols.joinToString()} · ${config.interval}")
    }

    private fun handleKlineClosed(event: KlineStreamEvent) {
        scope.launch {
            val config = app.configStore.load()
            val klines = app.klineRepository.getRecent(event.symbol, event.interval, config.aiKlineContext)
            if (klines.size < 20) {
                android.util.Log.w(TAG, "${event.symbol} K线数据不足(${klines.size}),跳过分析")
                return@launch
            }
            try {
                // 0. 模拟盘:按最新收盘价检测止损/止盈触发
                if (config.mode == com.quant.app.domain.model.TradingMode.SIMULATED) {
                    runCatchingS {
                        val closed = (app.exchangeApi as? com.quant.app.data.network.SimulatedApiClient)
                            ?.checkAndTrigger(event.symbol, event.close)
                        if (closed != null) {
                            app.database.tradeDao().getRecentBySymbol(event.symbol, 1)
                                .firstOrNull()?.let { trade ->
                                    app.database.tradeDao().markClosed(
                                        orderId = trade.orderId,
                                        status = closed.reason,
                                        pnl = closed.realizedPnl,
                                        closedAt = System.currentTimeMillis(),
                                        closedPrice = closed.closePrice,
                                    )
                                }
                            NotificationHelper.notifyAlert(
                                this@TradingService,
                                "模拟${if (closed.reason == "STOPPED") "止损" else "止盈"}触发",
                                "${closed.symbol} 平仓 @ ${"%.2f".format(closed.closePrice)} · 盈亏 ${"%.2f".format(closed.realizedPnl)} USDT",
                            )
                        }
                    }.onFailure { e -> android.util.Log.w(TAG, "模拟止损检测失败: ${e.message}") }
                }

                // 1. 定时刷新新闻情报(内部限频)+ 预测破位检测/生成
                runCatchingS { app.newsRepository.refresh() }
                    .onFailure { e -> android.util.Log.w(TAG, "新闻刷新失败: ${e.message}") }
                app.predictionAlertEngine.onKlineClosed(event)

                // 2. 按当前策略生成信号(AI 策略会落库分析记录)
                val strategyId = config.strategyId
                val strategy = app.strategyEngine.get(strategyId)
                if (strategy == null) {
                    android.util.Log.w(TAG, "未知策略: $strategyId")
                    return@launch
                }
                val signal = app.strategyEngine.evaluate(strategyId, event.symbol, event.interval, klines)
                    ?: return@launch
                if (signal.direction == "neutral") return@launch
                val aiSignal = com.quant.app.data.network.dto.AiSignalDto(
                    direction = signal.direction,
                    confidence = signal.confidence,
                    entry = signal.entry,
                    stopLoss = signal.stopLoss,
                    takeProfit = signal.takeProfit,
                    reasons = listOf(signal.reason),
                )
                NotificationHelper.notifyAiReport(this@TradingService, event.symbol, aiSignal)

                // 2. 按模式处理
                if (config.autoTrade) {
                    // 自动模式:规则通过则直接下单
                    app.tradingOrchestrator.onAiSignal(
                        symbol = event.symbol,
                        signal = aiSignal,
                        mode = "AUTO",
                        onResult = { result ->
                            NotificationHelper.notifyTrade(this@TradingService, event.symbol, result)
                        },
                    )
                }
                // 建议模式:仅通知,人工确认下单由 UI 触发(S7)
            } catch (e: Exception) {
                NotificationHelper.notifyAlert(this@TradingService, "AI 分析失败", e.message ?: "未知错误")
            }
        }
    }

    private fun stopEngine() {
        engineStarted = false
        // 行情流为 App 级生命周期(打开 App 即同步,见 MainViewModel.init),
        // 引擎停止只解除分析回调,不影响情报页/驾驶舱行情展示
        app.klineRepository.onKlineClosed = null
        app.userDataStreamer.stop()
        app.pnlTracker.stop()
        app.predictionAlertEngine.onAlert = null
        app.userDataStreamer.onStopLossTriggered = null
    }
    private fun updateStatus(text: String) {
        val manager = getSystemService(android.app.NotificationManager::class.java)
        manager?.notify(
            NOTIFICATION_ID,
            NotificationHelper.statusNotification(this, text),
        )
    }

    companion object {
        private const val TAG = "TradingService"
        private const val NOTIFICATION_ID = 1
        private const val ACTION_STOP = "com.quant.app.action.STOP_TRADING"
        private const val PREFS = "engine_state"
        private const val KEY_RUNNING = "running"

        /** 当前进程内引擎是否在运行(进程被杀后为 false)。 */
        @Volatile
        var isRunning: Boolean = false
            private set

        /** 持久化运行标志:跨进程/重启保留,供开机自启与心跳恢复判断。 */
        fun setRunning(context: Context, running: Boolean) {
            isRunning = running
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_RUNNING, running)
                .apply()
        }

        fun wasRunning(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_RUNNING, false)

        fun start(context: Context) {
            EngineKeepAliveReceiver.schedule(context)
            val intent = Intent(context, TradingService::class.java)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, TradingService::class.java).setAction(ACTION_STOP)
            context.startService(intent)
        }
    }
}
