package com.quant.app.domain.strategy

import com.quant.app.data.db.entity.KlineEntity

/**
 * 策略信号(统一输出,供 SignalEngine 过滤 + TradeExecutor 执行)。
 */
data class StrategySignal(
    val direction: String,        // long / short / neutral
    val confidence: Double,       // 0.0 ~ 1.0
    val entry: Double? = null,
    val stopLoss: Double? = null,
    val takeProfit: Double? = null,
    val reason: String = "",
)

/**
 * 策略接口。所有策略输入 K线序列,输出开/平仓信号。
 * 由策略选择器按当前配置选择生效策略。
 */
interface Strategy {
    /** 唯一标识(持久化用)。 */
    val id: String
    /** 显示名称。 */
    val label: String
    /** 是否需要 AI Key(纯规则策略不需要)。 */
    val needsAi: Boolean

    /**
     * 评估 K线,返回信号。
     * @param klines 按时间升序的 K线(至少 20 根)。
     */
    suspend fun evaluate(symbol: String, interval: String, klines: List<KlineEntity>): StrategySignal
}
