package com.quant.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.quant.app.data.db.entity.KlineEntity
import com.quant.app.ui.MainViewModel
import com.quant.app.ui.MainViewModel.PriceAlert

/** 智能交易驾驶舱首页。 */
@Composable
fun CockpitScreen(
    viewModel: MainViewModel,
    onOpenBacktest: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
) {
    val config by viewModel.configState.collectAsState()
    val account by viewModel.account.collectAsState()
    val positions by viewModel.positions.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val countdown by viewModel.fundingCountdown.collectAsState()
    val dailyPnl by viewModel.dailyPnl.collectAsState()
    val alerts by viewModel.priceAlerts.collectAsState()
    val engineRunning by viewModel.engineRunning.collectAsState()
    val engineStatus by viewModel.engineStatus.collectAsState()
    val realtimeTickers by viewModel.realtimeTickers.collectAsState()
    val message by viewModel.message.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showAiDialog by remember { mutableStateOf(false) }
    var aiQuery by remember { mutableStateOf("") }

    var alertSymbol by remember { mutableStateOf("BTCUSDT") }
    var alertPrice by remember { mutableStateOf("") }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAiDialog = true },
                containerColor = Color(0xFF4F8CFF),
            ) {
                Text("🤖", style = MaterialTheme.typography.titleMedium)
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // ---- 引擎控制 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("量化引擎 · ${config.mode.label}", style = MaterialTheme.typography.titleSmall)
                        // 运行状态灯:运行中=绿 / 已停止=灰 / 异常=红
                        Text(
                            if (engineRunning) {
                                "● 运行中"
                            } else {
                                "● 已停止"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (engineRunning) Color(0xFF22C55E) else Color.Gray,
                        )
                    }
                    // 引擎状态详情(启动失败原因/监控内容),异常时红色提示
                    engineStatus?.let { status ->
                        if (!engineRunning) {
                            Text(
                                status,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFEF4444),
                            )
                        } else {
                            Text(
                                status,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                            )
                        }
                    }
                    config.missingConfigHint?.let { missing ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            Text(
                                "⚠️ $missing",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFEF4444),
                            )
                            Button(onClick = onOpenSettings) { Text("去配置") }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { viewModel.startEngine() }) { Text("启动") }
                        OutlinedButton(onClick = { viewModel.stopEngine() }) { Text("停止") }
                        OutlinedButton(
                            onClick = { viewModel.refreshAccount() },
                            enabled = !loading,
                        ) {
                            Text(if (loading) "刷新中..." else "刷新")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onOpenBacktest,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("📊 策略回测")
                        }
                    }
                }
            }

            // ---- 实时行情 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("📡 实时行情", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "实时订阅自动刷新",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                        )
                    }
                    if (realtimeTickers.isEmpty()) {
                        Text(
                            "正在同步行情...",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                        )
                    } else {
                        config.symbols.forEach { symbol ->
                            val list = realtimeTickers[symbol].orEmpty()
                            if (list.isNotEmpty()) {
                                RealtimeTickerRow(symbol, list)
                            }
                        }
                    }
                }
            }

            // ---- 账户权益 + 费率倒计时 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("账户权益", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(
                                account?.totalWalletBalance ?: "--",
                                style = MaterialTheme.typography.headlineMedium,
                            )
                            Text(
                                "未实现 ${account?.totalUnrealizedProfit ?: "--"}",
                                color = if ((account?.totalUnrealizedProfit?.toDoubleOrNull() ?: 0.0) >= 0) {
                                    Color(0xFF22C55E)
                                } else {
                                    Color(0xFFEF4444)
                                },
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("⏳ 距费率结算", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(countdown, style = MaterialTheme.typography.titleLarge)
                            Text("当前费率 +0.01%", style = MaterialTheme.typography.bodySmall, color = Color(0xFF22C55E))
                        }
                    }
                }
            }

            // ---- 策略切换 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("当前策略", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StrategyChip("AI", "ai", config.strategyId) { viewModel.saveConfig(config.copy(strategyId = "ai")) }
                        StrategyChip("趋势", "trend", config.strategyId) { viewModel.saveConfig(config.copy(strategyId = "trend")) }
                        StrategyChip("均值回归", "mean_reversion", config.strategyId) { viewModel.saveConfig(config.copy(strategyId = "mean_reversion")) }
                        StrategyChip("网格", "grid", config.strategyId) { viewModel.saveConfig(config.copy(strategyId = "grid")) }
                    }
                }
            }

            // ---- AI 模拟跟单 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🧠 AI 实时信号", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "模拟跟单:在模拟盘记录虚拟盈亏,零风险验证策略",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                    )
                    Button(
                        onClick = { viewModel.simulateFollow() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("📈 模拟跟单(零风险)")
                    }
                }
            }

            // ---- 当前持仓(含手动平仓) ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("📦 当前持仓(${positions.size})", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "强平价含维持保证金估算",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                        )
                    }
                    if (positions.isEmpty()) {
                        Text(
                            "暂无持仓(启动引擎或模拟跟单后显示)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                        )
                    } else {
                        positions.forEach { pos ->
                            CockpitPositionRow(
                                symbol = pos.symbol,
                                side = pos.positionSide,
                                amount = pos.positionAmt,
                                entry = pos.entryPrice,
                                mark = pos.markPrice,
                                pnl = pos.unRealizedProfit,
                                leverage = pos.leverage,
                                liquidation = pos.liquidationPrice,
                                onClose = { ratio -> viewModel.closePosition(pos.symbol, ratio) },
                            )
                        }
                    }
                }
            }

            // ---- 盈亏热力图 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("📅 每日盈亏", style = MaterialTheme.typography.titleSmall)
                    if (dailyPnl.isEmpty()) {
                        Text("暂无已平仓记录", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    } else {
                        dailyPnl.entries.sortedByDescending { it.key }.take(14).forEach { (day, pnl) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(day, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    if (pnl >= 0) "+%.2f".format(pnl) else "%.2f".format(pnl),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (pnl >= 0) Color(0xFF22C55E) else Color(0xFFEF4444),
                                )
                            }
                        }
                    }
                }
            }

            // ---- 价格预警 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("⚡ 价格预警", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = alertSymbol,
                            onValueChange = { alertSymbol = it },
                            label = { Text("币种") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = alertPrice,
                            onValueChange = { alertPrice = it },
                            label = { Text("目标价") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            alertPrice.toDoubleOrNull()?.let {
                                viewModel.addPriceAlert(alertSymbol.trim().uppercase(), it, above = true)
                            }
                        }) { Text("突破↑") }
                        Button(onClick = {
                            alertPrice.toDoubleOrNull()?.let {
                                viewModel.addPriceAlert(alertSymbol.trim().uppercase(), it, above = false)
                            }
                        }) { Text("跌破↓") }
                    }
                    alerts.forEach { a ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                "${a.symbol} ${if (a.above) "突破" else "跌破"} ${a.target}",
                                style = MaterialTheme.typography.bodySmall,
                            )
                            OutlinedButton(onClick = { viewModel.removePriceAlert(a) }) { Text("删除") }
                        }
                    }
                }
            }
        }
    }

    // AI 悬浮球对话框
    if (showAiDialog) {
        AlertDialog(
            onDismissRequest = { showAiDialog = false },
            title = { Text("🤖 AI 助手") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("输入行情/分析/新闻相关问题", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    OutlinedTextField(
                        value = aiQuery,
                        onValueChange = { aiQuery = it },
                        label = { Text("例如: BTC 当前趋势如何?") },
                        singleLine = false,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.setMessage("已收到: $aiQuery (AI 回答功能开发中)")
                    showAiDialog = false
                    aiQuery = ""
                }) { Text("发送") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAiDialog = false }) { Text("取消") }
            },
        )
    }
}

@Composable
private fun StrategyChip(
    label: String,
    id: String,
    current: String,
    onSelect: () -> Unit,
) {
    val selected = current == id
    if (selected) {
        Button(onClick = onSelect) { Text(label) }
    } else {
        OutlinedButton(onClick = onSelect) { Text(label) }
    }
}

/** 实时行情行:币种 + 最新价 + 近24根涨跌幅 + 迷你走势线。 */
@Composable
private fun RealtimeTickerRow(symbol: String, klines: List<KlineEntity>) {
    val last = klines.last()
    val prev = klines.getOrNull(klines.size - 25) ?: klines.first()
    val change = if (prev.close > 0) (last.close - prev.close) / prev.close * 100 else 0.0
    val up = change >= 0
    val color = if (up) Color(0xFF22C55E) else Color(0xFFEF4444)
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(symbol.removeSuffix("USDT"), style = MaterialTheme.typography.titleSmall)
                Text(
                    "最新 ${tickerPrice(last.close)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "${if (up) "+" else ""}${"%.2f".format(change)}%",
                    style = MaterialTheme.typography.titleMedium,
                    color = color,
                )
                Text("近24根", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Sparkline(
                values = klines.takeLast(30).map { it.close },
                color = color,
                modifier = Modifier.size(width = 72.dp, height = 36.dp),
            )
        }
    }
}

/** 迷你走势线:最近 N 根收盘价折线 + 渐变填充。 */
@Composable
private fun Sparkline(values: List<Double>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (values.size < 2) return@Canvas
        val min = values.min()
        val max = values.max()
        val range = (max - min).coerceAtLeast(1e-9)
        val stepX = size.width / (values.size - 1)
        fun yOf(v: Double): Float = size.height - ((v - min) / range * size.height).toFloat()

        val fill = Path().apply {
            moveTo(0f, size.height)
            values.forEachIndexed { i, v ->
                lineTo(i * stepX, yOf(v))
            }
            lineTo(size.width, size.height)
            close()
        }
        drawPath(fill, color = color.copy(alpha = 0.15f))

        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i * stepX
            val y = yOf(v)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = color, style = Stroke(width = 2f))
    }
}

/** 按价格区间自适应小数位(大币整百显示,小币四位)。 */
private fun tickerPrice(v: Double): String = when {
    v >= 1000 -> "%.0f".format(v)
    v >= 1 -> "%.2f".format(v)
    else -> "%.4f".format(v)
}

/** 驾驶舱持仓行:方向/入场/标记/未实现盈亏/杠杆/强平价 + 平仓比例按钮。 */
@Composable
private fun CockpitPositionRow(
    symbol: String,
    side: String,
    amount: String,
    entry: String,
    mark: String,
    pnl: String,
    leverage: String,
    liquidation: String,
    onClose: (Double) -> Unit,
) {
    val isShort = amount.startsWith("-")
    val pnlValue = pnl.toDoubleOrNull() ?: 0.0
    Card(Modifier.fillMaxWidth(), colors = androidx.compose.material3.CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
    )) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    "$symbol · ${if (isShort) "空头" else "多头"}",
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isShort) Color(0xFFEF4444) else Color(0xFF22C55E),
                )
                Text(
                    if (pnlValue >= 0) "+%.2f".format(pnlValue) else "%.2f".format(pnlValue),
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (pnlValue >= 0) Color(0xFF22C55E) else Color(0xFFEF4444),
                )
            }
            Text(
                "入场 $entry · 标记 $mark · 杠杆 ${leverage}x",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                "强平价 $liquidation",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onClose(1.0) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("全平")
                }
                OutlinedButton(
                    onClick = { onClose(0.5) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("平50%")
                }
                OutlinedButton(
                    onClick = { onClose(0.25) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("平25%")
                }
            }
        }
    }
}