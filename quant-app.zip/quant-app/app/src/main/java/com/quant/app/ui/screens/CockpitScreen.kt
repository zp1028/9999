package com.quant.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.quant.app.ui.MainViewModel
import com.quant.app.ui.MainViewModel.PriceAlert

/** 智能交易驾驶舱首页。 */
@Composable
fun CockpitScreen(
    viewModel: MainViewModel,
    onOpenBacktest: () -> Unit = {},
) {
    val config by viewModel.configState.collectAsState()
    val account by viewModel.account.collectAsState()
    val positions by viewModel.positions.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val countdown by viewModel.fundingCountdown.collectAsState()
    val dailyPnl by viewModel.dailyPnl.collectAsState()
    val alerts by viewModel.priceAlerts.collectAsState()
    val message by viewModel.message.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showAiDialog by remember { mutableStateOf(false) }
    var aiQuery by remember { mutableStateOf("") }

    var alertSymbol by remember { mutableStateOf("BTCUSDT") }
    var alertPrice by remember { mutableStateOf("") }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAiDialog = true },
                containerColor = Color(0xFF4F8CFF),
            ) {
                Text("🤖", style = MaterialTheme.typography.titleMedium)
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // ---- 引擎控制 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("量化引擎 · ${config.mode.label}", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { viewModel.startEngine() }) { Text("启动") }
                        OutlinedButton(onClick = { viewModel.stopEngine() }) { Text("停止") }
                        OutlinedButton(
                            onClick = { viewModel.refreshAccount() },
                            enabled = !loading,
                        ) {
                            Text(if (loading) "刷新中..." else "刷新")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onOpenBacktest,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("📊 策略回测")
                        }
                    }
                }
            }

            // ---- 账户权益 + 费率倒计时 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("账户权益", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(
                                account?.totalWalletBalance ?: "--",
                                style = MaterialTheme.typography.headlineMedium,
                            )
                            Text(
                                "未实现 ${account?.totalUnrealizedProfit ?: "--"}",
                                color = if ((account?.totalUnrealizedProfit?.toDoubleOrNull() ?: 0.0) >= 0) {
                                    Color(0xFF22C55E)
                                } else {
                                    Color(0xFFEF4444)
                                },
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        Column(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("⏳ 距费率结算", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text(countdown, style = MaterialTheme.typography.titleLarge)
                            Text("当前费率 +0.01%", style = MaterialTheme.typography.bodySmall, color = Color(0xFF22C55E))
                        }
                    }
                }
            }

            // ---- 策略切换 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("当前策略", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StrategyChip("AI", "ai", config.strategyId) { viewModel.saveConfig(config.copy(strategyId = "ai")) }
                        StrategyChip("趋势", "trend", config.strategyId) { viewModel.saveConfig(config.copy(strategyId = "trend")) }
                        StrategyChip("均值回归", "mean_reversion", config.strategyId) { viewModel.saveConfig(config.copy(strategyId = "mean_reversion")) }
                        StrategyChip("网格", "grid", config.strategyId) { viewModel.saveConfig(config.copy(strategyId = "grid")) }
                    }
                }
            }

            // ---- AI 模拟跟单 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🧠 AI 实时信号", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "模拟跟单:在模拟盘记录虚拟盈亏,零风险验证策略",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                    )
                    Button(
                        onClick = { viewModel.simulateFollow() },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("📈 模拟跟单(零风险)")
                    }
                }
            }

            // ---- 当前持仓(含手动平仓) ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("📦 当前持仓(${positions.size})", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "强平价含维持保证金估算",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                        )
                    }
                    if (positions.isEmpty()) {
                        Text(
                            "暂无持仓(启动引擎或模拟跟单后显示)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                        )
                    } else {
                        positions.forEach { pos ->
                            CockpitPositionRow(
                                symbol = pos.symbol,
                                side = pos.positionSide,
                                amount = pos.positionAmt,
                                entry = pos.entryPrice,
                                mark = pos.markPrice,
                                pnl = pos.unRealizedProfit,
                                leverage = pos.leverage,
                                liquidation = pos.liquidationPrice,
                                onClose = { ratio -> viewModel.closePosition(pos.symbol, ratio) },
                            )
                        }
                    }
                }
            }

            // ---- 盈亏热力图 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("📅 每日盈亏", style = MaterialTheme.typography.titleSmall)
                    if (dailyPnl.isEmpty()) {
                        Text("暂无已平仓记录", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    } else {
                        dailyPnl.entries.sortedByDescending { it.key }.take(14).forEach { (day, pnl) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(day, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    if (pnl >= 0) "+%.2f".format(pnl) else "%.2f".format(pnl),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (pnl >= 0) Color(0xFF22C55E) else Color(0xFFEF4444),
                                )
                            }
                        }
                    }
                }
            }

            // ---- 价格预警 ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("⚡ 价格预警", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = alertSymbol,
                            onValueChange = { alertSymbol = it },
                            label = { Text("币种") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = alertPrice,
                            onValueChange = { alertPrice = it },
                            label = { Text("目标价") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            alertPrice.toDoubleOrNull()?.let {
                                viewModel.addPriceAlert(alertSymbol.trim().uppercase(), it, above = true)
                            }
                        }) { Text("突破↑") }
                        Button(onClick = {
                            alertPrice.toDoubleOrNull()?.let {
                                viewModel.addPriceAlert(alertSymbol.trim().uppercase(), it, above = false)
                            }
                        }) { Text("跌破↓") }
                    }
                    alerts.forEach { a ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                "${a.symbol} ${if (a.above) "突破" else "跌破"} ${a.target}",
                                style = MaterialTheme.typography.bodySmall,
                            )
                            OutlinedButton(onClick = { viewModel.removePriceAlert(a) }) { Text("删除") }
                        }
                    }
                }
            }
        }
    }

    // AI 悬浮球对话框
    if (showAiDialog) {
        AlertDialog(
            onDismissRequest = { showAiDialog = false },
            title = { Text("🤖 AI 助手") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("输入行情/分析/新闻相关问题", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    OutlinedTextField(
                        value = aiQuery,
                        onValueChange = { aiQuery = it },
                        label = { Text("例如: BTC 当前趋势如何?") },
                        singleLine = false,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.setMessage("已收到: $aiQuery (AI 回答功能开发中)")
                    showAiDialog = false
                    aiQuery = ""
                }) { Text("发送") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAiDialog = false }) { Text("取消") }
            },
        )
    }
}

@Composable
private fun StrategyChip(
    label: String,
    id: String,
    current: String,
    onSelect: () -> Unit,
) {
    val selected = current == id
    if (selected) {
        Button(onClick = onSelect) { Text(label) }
    } else {
        OutlinedButton(onClick = onSelect) { Text(label) }
    }
}

/** 驾驶舱持仓行:方向/入场/标记/未实现盈亏/杠杆/强平价 + 平仓比例按钮。 */
@Composable
private fun CockpitPositionRow(
    symbol: String,
    side: String,
    amount: String,
    entry: String,
    mark: String,
    pnl: String,
    leverage: String,
    liquidation: String,
    onClose: (Double) -> Unit,
) {
    val isShort = amount.startsWith("-")
    val pnlValue = pnl.toDoubleOrNull() ?: 0.0
    Card(Modifier.fillMaxWidth(), colors = androidx.compose.material3.CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
    )) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    "$symbol · ${if (isShort) "空头" else "多头"}",
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isShort) Color(0xFFEF4444) else Color(0xFF22C55E),
                )
                Text(
                    if (pnlValue >= 0) "+%.2f".format(pnlValue) else "%.2f".format(pnlValue),
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (pnlValue >= 0) Color(0xFF22C55E) else Color(0xFFEF4444),
                )
            }
            Text(
                "入场 $entry · 标记 $mark · 杠杆 ${leverage}x",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                "强平价 $liquidation",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onClose(1.0) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("全平")
                }
                OutlinedButton(
                    onClick = { onClose(0.5) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("平50%")
                }
                OutlinedButton(
                    onClick = { onClose(0.25) },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("平25%")
                }
            }
        }
    }
}