package com.quant.app.domain.model

/**
 * 运行时配置模型。所有字段均有默认值,未配置时程序进入"未初始化"引导态。
 * 安全策略:币安 Key / DeepSeek Key 仅存于加密存储,不落普通数据库。
 * 双环境隔离:测试网与实盘的 API Key 分开存储,避免错单。
 */
data class AppConfig(
    /** 测试网(模拟)API Key */
    val testnetApiKey: String = "",
    val testnetSecretKey: String = "",
    /** 实盘 API Key */
    val liveApiKey: String = "",
    val liveSecretKey: String = "",
    val deepseekApiKey: String = "",
    /** 交易环境:SIMULATED(本地模拟盘)/ TESTNET(测试网)/ LIVE(实盘) */
    val mode: TradingMode = TradingMode.SIMULATED,
    /** 模拟盘初始资金(USDT),仅 SIMULATED 模式生效 */
    val simulatedBalance: Double = 1000.0,
    /** 自动下单开关:true=AI 信号直接自动下单;false=仅出建议,人工确认(推荐) */
    val autoTrade: Boolean = false,
    /** 自动下单置信度阈值,默认 0.7 */
    val confidenceThreshold: Double = 0.7,
    /** 杠杆倍数(读取自币安账户,允许随时调整) */
    val leverage: Int = 3,
    /** 单笔开仓保证金上限(USDT),仅 FIXED_USD 模式生效 */
    val maxPositionUsd: Double = 100.0,
    /** 仓位模式:FIXED_USD=固定金额;PERCENT=按账户权益百分比 */
    val positionMode: PositionMode = PositionMode.FIXED_USD,
    /** 单笔开仓占账户权益百分比(%),仅 PERCENT 模式生效,默认 20% */
    val positionPercent: Double = 20.0,
    /** 当日累计亏损熔断比例(%) */
    val maxDailyLossPct: Double = 5.0,
    /** 同币种两次交易最小间隔(分钟) */
    val cooldownMinutes: Int = 30,
    /** K线周期,默认 15m */
    val interval: String = "15m",
    /** 监控的合约列表 */
    val symbols: List<String> = listOf("BTCUSDT", "ETHUSDT", "SOLUSDT"),
    /** 当前生效策略 id(趋势/均值回归/网格/AI) */
    val strategyId: String = "ai",
    // ---------- 策略参数(可配置) ----------
    /** 趋势策略:快线 MA 周期 */
    val trendMaFast: Int = 5,
    /** 趋势策略:慢线 MA 周期 */
    val trendMaSlow: Int = 20,
    /** 趋势策略:信号置信度 */
    val trendConfidence: Double = 0.75,
    /** 均值回归:RSI 周期 */
    val meanRsiPeriod: Int = 14,
    /** 均值回归:超卖阈值 */
    val meanOversold: Double = 30.0,
    /** 均值回归:超买阈值 */
    val meanOverbought: Double = 70.0,
    /** 网格:网格数量 */
    val gridCount: Int = 5,
    /** 规则策略止损百分比(默认 2%) */
    val strategySlPct: Double = 2.0,
    /** 规则策略止盈百分比(默认 4%) */
    val strategyTpPct: Double = 4.0,
    // ---------- 风控 ----------
    /** 最大同时持仓数(超过则新信号跳过,反转除外) */
    val maxOpenPositions: Int = 3,
    /** 实盘自动交易二次确认(防误配真钱裸跑),默认关闭 */
    val liveAutoTradeGuard: Boolean = false,
) {
    /** 当前环境生效的币安 Key。 */
    val activeApiKey: String
        get() = if (mode == TradingMode.LIVE) liveApiKey else testnetApiKey

    val activeSecretKey: String
        get() = if (mode == TradingMode.LIVE) liveSecretKey else testnetSecretKey

    /**
     * 引擎是否可启动(按策略区分):
     * - 非 AI 策略(趋势/均值回归/网格):模拟盘无需任何 Key;测试网/实盘只需币安 Key;
     * - AI 策略:额外需要 AI Key(三种模式均依赖 AI 分析)。
     */
    val isConfigured: Boolean
        get() = missingConfigHint == null

    /** 具体缺失项提示(供主页/引擎启动直接展示);null 表示配置齐全。 */
    val missingConfigHint: String?
        get() {
            val aiNeeded = strategyId == "ai" && deepseekApiKey.isBlank()
            val binanceNeeded = mode != TradingMode.SIMULATED &&
                (activeApiKey.isBlank() || activeSecretKey.isBlank())
            return when {
                aiNeeded && binanceNeeded -> "缺少 ${mode.label} API Key 与 AI Key"
                aiNeeded -> "缺少 AI Key(当前 AI 策略需要)"
                binanceNeeded -> "缺少 ${mode.label} API Key"
                else -> null
            }
        }
}

enum class TradingMode(val label: String) {
    SIMULATED("模拟盘"),
    TESTNET("测试网"),
    LIVE("实盘"),
}

/** 开仓仓位模式。 */
enum class PositionMode(val label: String) {
    FIXED_USD("固定金额"),
    PERCENT("账户百分比"),
}
