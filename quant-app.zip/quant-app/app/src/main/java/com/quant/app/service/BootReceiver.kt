package com.quant.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * 开机自启:设备重启后,若上次引擎仍在运行则自动恢复。
 * 依赖 TradingService 持久化的运行标志(SharedPreferences)。
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (TradingService.wasRunning(context) && !TradingService.isRunning) {
            runCatching { TradingService.start(context) }
                .onFailure { e -> android.util.Log.w(TAG, "开机自启引擎失败: ${e.message}") }
        }
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
