package com.quant.app.domain.strategy

import com.quant.app.data.db.entity.KlineEntity
import com.quant.app.domain.model.AppConfig

/**
 * 网格策略:震荡收割。
 * 在价格区间 [lower, upper] 内等分 N 格,价格下跌一格买入、上涨一格卖出。
 * 规则:
 * - 价格低于当前网格下沿 → 做多(买入);
 * - 价格高于当前网格上沿 → 做空(卖出);
 * - 否则观望。
 * 区间取最近 50 根的高低点,格数可通过设置页配置。
 */
class GridStrategy(
    private val configProvider: () -> AppConfig,
) : Strategy {
    override val id = "grid"
    override val label = "网格"
    override val needsAi = false

    override suspend fun evaluate(symbol: String, interval: String, klines: List<KlineEntity>): StrategySignal {
        if (klines.size < 20) return StrategySignal("neutral", 0.0, reason = "K线不足")
        val cfg = configProvider()
        val gridCount = cfg.gridCount.coerceAtLeast(2)
        val rangePeriod = cfg.gridRangePeriod.coerceIn(10, 500)
        val last = klines.last()
        val high = Indicators.highest(klines, rangePeriod) ?: return neutral()
        val low = Indicators.lowest(klines, rangePeriod) ?: return neutral()
        if (high <= low) return neutral("区间无效")

        val step = (high - low) / gridCount
        // 当前价格所在网格
        val gridIndex = ((last.close - low) / step).toInt().coerceIn(0, gridCount - 1)
        val gridLow = low + gridIndex * step
        val gridHigh = gridLow + step
        val slPct = cfg.strategySlPct / 100.0
        val tpPct = cfg.strategyTpPct / 100.0

        return when {
            last.close <= gridLow -> {
                val entry = last.close
                StrategySignal(
                    direction = "long",
                    confidence = 0.6,
                    entry = entry,
                    stopLoss = entry * (1 - slPct),
                    takeProfit = entry * (1 + tpPct),
                    reason = "网格买入(区间 ${"%.0f".format(low)}~${"%.0f".format(high)})",
                )
            }
            last.close >= gridHigh -> {
                val entry = last.close
                StrategySignal(
                    direction = "short",
                    confidence = 0.6,
                    entry = entry,
                    stopLoss = entry * (1 + slPct),
                    takeProfit = entry * (1 - tpPct),
                    reason = "网格卖出(区间 ${"%.0f".format(low)}~${"%.0f".format(high)})",
                )
            }
            else -> neutral("网格内观望")
        }
    }

    private fun neutral(reason: String = "观望") = StrategySignal("neutral", 0.0, reason = reason)
}
