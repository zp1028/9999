package com.quant.app.domain.backtest

import com.quant.app.data.db.entity.KlineEntity
import com.quant.app.domain.strategy.Strategy

/** 回测单笔模拟交易。 */
data class BacktestTrade(
    val symbol: String,
    val direction: String,        // long / short
    val entryTime: Long,
    val entryPrice: Double,
    val exitTime: Long,
    val exitPrice: Double,
    val pnlPct: Double,           // 价格涨跌幅(不含杠杆)
    val exitReason: String,       // take_profit / stop_loss / reverse / close
)

/** 回测结果。 */
data class BacktestResult(
    val symbol: String,
    val interval: String,
    val strategyId: String,
    val strategyLabel: String,
    val initialBalance: Double,
    val finalBalance: Double,
    val totalReturnPct: Double,
    val tradeCount: Int,
    val winCount: Int,
    val winRate: Double,
    val maxDrawdownPct: Double,
    val profitFactor: Double,     // 总盈利 / 总亏损(绝对值)
    val trades: List<BacktestTrade>,
    /** 收益曲线(时间戳 → 累计收益率%)。 */
    val equityCurve: List<Pair<Long, Double>>,
)

/**
 * 回测引擎:用历史 K 线回放策略,验证胜率与收益。
 * 规则:
 * - 从第 20 根起,每根收盘以"截至当前"的窗口调用策略;
 * - 持仓中:每根先检查止损/止盈是否被 K 线区间扫到(用 high/low 更保守);
 *   再检查策略是否产生反向信号(触发换仓);否则继续持有;
 * - 无持仓:策略出开仓信号则按固定名义金额开仓;
 * - 区间结束仍持仓 → 按最后收盘价强平;
 * - 每笔收益按价格涨跌幅 × 杠杆计入余额。
 */
class BacktestEngine {

    suspend fun run(
        strategy: Strategy,
        symbol: String,
        interval: String,
        klines: List<KlineEntity>,   // 时间升序
        initialBalance: Double = 1000.0,
        leverage: Int = 1,
    ): BacktestResult {
        require(klines.size >= 20) { "K线不足 20 根,无法回测" }

        var balance = initialBalance
        var position: OpenPosition? = null
        val trades = mutableListOf<BacktestTrade>()
        val equity = mutableListOf<Pair<Long, Double>>(klines[0].openTime to 0.0)

        for (i in 19 until klines.size) {
            val k = klines[i]
            val window = klines.subList(0, i + 1)

            // 1. 持仓中:先检查止盈/止损触发
            position?.let { pos ->
                val exit = pos.checkExit(k)
                if (exit != null) {
                    balance = applyPnl(balance, pos, exit.price, leverage)
                    trades += pos.toTrade(exit.price, exit.reason, k.closeTime)
                    equity += k.closeTime to (balance / initialBalance - 1.0) * 100.0
                    position = null
                }
            }

            // 2. 评估策略(持仓中也可产生反向信号 → 换仓)
            val signal = try {
                strategy.evaluate(symbol, interval, window)
            } catch (e: Exception) {
                null
            }
            if (signal != null && signal.direction != "neutral") {
                val pos = position
                if (pos != null) {
                    if (pos.direction != signal.direction) {
                        // 反向信号:按当前收盘价平旧仓,开新仓
                        balance = applyPnl(balance, pos, k.close, leverage)
                        trades += pos.toTrade(k.close, "reverse", k.closeTime)
                        equity += k.closeTime to (balance / initialBalance - 1.0) * 100.0
                        position = OpenPosition(
                            direction = signal.direction,
                            entryTime = k.closeTime,
                            entryPrice = k.close,
                            stopLoss = signal.stopLoss,
                            takeProfit = signal.takeProfit,
                            symbol = symbol,
                        )
                    }
                } else {
                    // 无持仓:开仓
                    position = OpenPosition(
                        direction = signal.direction,
                        entryTime = k.closeTime,
                        entryPrice = k.close,
                        stopLoss = signal.stopLoss,
                        takeProfit = signal.takeProfit,
                        symbol = symbol,
                    )
                }
            }
        }

        // 3. 结束仍持仓 → 强平
        position?.let { pos ->
            val last = klines.last()
            balance = applyPnl(balance, pos, last.close, leverage)
            trades += pos.toTrade(last.close, "close", last.closeTime)
            equity += last.closeTime to (balance / initialBalance - 1.0) * 100.0
        }

        val totalReturn = (balance / initialBalance - 1.0) * 100.0
        val winCount = trades.count { it.pnlPct > 0 }
        val grossProfit = trades.filter { it.pnlPct > 0 }.sumOf { it.pnlPct }
        val grossLoss = trades.filter { it.pnlPct <= 0 }.sumOf { kotlin.math.abs(it.pnlPct) }
        val profitFactor = if (grossLoss > 0.0) grossProfit / grossLoss else grossProfit

        return BacktestResult(
            symbol = symbol,
            interval = interval,
            strategyId = strategy.id,
            strategyLabel = strategy.label,
            initialBalance = initialBalance,
            finalBalance = balance,
            totalReturnPct = totalReturn,
            tradeCount = trades.size,
            winCount = winCount,
            winRate = if (trades.isEmpty()) 0.0 else winCount.toDouble() / trades.size * 100.0,
            maxDrawdownPct = maxDrawdown(equity),
            profitFactor = profitFactor,
            trades = trades,
            equityCurve = equity,
        )
    }

    private fun applyPnl(balance: Double, pos: OpenPosition, exitPrice: Double, leverage: Int): Double {
        val dir = if (pos.direction == "long") 1.0 else -1.0
        val pnlPct = (exitPrice / pos.entryPrice - 1.0) * dir * leverage
        return balance * (1.0 + pnlPct)
    }

    /** 曲线最大回撤(百分比)。 */
    private fun maxDrawdown(curve: List<Pair<Long, Double>>): Double {
        var peak = Double.MIN_VALUE
        var maxDd = 0.0
        for ((_, v) in curve) {
            if (v > peak) peak = v
            if (peak > 0) maxDd = maxOf(maxDd, (peak - v) / peak * 100.0)
        }
        return maxDd
    }

    /** 持仓状态。 */
    private class OpenPosition(
        val symbol: String,
        val direction: String,
        val entryTime: Long,
        val entryPrice: Double,
        val stopLoss: Double?,
        val takeProfit: Double?,
    ) {
        /** 检查本根 K 线是否触发止盈/止损;未触发返回 null。 */
        fun checkExit(k: KlineEntity): Exit? {
            val sl = stopLoss ?: return null
            val tp = takeProfit ?: return null
            return if (direction == "long") {
                when {
                    k.low <= sl -> Exit(sl, "stop_loss")
                    k.high >= tp -> Exit(tp, "take_profit")
                    else -> null
                }
            } else {
                when {
                    k.high >= sl -> Exit(sl, "stop_loss")
                    k.low <= tp -> Exit(tp, "take_profit")
                    else -> null
                }
            }
        }

        fun toTrade(exitPrice: Double, reason: String, exitTime: Long): BacktestTrade {
            val dir = if (direction == "long") 1.0 else -1.0
            val pnlPct = (exitPrice / entryPrice - 1.0) * dir * 100.0
            return BacktestTrade(
                symbol = symbol,
                direction = direction,
                entryTime = entryTime,
                entryPrice = entryPrice,
                exitTime = exitTime,
                exitPrice = exitPrice,
                pnlPct = pnlPct,
                exitReason = reason,
            )
        }
    }

    private data class Exit(val price: Double, val reason: String)
}
