package com.quant.app.domain.strategy

import com.quant.app.data.db.entity.KlineEntity
import com.quant.app.data.network.dto.AiSignalDto

/**
 * AI 策略:复用现有 LLM 分析(K线 + 新闻情绪 + 预测上下文)。
 * 通过 [aiAnalyze] 回调获取 AI 信号,再转成统一 [StrategySignal]。
 */
class AiStrategy(
    private val aiAnalyze: suspend (symbol: String, interval: String, klines: List<KlineEntity>) -> AiSignalDto,
) : Strategy {
    override val id = "ai"
    override val label = "AI智能"
    override val needsAi = true

    override suspend fun evaluate(symbol: String, interval: String, klines: List<KlineEntity>): StrategySignal {
        val signal = aiAnalyze(symbol, interval, klines)
        return StrategySignal(
            direction = signal.direction,
            confidence = signal.confidence,
            entry = signal.entry,
            stopLoss = signal.stopLoss,
            takeProfit = signal.takeProfit,
            reason = signal.reasons.firstOrNull() ?: "",
        )
    }
}
