package com.quant.app.data.network

import com.quant.app.data.network.dto.AccountDto
import com.quant.app.data.network.dto.AssetDto
import com.quant.app.data.network.dto.PositionDto
import java.util.concurrent.ConcurrentHashMap

/**
 * 本地模拟账户账本(仅 SIMULATED 模式使用,无需币安 Key)。
 * 维护余额与持仓,提供与币安一致的 AccountDto/PositionDto 供 UI 与引擎读取。
 * 线程安全:所有读写经 synchronized 保护。
 */
class SimulatedAccount {

    /** 模拟持仓。 */
    data class SimPosition(
        val symbol: String,
        val side: String,          // LONG / SHORT
        val qty: Double,
        val entryPrice: Double,
        val leverage: Int,
        val stopLossPrice: Double?,
        val takeProfitPrice: Double?,
    )

    @Volatile
    var balance: Double = 0.0
        private set

    private val positions = ConcurrentHashMap<String, SimPosition>()

    /** 重置账户:清空持仓,余额设为初始资金。 */
    @Synchronized
    fun reset(initialBalance: Double) {
        balance = initialBalance
        positions.clear()
    }

    /** 开仓:扣保证金,记录持仓。返回是否成功(余额不足则失败)。 */
    @Synchronized
    fun openPosition(
        symbol: String,
        side: String,
        qty: Double,
        entryPrice: Double,
        leverage: Int,
        stopLossPrice: Double?,
        takeProfitPrice: Double?,
    ): Boolean {
        if (positions.containsKey(symbol)) return false   // 已有持仓,不追加
        val margin = qty * entryPrice / leverage
        if (margin > balance) return false                // 保证金不足
        balance -= margin
        positions[symbol] = SimPosition(
            symbol = symbol,
            side = side,
            qty = qty,
            entryPrice = entryPrice,
            leverage = leverage,
            stopLossPrice = stopLossPrice,
            takeProfitPrice = takeProfitPrice,
        )
        return true
    }

    /** 按当前价平仓,计算已实现盈亏并回笼保证金。返回平仓盈亏;无持仓返回 null。 */
    @Synchronized
    fun closePosition(symbol: String, markPrice: Double): Double? {
        val pos = positions.remove(symbol) ?: return null
        val pnl = realizedPnl(pos, markPrice)
        balance += pos.qty * pos.entryPrice / pos.leverage + pnl   // 回笼保证金 + 盈亏
        return pnl
    }

    /** 部分平仓:按数量缩减持仓,释放对应比例保证金。closeQty 需在 (0, 当前数量) 之间。 */
    @Synchronized
    fun reducePosition(symbol: String, closeQty: Double): Boolean {
        val pos = positions[symbol] ?: return false
        if (closeQty <= 0.0 || closeQty >= pos.qty) return false
        val margin = pos.qty * pos.entryPrice / pos.leverage
        balance += margin * closeQty / pos.qty   // 释放对应保证金(部分平仓不结算盈亏,MVP 简化)
        positions[symbol] = pos.copy(qty = pos.qty - closeQty)
        return true
    }

    /** 为持仓设置止盈价(开仓后由引擎回填)。 */
    @Synchronized
    fun setTakeProfit(symbol: String, takeProfitPrice: Double?) {
        val pos = positions[symbol] ?: return
        positions[symbol] = pos.copy(takeProfitPrice = takeProfitPrice)
    }

    /** 为持仓设置止损价(开仓后由引擎回填)。 */
    @Synchronized
    fun setStopLoss(symbol: String, stopLossPrice: Double?) {
        val pos = positions[symbol] ?: return
        positions[symbol] = pos.copy(stopLossPrice = stopLossPrice)
    }

    /** 计算某持仓在给定标记价下的未实现盈亏。 */
    fun unrealizedPnl(pos: SimPosition, markPrice: Double): Double {
        val diff = if (pos.side == "LONG") markPrice - pos.entryPrice else pos.entryPrice - markPrice
        return diff * pos.qty
    }

    /**
     * 估算模拟盘强平价(逐仓近似公式,维持保证金率 0.5%)。
     * 多头: entry × (1 - 1/杠杆 + 维持保证金率)
     * 空头: entry × (1 + 1/杠杆 - 维持保证金率)
     */
    fun liquidationPrice(pos: SimPosition): Double {
        val mmr = MAINTENANCE_MARGIN_RATE
        return if (pos.side == "LONG") {
            pos.entryPrice * (1 - 1.0 / pos.leverage + mmr)
        } else {
            pos.entryPrice * (1 + 1.0 / pos.leverage - mmr)
        }
    }

    private fun realizedPnl(pos: SimPosition, markPrice: Double): Double = unrealizedPnl(pos, markPrice)

    /** 当前所有持仓。 */
    fun allPositions(): List<SimPosition> = positions.values.toList()

    fun position(symbol: String): SimPosition? = positions[symbol]

    /** 未实现盈亏合计。 */
    fun totalUnrealizedPnl(markPrices: Map<String, Double>): Double =
        positions.values.sumOf { unrealizedPnl(it, markPrices[it.symbol] ?: it.entryPrice) }

    /** 转成币安兼容的 AccountDto(供 UI 直接展示)。 */
    fun toAccountDto(markPrices: Map<String, Double>): AccountDto {
        val unrealized = totalUnrealizedPnl(markPrices)
        return AccountDto(
            totalWalletBalance = "%.2f".format(balance + unrealized),
            totalUnrealizedProfit = "%.2f".format(unrealized),
            availableBalance = "%.2f".format(balance),
            assets = listOf(
                AssetDto(
                    asset = "USDT",
                    walletBalance = "%.2f".format(balance),
                    unrealizedProfit = "%.2f".format(unrealized),
                    marginBalance = "%.2f".format(balance + unrealized),
                )
            ),
            positions = toPositionDtos(markPrices),
        )
    }

    /** 转成币安兼容的 PositionDto 列表。 */
    fun toPositionDtos(markPrices: Map<String, Double>): List<PositionDto> =
        positions.values.map { pos ->
            val mark = markPrices[pos.symbol] ?: pos.entryPrice
            val pnl = unrealizedPnl(pos, mark)
            PositionDto(
                symbol = pos.symbol,
                positionSide = pos.side,
                positionAmt = if (pos.side == "LONG") "%.8f".format(pos.qty) else "-%.8f".format(pos.qty),
                entryPrice = "%.2f".format(pos.entryPrice),
                markPrice = "%.2f".format(mark),
                unRealizedProfit = "%.2f".format(pnl),
                liquidationPrice = "%.2f".format(liquidationPrice(pos)),
                leverage = pos.leverage.toString(),
            )
        }

    companion object {
        /** 模拟盘维持保证金率(币安常见 0.5%,用于爆仓线估算)。 */
        private const val MAINTENANCE_MARGIN_RATE = 0.005
    }
}
