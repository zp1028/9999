package com.quant.app.domain.strategy

import com.quant.app.data.db.entity.KlineEntity
import com.quant.app.domain.model.AppConfig

/**
 * 趋势跟踪策略:顺势而为。
 * 规则:
 * - 快线 MA 上穿慢线 MA 且价格站上快线 → 做多;
 * - 快线 MA 下穿慢线 MA 且价格跌破快线 → 做空;
 * - 否则观望。
 * 周期/置信度/止损止盈均可通过设置页配置。
 */
class TrendStrategy(
    private val configProvider: () -> AppConfig,
) : Strategy {
    override val id = "trend"
    override val label = "趋势跟踪"
    override val needsAi = false

    override suspend fun evaluate(symbol: String, interval: String, klines: List<KlineEntity>): StrategySignal {
        if (klines.size < 20) return StrategySignal("neutral", 0.0, reason = "K线不足")
        val cfg = configProvider()
        val last = klines.last()
        val maFast = Indicators.ma(klines, cfg.trendMaFast) ?: return neutral()
        val maSlow = Indicators.ma(klines, cfg.trendMaSlow) ?: return neutral()
        if (maFast == maSlow) return neutral("均线重合")

        val bullish = maFast > maSlow && last.close > maFast
        val bearish = maFast < maSlow && last.close < maFast
        val slPct = cfg.strategySlPct / 100.0
        val tpPct = cfg.strategyTpPct / 100.0

        return when {
            bullish -> {
                val entry = last.close
                StrategySignal(
                    direction = "long",
                    confidence = cfg.trendConfidence,
                    entry = entry,
                    stopLoss = entry * (1 - slPct),
                    takeProfit = entry * (1 + tpPct),
                    reason = "均线多头(${cfg.trendMaFast}/${cfg.trendMaSlow}),价格站上快线",
                )
            }
            bearish -> {
                val entry = last.close
                StrategySignal(
                    direction = "short",
                    confidence = cfg.trendConfidence,
                    entry = entry,
                    stopLoss = entry * (1 + slPct),
                    takeProfit = entry * (1 - tpPct),
                    reason = "均线空头(${cfg.trendMaFast}/${cfg.trendMaSlow}),价格跌破快线",
                )
            }
            else -> neutral("均线纠缠,趋势不明")
        }
    }

    private fun neutral(reason: String = "观望") = StrategySignal("neutral", 0.0, reason = reason)
}
