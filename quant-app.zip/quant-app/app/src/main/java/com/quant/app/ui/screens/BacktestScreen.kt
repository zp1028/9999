package com.quant.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.quant.app.domain.backtest.BacktestResult
import com.quant.app.ui.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 回测页(全屏,从驾驶舱入口进入)。 */
@Composable
fun BacktestScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val result by viewModel.backtestResult.collectAsState()
    val loading by viewModel.backtestLoading.collectAsState()

    var strategyId by remember { mutableStateOf("trend") }
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var interval by remember { mutableStateOf("1h") }
    var leverage by remember { mutableStateOf("1") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← 返回") }
            Text("回测", style = MaterialTheme.typography.titleLarge)
        }
        Text(
            "用历史 K 线回放策略,验证胜率与收益(500 根 K线)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // ---- 参数 ----
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("策略", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StrategyChip("AI智能", "ai", strategyId) { strategyId = "ai" }
                    StrategyChip("趋势跟踪", "trend", strategyId) { strategyId = "trend" }
                    StrategyChip("均值回归", "mean_reversion", strategyId) { strategyId = "mean_reversion" }
                    StrategyChip("网格", "grid", strategyId) { strategyId = "grid" }
                }
                OutlinedTextField(
                    value = symbol,
                    onValueChange = { symbol = it.uppercase() },
                    label = { Text("币种(如 BTCUSDT)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = interval,
                        onValueChange = { interval = it },
                        label = { Text("K线周期") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = leverage,
                        onValueChange = { leverage = it },
                        label = { Text("杠杆") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                }
                Button(
                    onClick = {
                        viewModel.runBacktest(
                            strategyId = strategyId,
                            symbol = symbol.ifBlank { "BTCUSDT" },
                            interval = interval.ifBlank { "1h" },
                            leverage = leverage.toIntOrNull()?.coerceIn(1, 125) ?: 1,
                        )
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (loading) "回测中..." else "运行回测")
                }
            }
        }

        // ---- 结果 ----
        result?.let { r ->
            ResultOverview(r)
            EquityCurveCard(r)
            if (r.trades.isNotEmpty()) {
                Text("交易明细(${r.trades.size})", style = MaterialTheme.typography.titleMedium)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(r.trades.asReversed(), key = { "${it.entryTime}-${it.exitTime}" }) { t ->
                        TradeRow(t)
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultOverview(r: BacktestResult) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("回测结果(${r.strategyLabel} · ${r.symbol} · ${r.interval})", style = MaterialTheme.typography.titleSmall)
            val up = r.totalReturnPct >= 0
            Text(
                "总收益 ${"%.2f".format(r.totalReturnPct)}%   (余额 ${"%.2f".format(r.initialBalance)} → ${"%.2f".format(r.finalBalance)})",
                style = MaterialTheme.typography.titleMedium,
                color = if (up) Color(0xFF22C55E) else Color(0xFFEF4444),
            )
            StatGrid(
                listOf(
                    "交易次数" to "${r.tradeCount}",
                    "胜率" to "${"%.1f".format(r.winRate)}%",
                    "盈亏比" to "${"%.2f".format(r.profitFactor)}",
                    "最大回撤" to "${"%.2f".format(r.maxDrawdownPct)}%",
                )
            )
        }
    }
}

@Composable
private fun EquityCurveCard(r: BacktestResult) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("收益曲线", style = MaterialTheme.typography.titleSmall)
            EquityCurveChart(r.equityCurve)
        }
    }
}

/** 收益曲线折线图。 */
@Composable
private fun EquityCurveChart(curve: List<Pair<Long, Double>>) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
    ) {
        if (curve.size < 2) return@Canvas
        val values = curve.map { it.second }
        val min = values.min()
        val max = values.max()
        val range = (max - min).coerceAtLeast(1e-9)
        val stepX = size.width / (curve.size - 1)
        val path = Path()
        curve.forEachIndexed { i, (_, v) ->
            val x = i * stepX
            val y = size.height - ((v - min) / range * size.height).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = if (values.last() >= 0) Color(0xFF22C55E) else Color(0xFFEF4444),
            style = Stroke(width = 4f),
        )
    }
}

@Composable
private fun StatGrid(stats: List<Pair<String, String>>) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        stats.forEach { (label, value) ->
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun TradeRow(t: com.quant.app.domain.backtest.BacktestTrade) {
    val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
    val up = t.pnlPct >= 0
    Card(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(
                    "${if (t.direction == "long") "多" else "空"} @ ${"%.2f".format(t.entryPrice)} → ${"%.2f".format(t.exitPrice)}",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "${fmt.format(Date(t.entryTime))} · ${exitReasonLabel(t.exitReason)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                "${if (up) "+" else ""}${"%.2f".format(t.pnlPct)}%",
                style = MaterialTheme.typography.titleSmall,
                color = if (up) Color(0xFF22C55E) else Color(0xFFEF4444),
            )
        }
    }
}

private fun exitReasonLabel(reason: String): String = when (reason) {
    "take_profit" -> "止盈"
    "stop_loss" -> "止损"
    "reverse" -> "反手"
    else -> "收盘强平"
}

@Composable
private fun StrategyChip(
    label: String,
    id: String,
    current: String,
    onSelect: () -> Unit,
) {
    val selected = current == id
    if (selected) {
        Button(onClick = onSelect) { Text(label) }
    } else {
        OutlinedButton(onClick = onSelect) { Text(label) }
    }
}
