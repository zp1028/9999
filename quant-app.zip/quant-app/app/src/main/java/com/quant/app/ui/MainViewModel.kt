package com.quant.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.quant.app.QuantApplication
import com.quant.app.data.db.entity.AiAnalysisEntity
import com.quant.app.data.db.entity.KlineEntity
import com.quant.app.data.db.entity.NewsEntity
import com.quant.app.data.db.entity.TradeEntity
import com.quant.app.data.db.entity.TrendPredictionEntity
import com.quant.app.data.network.dto.AccountDto
import com.quant.app.data.network.dto.PositionDto
import com.quant.app.data.network.dto.TrendPredictionDto
import com.quant.app.domain.backtest.BacktestResult
import com.quant.app.domain.model.AppConfig
import com.quant.app.domain.predict.AccuracyStats
import com.quant.app.domain.pnl.PnlSummary
import com.quant.app.domain.trade.TradeResult
import com.quant.app.util.runCatchingS
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * 主 ViewModel:聚合配置、账户/持仓轮询、AI 报告、交易历史、情报与预测。
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app get() = getApplication<QuantApplication>()

    private val _config = MutableStateFlow(app.configStore.load())
    val configState: StateFlow<AppConfig> = _config.asStateFlow()

    private val _account = MutableStateFlow<AccountDto?>(null)
    val account: StateFlow<AccountDto?> = _account.asStateFlow()

    private val _positions = MutableStateFlow<List<PositionDto>>(emptyList())
    val positions: StateFlow<List<PositionDto>> = _positions.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _publicIp = MutableStateFlow<String?>(null)
    val publicIp: StateFlow<String?> = _publicIp.asStateFlow()

    /** 连接测试结果(供设置页弹窗展示)。 */
    data class TestResult(val success: Boolean, val message: String)

    private val _testResult = MutableStateFlow<TestResult?>(null)
    val testResult: StateFlow<TestResult?> = _testResult.asStateFlow()

    /** 登录状态(设置页常驻显示):connected=null 未登入 / true 成功 / false 失败。 */
    data class LoginState(
        val connected: Boolean? = null,
        val detail: String = "",
        val loading: Boolean = false,
    )

    private val _aiLoginState = MutableStateFlow(LoginState())
    val aiLoginState: StateFlow<LoginState> = _aiLoginState.asStateFlow()

    private val _binanceLoginState = MutableStateFlow(LoginState())
    val binanceLoginState: StateFlow<LoginState> = _binanceLoginState.asStateFlow()

    /** 输入框内容变化后重置登录状态(新 Key 视为未验证)。 */
    fun resetAiLogin() {
        _aiLoginState.value = LoginState()
    }

    fun resetBinanceLogin() {
        _binanceLoginState.value = LoginState()
    }

    /** 引擎运行状态(供主页状态灯显示)。 */
    private val _engineRunning = MutableStateFlow(com.quant.app.service.TradingService.isRunning)
    val engineRunning: StateFlow<Boolean> = _engineRunning.asStateFlow()

    /** 引擎状态描述(启动失败原因 / 运行详情),主页卡片直接展示。 */
    private val _engineStatus = MutableStateFlow<String?>(null)
    val engineStatus: StateFlow<String?> = _engineStatus.asStateFlow()

    fun dismissTestResult() {
        _testResult.value = null
    }

    // ---------- 交易市场(合约种类搜索) ----------

    /** 币安交易对(合约市场)。 */
    data class MarketSymbol(
        val symbol: String,
        val contractType: String,   // 英文: PERPETUAL / CURRENT_QUARTER ...
        val baseAsset: String,
        val quoteAsset: String,
        val status: String,
    ) {
        /** 合约类型中文标注。 */
        val contractLabel: String
            get() = when (contractType) {
                "PERPETUAL" -> "永续合约"
                "CURRENT_QUARTER" -> "当季合约"
                "NEXT_QUARTER" -> "次季合约"
                "CURRENT_MONTH" -> "当月合约"
                "NEXT_MONTH" -> "次月合约"
                else -> "合约"
            }
    }

    private val _marketSymbols = MutableStateFlow<List<MarketSymbol>>(emptyList())
    val marketSymbols: StateFlow<List<MarketSymbol>> = _marketSymbols.asStateFlow()

    private val _marketLoading = MutableStateFlow(false)
    val marketLoading: StateFlow<Boolean> = _marketLoading.asStateFlow()

    /** 从币安 exchangeInfo 拉取全部合约交易对(实盘/测试网均可,无需签名)。 */
    fun refreshMarket() {
        viewModelScope.launch {
            _marketLoading.value = true
            runCatchingS {
                app.exchangeApi.exchangeInfo().symbols
                    .filter { it.quoteAsset == "USDT" && it.status == "TRADING" }
                    .map {
                        MarketSymbol(
                            symbol = it.symbol,
                            contractType = it.contractType,
                            baseAsset = it.baseAsset,
                            quoteAsset = it.quoteAsset,
                            status = it.status,
                        )
                    }
                    .sortedWith(compareBy({ it.contractLabel }, { it.symbol }))
            }
                .onSuccess { list -> _marketSymbols.value = list }
                .onFailure { e -> _message.value = "拉取市场失败: ${e.message}" }
            _marketLoading.value = false
        }
    }

    /** 按关键字搜索(匹配交易对名或基础币)。 */
    fun searchMarket(query: String): List<MarketSymbol> {
        val q = query.trim().uppercase()
        if (q.isEmpty()) return _marketSymbols.value
        return _marketSymbols.value.filter {
            it.symbol.contains(q) || it.baseAsset.contains(q)
        }
    }

    fun clearMessage() {
        _message.value = null
    }

    fun setMessage(text: String) {
        _message.value = text
    }

    // ---------- 情报与预测 ----------

    private val initialSymbol = app.configStore.load().symbols.firstOrNull() ?: "BTCUSDT"
    private val _selectedSymbol = MutableStateFlow(initialSymbol)
    val selectedSymbol: StateFlow<String> = _selectedSymbol.asStateFlow()

    val klines: StateFlow<List<KlineEntity>> = _selectedSymbol
        .flatMapLatest { sym ->
            app.klineRepository.observeRecent(sym, _config.value.interval, 80)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val latestPrediction: StateFlow<TrendPredictionEntity?> = _selectedSymbol
        .flatMapLatest { sym -> app.database.trendPredictionDao().observeLatest(sym) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val latestForecast: StateFlow<List<TrendPredictionDto.DayForecast>> = latestPrediction
        .map { it?.let { p -> app.predictionValidator.parseForecast(p) } ?: emptyList() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val news: StateFlow<List<NewsEntity>> = app.newsRepository.observeNews(50)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _accuracy = MutableStateFlow(AccuracyStats(0, 0, 0.0))
    val accuracy: StateFlow<AccuracyStats> = _accuracy.asStateFlow()

    val aiAnalyses: StateFlow<List<AiAnalysisEntity>> = app.aiAnalysisRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val trades: StateFlow<List<TradeEntity>> = app.database.tradeDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _pnlSummary = MutableStateFlow(
        PnlSummary(0.0, 0, 0, 0.0, 0.0, 0.0, emptyList()),
    )
    val pnlSummary: StateFlow<PnlSummary> = _pnlSummary.asStateFlow()

    // ---------- 驾驶舱 ----------

    /** 距下次资金费率结算倒计时(UTC 00:00/08:00/16:00)。 */
    private val _fundingCountdown = MutableStateFlow("--:--:--")
    val fundingCountdown: StateFlow<String> = _fundingCountdown.asStateFlow()

    /** 每日盈亏热力图(日期 → 已实现盈亏)。 */
    private val _dailyPnl = MutableStateFlow<Map<String, Double>>(emptyMap())
    val dailyPnl: StateFlow<Map<String, Double>> = _dailyPnl.asStateFlow()

    /** 价格预警列表(内存态,MVP 不持久化)。 */
    private val _priceAlerts = MutableStateFlow<List<PriceAlert>>(emptyList())
    val priceAlerts: StateFlow<List<PriceAlert>> = _priceAlerts.asStateFlow()

    data class PriceAlert(val symbol: String, val target: Double, val above: Boolean)

    init {
        // 恢复持久化的引擎运行标志(进程被杀后重启时)
        _engineRunning.value = com.quant.app.service.TradingService.wasRunning(getApplication())
        refreshAccount()
        viewModelScope.launch {
            _accuracy.value = app.predictionAlertEngine.accuracyStats()
        }
        // 交易记录变化时刷新盈亏汇总
        viewModelScope.launch {
            app.database.tradeDao().observeAll().collect {
                _pnlSummary.value = app.pnlTracker.summary()
                _dailyPnl.value = computeDailyPnl(it)
            }
        }
        // 费率倒计时(每秒刷新)
        viewModelScope.launch {
            while (true) {
                _fundingCountdown.value = fundingCountdownText()
                kotlinx.coroutines.delay(1_000L)
            }
        }
    }

    /** 计算每日盈亏热力图。 */
    private fun computeDailyPnl(trades: List<TradeEntity>): Map<String, Double> {
        val fmt = java.text.SimpleDateFormat("MM-dd", java.util.Locale.getDefault())
        return trades
            .filter { it.realizedPnl != null }
            .groupBy { fmt.format(java.util.Date(it.timestamp)) }
            .mapValues { (_, list) -> list.sumOf { it.realizedPnl ?: 0.0 } }
    }

    /** 距下次费率结算(UTC 8h 周期)倒计时。 */
    private fun fundingCountdownText(): String {
        val now = System.currentTimeMillis()
        val utc = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        val hour = utc.get(java.util.Calendar.HOUR_OF_DAY)
        val nextHour = when {
            hour < 8 -> 8
            hour < 16 -> 16
            else -> 24
        }
        val next = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
            set(java.util.Calendar.HOUR_OF_DAY, nextHour)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }
        val diff = next.timeInMillis - now
        val totalSec = (diff / 1000).coerceAtLeast(0)
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return "%02d:%02d:%02d".format(h, m, s)
    }

    /** 添加价格预警。 */
    fun addPriceAlert(symbol: String, target: Double, above: Boolean) {
        _priceAlerts.value = _priceAlerts.value + PriceAlert(symbol, target, above)
    }

    fun removePriceAlert(alert: PriceAlert) {
        _priceAlerts.value = _priceAlerts.value - alert
    }

    /** 模拟跟单:用最新 AI 信号在模拟盘开仓(仅模拟盘生效)。 */
    fun simulateFollow() {
        viewModelScope.launch {
            val config = _config.value
            if (config.mode != com.quant.app.domain.model.TradingMode.SIMULATED) {
                _message.value = "模拟跟单仅限模拟盘模式"
                return@launch
            }
            val analyses = app.aiAnalysisRepository.getRecent(1)
            val target = analyses.firstOrNull() ?: run {
                _message.value = "暂无 AI 信号,请先启动引擎"
                return@launch
            }
            if (target.direction == "neutral") {
                _message.value = "当前信号为观望,无需跟单"
                return@launch
            }
            val signal = com.quant.app.data.network.dto.AiSignalDto(
                direction = target.direction,
                confidence = target.confidence,
                entry = target.entry,
                stopLoss = target.stopLoss,
                takeProfit = target.takeProfit,
                reasons = listOf("模拟跟单"),
            )
            app.tradingOrchestrator.onAiSignal(
                symbol = target.symbol,
                signal = signal,
                mode = "SIM_FOLLOW",
                onResult = { result ->
                    _message.value = when (result) {
                        is TradeResult.Success -> "模拟跟单成功 ${target.symbol} ${result.trade.side}"
                        is TradeResult.Failure -> "模拟跟单失败: ${result.reason}"
                    }
                },
            )
        }
    }

    fun selectSymbol(symbol: String) {
        _selectedSymbol.value = symbol
    }

    /** 手动刷新新闻情报。 */
    fun refreshNews() {
        viewModelScope.launch {
            runCatchingS { app.newsRepository.refresh() }
                .onSuccess { _message.value = "情报已刷新" }
                .onFailure { e -> _message.value = "情报刷新失败: ${e.message}" }
        }
    }

    /** 手动重新生成当前币种的预测趋势线。 */
    fun regeneratePrediction() {
        viewModelScope.launch {
            runCatchingS {
                app.predictionAlertEngine.generatePrediction(_selectedSymbol.value, _config.value.interval)
            }.onSuccess {
                _message.value = "已重新生成预测"
                _accuracy.value = app.predictionAlertEngine.accuracyStats()
            }.onFailure { e ->
                _message.value = "预测生成失败: ${e.message}"
            }
        }
    }

    // ---------- 回测 ----------

    private val _backtestResult = MutableStateFlow<BacktestResult?>(null)
    val backtestResult: StateFlow<BacktestResult?> = _backtestResult.asStateFlow()

    private val _backtestLoading = MutableStateFlow(false)
    val backtestLoading: StateFlow<Boolean> = _backtestLoading.asStateFlow()

    /** 运行历史回测:拉取 500 根 K线 → 回放策略 → 输出统计。 */
    fun runBacktest(strategyId: String, symbol: String, interval: String, leverage: Int) {
        viewModelScope.launch {
            _backtestLoading.value = true
            _backtestResult.value = null
            try {
                val strategy = app.strategyEngine.get(strategyId) ?: error("未知策略: $strategyId")
                val dtos = app.binanceApi.klines(symbol, interval, 500)
                val klines = dtos.map {
                    KlineEntity(
                        symbol = symbol,
                        interval = interval,
                        openTime = it.openTime,
                        open = it.open,
                        high = it.high,
                        low = it.low,
                        close = it.close,
                        volume = it.volume,
                        closeTime = it.closeTime,
                    )
                }
                val result = app.backtestEngine.run(
                    strategy = strategy,
                    symbol = symbol,
                    interval = interval,
                    klines = klines,
                    initialBalance = 1000.0,
                    leverage = leverage,
                )
                _backtestResult.value = result
            } catch (e: Exception) {
                _message.value = "回测失败: ${e.message}"
            }
            _backtestLoading.value = false
        }
    }

    // ---------- 原有功能 ----------

    fun reloadConfig() {
        _config.value = app.configStore.load()
    }

    fun saveConfig(config: AppConfig) {
        app.configStore.save(config)
        // 模式切换时重新装配交易所;进入模拟盘时重置本地账本
        if (config.mode == com.quant.app.domain.model.TradingMode.SIMULATED) {
            app.simulatedAccount.reset(config.simulatedBalance)
        }
        app.reconfigureExchange()
        reloadConfig()
        refreshAccount()
        _message.value = "配置已保存"
    }

    /** 重置模拟账户(清空持仓,余额恢复初始资金)。 */
    fun resetSimulatedAccount() {
        app.simulatedAccount.reset(_config.value.simulatedBalance)
        refreshAccount()
        _message.value = "模拟账户已重置"
    }

    /** 手动平仓。ratio 为平仓比例(1.0=全平,0.5=平半仓),支持部分平仓。 */
    fun closePosition(symbol: String, ratio: Double) {
        viewModelScope.launch {
            val pos = _positions.value.firstOrNull { it.symbol == symbol }
                ?: run {
                    _message.value = "无 $symbol 持仓"
                    return@launch
                }
            val qty = kotlin.math.abs(pos.positionAmt.toDoubleOrNull() ?: 0.0) * ratio
            if (qty <= 0.0) {
                _message.value = "平仓数量非法"
                return@launch
            }
            // 根据持仓方向确定 positionSide(实盘平仓单方向依赖它)
            val side = if (pos.positionAmt.startsWith("-")) "SHORT" else "LONG"
            val mode = if (_config.value.mode == com.quant.app.domain.model.TradingMode.SIMULATED) "SIM_CLOSE" else "CLOSE"
            runCatchingS {
                app.tradeExecutor.closePosition(
                    symbol = symbol,
                    positionSide = side,
                    quantity = "%.8f".format(qty),
                    mode = mode,
                )
            }.onSuccess { r ->
                refreshAccount()
                val pnlText = r.realizedPnl?.let { " · 盈亏 ${"%.2f".format(it)} USDT" } ?: ""
                _message.value = "已平仓 $symbol ${if (ratio >= 1.0) "(全平)" else "(${(ratio * 100).toInt()}%)"} @ ${"%.2f".format(r.closePrice)}$pnlText"
            }.onFailure { e ->
                _message.value = "平仓失败: ${e.message}"
            }
        }
    }

    /** 测试当前环境连接(币安 Key 或模拟盘),并显示出口 IP。 */
    fun testConnection() {
        viewModelScope.launch {
            _loading.value = true
            runCatchingS {
                val info = app.exchangeApi.testConnection()
                val ip = app.exchangeApi.publicIp()
                _publicIp.value = ip
                TestResult(
                    success = true,
                    message = "连接成功\n账户权益: $info\n出口IP: $ip",
                )
            }
                .onSuccess { result ->
                    _testResult.value = result
                    _message.value = "连接成功,账户权益 ${result.message}"
                }
                .onFailure { e ->
                    _testResult.value = TestResult(success = false, message = "连接失败\n${e.message}")
                    _message.value = "连接失败: ${e.message}"
                }
            _loading.value = false
        }
    }

    /**
     * AI 登入:先用输入框当前值落盘(登入成功 = Key 已保存),
     * 再发真实请求验证 Key(模型响应即成功);状态常驻显示,失败显示原因。
     */
    fun aiLogin(key: String) {
        val trimmed = key.trim()
        if (trimmed.isBlank()) {
            _aiLoginState.value = LoginState(connected = false, detail = "请先填写 AI API Key")
            return
        }
        // 登入前先落盘,避免"登入成功但没点保存,切页后 Key 丢失"
        val updated = _config.value.copy(deepseekApiKey = trimmed)
        app.configStore.save(updated)
        _config.value = updated
        _aiLoginState.value = LoginState(loading = true)
        viewModelScope.launch {
            runCatchingS { app.deepSeekApi.testConnection(trimmed) }
                .onSuccess { msg ->
                    _aiLoginState.value = LoginState(connected = true, detail = "已登入 · $msg")
                    _testResult.value = TestResult(success = true, message = "AI 登入成功\n$msg")
                    _message.value = "AI 登入成功,Key 已保存"
                }
                .onFailure { e ->
                    _aiLoginState.value = LoginState(connected = false, detail = "登入失败 · ${e.message}")
                    _testResult.value = TestResult(success = false, message = "AI 登入失败\n${e.message}")
                }
        }
    }

    /**
     * 币安登入:先用输入框当前值按模式落盘(登入成功 = Key 已保存),
     * 再带签名拉取真实账户权益 + 出口 IP(返回数据即 Key 有效)。
     * 固定走真实币安客户端,校验当前模式(测试网/实盘)对应的 Key。
     */
    fun binanceLogin(apiKey: String, secretKey: String) {
        val cfg = _config.value
        val modeLabel = cfg.mode.label
        val api = apiKey.trim()
        val secret = secretKey.trim()
        if (api.isBlank() || secret.isBlank()) {
            _binanceLoginState.value =
                LoginState(connected = false, detail = "请先填写 $modeLabel 的 API Key 与 Secret")
            return
        }
        // 登入前先按当前模式落盘,避免"登入成功但没点保存,切页后 Key 丢失"
        val updated = when (cfg.mode) {
            com.quant.app.domain.model.TradingMode.TESTNET ->
                cfg.copy(testnetApiKey = api, testnetSecretKey = secret)
            com.quant.app.domain.model.TradingMode.LIVE ->
                cfg.copy(liveApiKey = api, liveSecretKey = secret)
            else -> cfg
        }
        app.configStore.save(updated)
        _config.value = updated
        _binanceLoginState.value = LoginState(loading = true)
        viewModelScope.launch {
            runCatchingS {
                val wallet = app.binanceApi.testConnection()
                val ip = app.binanceApi.publicIp()
                _publicIp.value = ip
                "已登入 · $modeLabel 权益 $wallet · 出口IP $ip"
            }
                .onSuccess { msg ->
                    _binanceLoginState.value = LoginState(connected = true, detail = msg)
                    _testResult.value = TestResult(success = true, message = "币安登入成功\n$msg")
                    _message.value = "币安登入成功,Key 已保存"
                }
                .onFailure { e ->
                    _binanceLoginState.value = LoginState(connected = false, detail = "登入失败 · ${e.message}")
                    _testResult.value = TestResult(success = false, message = "币安登入失败\n${e.message}")
                    _message.value = "币安登入失败: ${e.message}"
                }
        }
    }

    /** 轮询账户与持仓。 */
    fun refreshAccount() {
        viewModelScope.launch {
            _loading.value = true
            runCatchingS { app.exchangeApi.account() }
                .onSuccess { acc ->
                    _account.value = acc
                    _positions.value = acc.positions.filter { it.isOpen }
                }
                .onFailure { e ->
                    _message.value = "账户查询失败: ${e.message}"
                }
            _loading.value = false
        }
    }

    /** 启动量化引擎(前台服务)。 */
    fun startEngine() {
        viewModelScope.launch {
            val config = _config.value
            val missing = config.missingConfigHint
            if (missing != null) {
                val reason = "缺少配置: $missing,请到设置页完成登入"
                _engineStatus.value = reason
                _message.value = reason
                return@launch
            }
            // 实盘安全:实盘 + 自动下单 必须开启保护确认,防止真钱裸跑
            if (config.mode == com.quant.app.domain.model.TradingMode.LIVE &&
                config.autoTrade &&
                !config.liveAutoTradeGuard
            ) {
                val reason = "实盘自动交易需先在设置页开启「实盘自动交易确认」"
                _engineStatus.value = reason
                _message.value = reason
                return@launch
            }
            runCatchingS {
                com.quant.app.service.TradingService.start(getApplication())
                _engineRunning.value = true
                _engineStatus.value = "监控 ${config.symbols.joinToString()} · ${config.interval}"
                "引擎已启动(${config.mode.label})"
            }.onSuccess { msg -> _message.value = msg }
                .onFailure { e ->
                    _engineRunning.value = false
                    _engineStatus.value = "启动失败: ${e.message}"
                    _message.value = "引擎启动失败: ${e.message}"
                }
        }
    }

    fun stopEngine() {
        com.quant.app.service.TradingService.stop(getApplication())
        _engineRunning.value = false
        _engineStatus.value = "已停止"
        _message.value = "引擎已停止"
    }

    /** 快捷切换模式:立即保存并重配交易所(设置页模式 chips 点击即保存)。 */
    fun saveMode(mode: com.quant.app.domain.model.TradingMode) {
        val newConfig = _config.value.copy(mode = mode)
        app.configStore.save(newConfig)
        if (mode == com.quant.app.domain.model.TradingMode.SIMULATED) {
            app.simulatedAccount.reset(newConfig.simulatedBalance)
        }
        app.reconfigureExchange()
        reloadConfig()
        refreshAccount()
        _message.value = "已切换至${mode.label},请按需完成 AI / 币安登入"
    }

    /** 人工确认下单(建议模式):取该条分析记录执行。 */
    fun confirmTrade(symbol: String, analysisId: Long, direction: String, confidence: Double) {
        viewModelScope.launch {
            val config = _config.value
            if (!config.isConfigured) {
                _message.value = "未配置 API Key,无法下单"
                return@launch
            }
            val analyses = app.aiAnalysisRepository.getRecent(100)
            val target = analyses.firstOrNull { it.id == analysisId }
                ?: run {
                    _message.value = "分析记录不存在"
                    return@launch
                }
            val signal = com.quant.app.data.network.dto.AiSignalDto(
                direction = target.direction,
                confidence = target.confidence,
                entry = target.entry,
                stopLoss = target.stopLoss,
                takeProfit = target.takeProfit,
                reasons = listOf("人工确认"),
            )
            app.tradingOrchestrator.onAiSignal(
                symbol = target.symbol,
                signal = signal,
                mode = "MANUAL",
                onResult = { result ->
                    _message.value = when (result) {
                        is TradeResult.Success -> "开仓成功 ${target.symbol} ${result.trade.side}"
                        is TradeResult.Failure -> "开仓失败: ${result.reason}"
                    }
                },
            )
        }
    }
}
