package com.quant.app.domain.strategy

import com.quant.app.data.db.entity.KlineEntity

/**
 * 策略引擎:注册全部策略,按当前配置选择生效策略并评估。
 * 供 TradingService 在每根 K 线收盘时调用,替代原先固定走 AI 的路径。
 */
class StrategyEngine(
    private val strategies: List<Strategy>,
) {
    private val byId = strategies.associateBy { it.id }

    /** 全部策略(供 UI 选择)。 */
    val all: List<Strategy> get() = strategies

    fun get(id: String): Strategy? = byId[id]

    /** 按策略 id 评估 K线,返回信号。 */
    suspend fun evaluate(id: String, symbol: String, interval: String, klines: List<KlineEntity>): StrategySignal? {
        val strategy = byId[id] ?: return null
        return strategy.evaluate(symbol, interval, klines)
    }
}
