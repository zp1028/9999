package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.config.ConsensusStore
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus

object ConsensusEngine {

    fun recordPending(
        store: ConsensusStore,
        lotteryKey: String,
        targetIssue: String,
        list: List<ModelConsensus>
    ) {
        list.forEach { c ->
            val parts = c.leadingDirection.split("/", "、", ",")
                .map { it.trim() }.filter { it.isNotEmpty() }
            val id = "$lotteryKey|$targetIssue|${c.category}"
            store.upsert(
                ConsensusRecord(
                    id = id,
                    lotteryKey = lotteryKey,
                    targetIssue = targetIssue,
                    category = c.category,
                    leadingDirection = c.leadingDirection,
                    candidates = parts.ifEmpty { listOf(c.leadingDirection) },
                    supportRatio = c.supportRatio,
                    participatingPlans = c.participatingPlans,
                    result = "待开"
                )
            )
        }
    }

    fun settleWithDraw(store: ConsensusStore, lotteryKey: String, draw: DrawRecord) {
        store.loadAll(lotteryKey).filter { it.result == "待开" }.forEach { r ->
            if (!issueReached(r.targetIssue, draw.issue)) return@forEach
            val actual = when (r.category) {
                "大小" -> draw.dx
                "单双" -> draw.ds
                "组合" -> draw.combo
                else -> null
            } ?: return@forEach
            val cands = r.candidates.ifEmpty {
                r.leadingDirection.split("/").map { it.trim() }.filter { it.isNotEmpty() }
            }
            val hit = cands.any { it == actual }
            store.upsert(
                r.copy(
                    actual = actual,
                    result = if (hit) "对" else "错",
                    settledAt = System.currentTimeMillis()
                )
            )
        }
    }

    private fun issueReached(pred: String, draw: String): Boolean {
        if (pred == draw) return true
        val a = pred.toLongOrNull()
        val b = draw.toLongOrNull()
        return a != null && b != null && a <= b
    }
}
