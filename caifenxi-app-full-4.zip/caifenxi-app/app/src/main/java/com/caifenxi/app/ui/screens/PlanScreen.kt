package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

private enum class PlanTab(val label: String) {
    CURRENT("本期计划"),
    CONSENSUS_STATS("共识战绩"),
    CONSENSUS_LOG("共识记录"),
    PLAN_STATS("计划战绩")
}

@Composable
fun PlanScreen(vm: MainViewModel) {
    val rows = vm.planRows.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value
    val allHist = vm.planHistory.value
    var tab by remember { mutableStateOf(PlanTab.CURRENT) }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var consensusCat by remember { mutableStateOf("全部") }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16)
    ) {
        Text("计划大厅", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        CaptionMuted(pred?.let { "目标第 ${it.targetIssue} 期" } ?: "加载后显示本期计划")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton(
            text = if (vm.backtestRunning.value) "生成/回测中…" else "重新随机生成并回测",
            onClick = { vm.runBacktest() },
            enabled = !vm.backtestRunning.value,
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(vertical = CaiTokens.S12),
            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            PlanTab.entries.forEach { t ->
                FilterChip(
                    selected = tab == t,
                    onClick = { tab = t },
                    label = { Text(t.label) }
                )
            }
        }

        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(bottom = CaiTokens.ScreenBottom),
            verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            when (tab) {
                PlanTab.CURRENT -> {
                    items(consensus) { c ->
                        GlobalCard {
                            Text("${c.category} 共识 → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                            Text("支持 ${(c.supportRatio * 100).roundToInt()}% · ${c.participatingPlans} 计划")
                        }
                    }
                    if (rows.isEmpty()) {
                        item { GlobalCard { Text("暂无计划，请先首页加载或点上方重新生成。") } }
                    } else {
                        items(rows, key = { it.first.planId }) { (def, rt) ->
                            val hist = allHist.filter { it.planId == def.planId }
                            val current = hist.filter { !it.settled }.ifEmpty {
                                hist.filter { it.targetIssue == pred?.targetIssue }
                            }
                            PlanCard(
                                def = def,
                                rt = rt,
                                currentPreds = current,
                                history = emptyList(), // 本期页不堆历史
                                expanded = expandedId == def.planId,
                                showHistory = false,
                                onToggle = {
                                    expandedId = if (expandedId == def.planId) null else def.planId
                                    if (expandedId == def.planId) vm.loadPlanDetail(def.planId)
                                }
                            )
                        }
                    }
                }
                PlanTab.CONSENSUS_STATS -> {
                    item {
                        val cs = vm.consensusStats.value
                        GlobalCard {
                            Text("共识对错率总览", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(CaiTokens.S12))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                StatCell("已结算", "${cs.hit + cs.miss}")
                                StatCell("对", "${cs.hit}", Color(0xFF2E7D32))
                                StatCell("错", "${cs.miss}", Color(0xFFC62828))
                                StatCell(
                                    "对错率",
                                    if (cs.hit + cs.miss == 0) "-" else "${(cs.hitRate * 100).roundToInt()}%",
                                    MaterialTheme.colorScheme.secondary
                                )
                            }
                            if (cs.pending > 0) CaptionMuted("待开 ${cs.pending} 条")
                            Spacer(Modifier.height(CaiTokens.S8))
                            cs.byCategory.forEach { (cat, pair) ->
                                val (h, m) = pair
                                val rate = if (h + m == 0) 0 else (h * 100.0 / (h + m)).roundToInt()
                                Text("$cat：对 $h / 错 $m · 命中率 $rate%")
                                if (h + m > 0) {
                                    LinearProgressIndicator(
                                        progress = { (rate / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                            Spacer(Modifier.height(CaiTokens.S8))
                            PrimaryButton("清空共识战绩", onClick = { vm.clearConsensusStats() }, ghost = true)
                        }
                    }
                }
                PlanTab.CONSENSUS_LOG -> {
                    val all = vm.consensusRecords.value
                    val cats = listOf("全部") + all.map { it.category }.distinct().sorted()
                    val filtered = all.filter {
                        consensusCat == "全部" || it.category == consensusCat
                    }
                    item {
                        CaptionMuted("共 ${filtered.size} / ${all.size} 条")
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            cats.forEach { cat ->
                                FilterChip(
                                    selected = consensusCat == cat,
                                    onClick = { consensusCat = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }
                    if (filtered.isEmpty()) {
                        item { GlobalCard { Text("暂无共识记录") } }
                    } else {
                        items(filtered.take(60), key = { it.id }) { r ->
                            val color = when (r.result) {
                                "对" -> Color(0xFF2E7D32)
                                "错" -> Color(0xFFC62828)
                                else -> Color(0xFFF9A825)
                            }
                            GlobalCard {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text("第 ${r.targetIssue} 期 · ${r.category}", fontWeight = FontWeight.Bold)
                                        Text(
                                            "共识「${r.leadingDirection}」" +
                                                (r.actual?.let { " → 开奖「$it」" } ?: " · 待开奖")
                                        )
                                        CaptionMuted(
                                            "支持度 ${(r.supportRatio * 100).roundToInt()}% · ${r.participatingPlans} 计划"
                                        )
                                    }
                                    Text(r.result, fontWeight = FontWeight.Bold, color = color)
                                }
                            }
                        }
                    }
                }
                PlanTab.PLAN_STATS -> {
                    item {
                        CaptionMuted("各计划累计成功率 · 点开可看历史预测")
                    }
                    if (rows.isEmpty()) {
                        item { GlobalCard { Text("暂无计划数据") } }
                    } else {
                        items(rows, key = { "s-" + it.first.planId }) { (def, rt) ->
                            val hist = allHist.filter { it.planId == def.planId && it.settled }.take(20)
                            PlanCard(
                                def = def,
                                rt = rt,
                                currentPreds = emptyList(),
                                history = hist,
                                expanded = expandedId == "s-" + def.planId,
                                showHistory = true,
                                onToggle = {
                                    val id = "s-" + def.planId
                                    expandedId = if (expandedId == id) null else id
                                    if (expandedId == id) vm.loadPlanDetail(def.planId)
                                }
                            )
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(CaiTokens.S24)) }
        }
    }
}

@Composable
private fun StatCell(label: String, value: String, color: Color = Color.Unspecified) {
    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(
            value,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
        )
        CaptionMuted(label)
    }
}

@Composable
private fun PlanCard(
    def: PlanDefinition,
    rt: PlanRuntime,
    currentPreds: List<PlanPredictionRecord>,
    history: List<PlanPredictionRecord>,
    expanded: Boolean,
    showHistory: Boolean,
    onToggle: () -> Unit
) {
    GlobalCard(onClick = onToggle) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(def.planName, fontWeight = FontWeight.Bold)
                CaptionMuted("${def.category} · ${def.algorithm} · 窗${def.window}")
                val curOut = currentPreds.firstOrNull()?.output ?: rt.lastPrediction
                if (curOut != null && !showHistory) {
                    Text(
                        "当期：${curOut}" + (currentPreds.firstOrNull()?.targetIssue?.let { " → 第${it}期" } ?: ""),
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text(rt.hitRatePercent, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                CaptionMuted(if (expanded) "收起" else "详情")
            }
        }
        if (rt.sampleCount > 0) {
            LinearProgressIndicator(
                progress = { rt.hitRate.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                color = MaterialTheme.colorScheme.secondary
            )
        }
        AnimatedVisibility(visible = expanded) {
            Column(Modifier.padding(top = CaiTokens.S12)) {
                DetailLine("ID", def.planId)
                DetailLine("参数", "${def.category}/${def.algorithm}/窗${def.window}")
                DetailLine("战绩", "对 ${rt.hitCount}/${rt.sampleCount} · ${rt.hitRatePercent}")
                if (!showHistory) {
                    Text("当期预测", fontWeight = FontWeight.SemiBold)
                    val cur = currentPreds.ifEmpty {
                        rt.lastPrediction?.let {
                            listOf(
                                PlanPredictionRecord(
                                    planId = def.planId, lotteryKey = "",
                                    targetIssue = rt.lastTargetIssue ?: "-", cutoffIssue = "-",
                                    output = it, scoreAtPredict = rt.score, weightAtPredict = rt.weight,
                                    planName = def.planName, category = def.category
                                )
                            )
                        } ?: emptyList()
                    }
                    if (cur.isEmpty()) CaptionMuted("暂无")
                    else cur.forEach { rec ->
                        Text("第${rec.targetIssue}期 → ${rec.output}", fontWeight = FontWeight.Medium)
                    }
                }
                if (showHistory) {
                    Text("历史预测与结果", fontWeight = FontWeight.SemiBold)
                    if (history.isEmpty()) CaptionMuted("尚无已结算历史")
                    else history.forEach { rec ->
                        val tag = when (rec.hit) { true -> "对"; false -> "错"; null -> "—" }
                        val color = when (rec.hit) {
                            true -> Color(0xFF2E7D32)
                            false -> Color(0xFFC62828)
                            null -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("第${rec.targetIssue}期 「${rec.output}」")
                            Text(tag, fontWeight = FontWeight.Bold, color = color)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
