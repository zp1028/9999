package com.caifenxi.app

import android.app.Application
import com.caifenxi.app.data.api.LotteryApiClient
import com.caifenxi.app.data.config.ConfigStore
import com.caifenxi.app.data.config.ManualStore
import com.caifenxi.app.data.config.ConsensusStore
import com.caifenxi.app.data.config.StatStore
import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.repository.DrawRepository

class CaiFenXiApplication : Application() {
    lateinit var database: CaiDatabase private set
    lateinit var configStore: ConfigStore private set
    lateinit var statStore: StatStore private set
    lateinit var manualStore: ManualStore private set
    lateinit var consensusStore: ConsensusStore private set
    lateinit var apiClient: LotteryApiClient private set
    lateinit var drawRepository: DrawRepository private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = CaiDatabase.getInstance(this)
        configStore = ConfigStore(this)
        statStore = StatStore(this)
        manualStore = ManualStore(this)
        consensusStore = ConsensusStore(this)
        apiClient = LotteryApiClient()
        drawRepository = DrawRepository(apiClient, database.drawDao(), configStore)
    }

    companion object {
        lateinit var instance: CaiFenXiApplication private set
    }
}
