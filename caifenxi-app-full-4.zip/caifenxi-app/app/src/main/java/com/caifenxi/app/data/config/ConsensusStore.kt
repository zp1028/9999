package com.caifenxi.app.data.config

import android.content.Context
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class ConsensusStore(context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val prefs = context.getSharedPreferences("caifenxi_consensus", Context.MODE_PRIVATE)

    fun loadAll(lotteryKey: String? = null): List<ConsensusRecord> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val list = json.decodeFromString<List<ConsensusRecord>>(raw)
            if (lotteryKey == null) list else list.filter { it.lotteryKey == lotteryKey }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveAll(list: List<ConsensusRecord>) {
        prefs.edit().putString(KEY, json.encodeToString(list.takeLast(500))).apply()
    }

    fun upsert(record: ConsensusRecord) {
        val list = loadAll().toMutableList()
        val idx = list.indexOfFirst { it.id == record.id }
        if (idx >= 0) {
            // 不覆盖已结算
            if (list[idx].result != "待开" && record.result == "待开") return
            list[idx] = record
        } else list.add(record)
        saveAll(list)
    }

    fun clear(lotteryKey: String? = null) {
        if (lotteryKey == null) prefs.edit().remove(KEY).apply()
        else saveAll(loadAll().filter { it.lotteryKey != lotteryKey })
    }

    fun stats(lotteryKey: String): ConsensusStats {
        val all = loadAll(lotteryKey)
        val settled = all.filter { it.result == "对" || it.result == "错" }
        val hit = settled.count { it.result == "对" }
        val miss = settled.count { it.result == "错" }
        val byCat = settled.groupBy { it.category }.mapValues { (_, rows) ->
            rows.count { it.result == "对" } to rows.count { it.result == "错" }
        }
        return ConsensusStats(
            total = all.size,
            pending = all.count { it.result == "待开" },
            hit = hit,
            miss = miss,
            hitRate = if (hit + miss == 0) 0.0 else hit.toDouble() / (hit + miss),
            byCategory = byCat
        )
    }

    companion object {
        private const val KEY = "consensus_records"
    }
}
