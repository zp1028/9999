package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

private enum class PlanTab(val label: String) {
    POOL("全部计划"),
    CURRENT("本期预测"),
    CONSENSUS_STATS("共识战绩"),
    CONSENSUS_LOG("共识记录")
}

@Composable
fun PlanScreen(vm: MainViewModel) {
    val rows = vm.planRows.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value
    val allHist = vm.planHistory.value
    var tab by remember { mutableStateOf(PlanTab.POOL) }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var categoryFilter by remember { mutableStateOf("全部") }
    var consensusCat by remember { mutableStateOf("全部") }

    val categories = listOf("全部") + rows.map { it.first.category }.distinct()
        .ifEmpty { listOf("大小", "单双", "区间", "号码", "结构", "AI") }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16)
    ) {
        Text("计划大厅", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        CaptionMuted(
            "固定计划池 ${PlanPool.STRATEGY_VERSION} · 启用 ${rows.size}/${vm.prefs.value.planPoolCount.coerceAtMost(40)} · 每类最多 ${vm.prefs.value.planPerCategory}"
        )
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton(
            text = if (vm.backtestRunning.value) "回测中…" else "用固定计划池回测并刷新预测",
            onClick = { vm.runBacktest() },
            enabled = !vm.backtestRunning.value,
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S12),
            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            PlanTab.entries.forEach { t ->
                FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(t.label) })
            }
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(bottom = CaiTokens.ScreenBottom),
            verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            when (tab) {
                PlanTab.POOL -> {
                    item {
                        CaptionMuted("按分类浏览 · 点计划展开参数 / 当期预测 / 历史战绩")
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            categories.forEach { cat ->
                                FilterChip(
                                    selected = categoryFilter == cat,
                                    onClick = { categoryFilter = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }
                    val filtered = if (categoryFilter == "全部") rows
                    else rows.filter { it.first.category == categoryFilter }
                    val grouped = filtered.groupBy { it.first.category }
                    if (filtered.isEmpty()) {
                        item { GlobalCard { Text("暂无计划。请首页加载数据或点上方回测。") } }
                    } else {
                        grouped.forEach { (cat, list) ->
                            item {
                                Text("$cat（${list.size}）", fontWeight = FontWeight.Bold)
                            }
                            items(list, key = { it.first.planId }) { (def, rt) ->
                                val hist = allHist.filter { it.planId == def.planId }
                                val current = hist.filter { !it.settled }.ifEmpty {
                                    hist.filter { it.targetIssue == pred?.targetIssue }
                                }
                                val settled = hist.filter { it.settled }.take(25)
                                FixedPlanCard(
                                    def = def,
                                    rt = rt,
                                    currentPreds = current,
                                    history = settled,
                                    expanded = expandedId == def.planId,
                                    onToggle = {
                                        expandedId = if (expandedId == def.planId) null else def.planId
                                        if (expandedId == def.planId) vm.loadPlanDetail(def.planId)
                                    }
                                )
                            }
                        }
                    }
                }
                PlanTab.CURRENT -> {
                    item {
                        Text("当期共识", fontWeight = FontWeight.Bold)
                        CaptionMuted(pred?.let { "目标第 ${it.targetIssue} 期" } ?: "")
                    }
                    items(consensus) { c ->
                        GlobalCard {
                            Text("${c.category} → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                            Text("支持 ${(c.supportRatio * 100).roundToInt()}% · ${c.participatingPlans} 计划")
                        }
                    }
                    item { Text("各计划本期输出", fontWeight = FontWeight.Bold) }
                    items(rows, key = { "c-" + it.first.planId }) { (def, rt) ->
                        GlobalCard {
                            Text(def.planName, fontWeight = FontWeight.SemiBold)
                            CaptionMuted("${def.category} · ${def.algorithm}")
                            Text(
                                "预测：${rt.lastPrediction ?: "—"}" +
                                    (rt.lastTargetIssue?.let { " → 第${it}期" } ?: ""),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
                PlanTab.CONSENSUS_STATS -> {
                    item {
                        val cs = vm.consensusStats.value
                        GlobalCard {
                            Text("共识对错率", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(CaiTokens.S12))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                Mini("已结算", "${cs.hit + cs.miss}")
                                Mini("对", "${cs.hit}", Color(0xFF2E7D32))
                                Mini("错", "${cs.miss}", Color(0xFFC62828))
                                Mini(
                                    "对错率",
                                    if (cs.hit + cs.miss == 0) "-" else "${(cs.hitRate * 100).roundToInt()}%",
                                    MaterialTheme.colorScheme.secondary
                                )
                            }
                            cs.byCategory.forEach { (cat, pair) ->
                                val (h, m) = pair
                                val rate = if (h + m == 0) 0 else (h * 100.0 / (h + m)).roundToInt()
                                Text("$cat：对 $h / 错 $m · $rate%")
                            }
                            Spacer(Modifier.height(CaiTokens.S8))
                            PrimaryButton("清空共识战绩", onClick = { vm.clearConsensusStats() }, ghost = true)
                        }
                    }
                }
                PlanTab.CONSENSUS_LOG -> {
                    val all = vm.consensusRecords.value
                    val cats = listOf("全部") + all.map { it.category }.distinct().sorted()
                    val filtered = all.filter { consensusCat == "全部" || it.category == consensusCat }
                    item {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            cats.forEach { cat ->
                                FilterChip(
                                    selected = consensusCat == cat,
                                    onClick = { consensusCat = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }
                    items(filtered.take(60), key = { it.id }) { r ->
                        val color = when (r.result) {
                            "对" -> Color(0xFF2E7D32)
                            "错" -> Color(0xFFC62828)
                            else -> Color(0xFFF9A825)
                        }
                        GlobalCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text("第 ${r.targetIssue} 期 · ${r.category}", fontWeight = FontWeight.Bold)
                                    Text("共识「${r.leadingDirection}」" + (r.actual?.let { " → $it" } ?: " · 待开"))
                                }
                                Text(r.result, fontWeight = FontWeight.Bold, color = color)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(CaiTokens.S24)) }
        }
    }
}

@Composable
private fun Mini(label: String, value: String, color: Color = Color.Unspecified) {
    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(
            value, fontWeight = FontWeight.Bold,
            color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
        )
        CaptionMuted(label)
    }
}

@Composable
private fun FixedPlanCard(
    def: PlanDefinition,
    rt: PlanRuntime,
    currentPreds: List<PlanPredictionRecord>,
    history: List<PlanPredictionRecord>,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    GlobalCard(onClick = onToggle) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(def.planName, fontWeight = FontWeight.Bold)
                CaptionMuted("${def.planId} · ${def.algorithm} · 窗${def.window}")
                val cur = currentPreds.firstOrNull()?.output ?: rt.lastPrediction
                if (cur != null) {
                    Text(
                        "当期：$cur",
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text(rt.hitRatePercent, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                CaptionMuted(if (expanded) "收起" else "详情")
            }
        }
        if (rt.sampleCount > 0) {
            LinearProgressIndicator(
                progress = { rt.hitRate.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                color = MaterialTheme.colorScheme.secondary
            )
        }
        AnimatedVisibility(visible = expanded) {
            Column(Modifier.padding(top = CaiTokens.S12)) {
                Text("计划参数", fontWeight = FontWeight.SemiBold)
                Line("ID", def.planId)
                Line("名称", def.planName)
                Line("分类", def.category)
                Line("算法", def.algorithm)
                Line("窗口", "${def.window} 期")
                Line("输出", def.outputFormat.name)
                Line("命中规则", def.hitCriteria.name)
                Line("参与共识", if (def.participateConsensus) "是" else "否")
                Spacer(Modifier.height(CaiTokens.S8))
                Text("战绩", fontWeight = FontWeight.SemiBold)
                Line("成功率", rt.hitRatePercent)
                Line("对 / 样本", "${rt.hitCount} / ${rt.sampleCount}")
                Line("评分 / 权重", "${"%.1f".format(rt.score)} / ${"%.2f".format(rt.weight)}")
                Line("连错 / 状态", "${rt.consecutiveMiss} / ${rt.status}")
                Spacer(Modifier.height(CaiTokens.S8))
                Text("当期预测", fontWeight = FontWeight.SemiBold)
                val curList = currentPreds.ifEmpty {
                    rt.lastPrediction?.let {
                        listOf(
                            PlanPredictionRecord(
                                planId = def.planId, lotteryKey = "",
                                targetIssue = rt.lastTargetIssue ?: "-", cutoffIssue = "-",
                                output = it, scoreAtPredict = rt.score, weightAtPredict = rt.weight,
                                planName = def.planName, category = def.category
                            )
                        )
                    } ?: emptyList()
                }
                if (curList.isEmpty()) CaptionMuted("暂无")
                else curList.forEach {
                    Text("第${it.targetIssue}期 → ${it.output}", fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(CaiTokens.S8))
                Text("历史结果", fontWeight = FontWeight.SemiBold)
                if (history.isEmpty()) CaptionMuted("尚无已结算记录")
                else history.forEach { rec ->
                    val tag = when (rec.hit) { true -> "对"; false -> "错"; null -> "—" }
                    val color = when (rec.hit) {
                        true -> Color(0xFF2E7D32)
                        false -> Color(0xFFC62828)
                        null -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("第${rec.targetIssue}期 「${rec.output}」")
                        Text(tag, fontWeight = FontWeight.Bold, color = color)
                    }
                }
            }
        }
    }
}

@Composable
private fun Line(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
