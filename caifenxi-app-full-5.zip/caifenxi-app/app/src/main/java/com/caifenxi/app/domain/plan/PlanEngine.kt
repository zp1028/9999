package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanStatus
import com.caifenxi.app.domain.model.ScoreWeights
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.min

/**
 * 固定计划池：使用 PLAN-POOL-40 模板，不再每期随机换计划。
 * 可按分类限制启用数量（合计上限 40）。
 */
class PlanEngine {

    private val runtimes = mutableMapOf<String, PlanRuntime>()
    private val careerStats = mutableMapOf<String, PlanRuntime>()
    private val historyPreds = mutableListOf<PlanPredictionRecord>()
    private var activePlans: List<PlanDefinition> = emptyList()

    fun ensureCareerFromPool() {
        PlanPool.ALL.forEach { def ->
            if (!careerStats.containsKey(def.planId)) {
                careerStats[def.planId] = PlanRuntime(planId = def.planId)
            }
        }
    }

    /**
     * 固定启用计划：按分类从模板池取前 N 条，N 由 prefs 控制，总和不超过 40。
     */
    fun buildFixedActivePlans(prefs: UserPrefs): List<PlanDefinition> {
        ensureCareerFromPool()
        val perCat = prefs.planPerCategory.coerceIn(1, 40)
        val maxTotal = prefs.planPoolCount.coerceIn(1, 40)
        val order = listOf("大小", "单双", "区间", "号码", "结构", "AI")
        val selected = mutableListOf<PlanDefinition>()
        for (cat in order) {
            val fromCat = PlanPool.ALL.filter { it.category == cat }.take(perCat)
            selected.addAll(fromCat)
            if (selected.size >= maxTotal) break
        }
        // 若某分类为空名未命中，补其余
        if (selected.size < maxTotal) {
            val rest = PlanPool.ALL.filter { it !in selected }
            selected.addAll(rest.take(maxTotal - selected.size))
        }
        activePlans = selected.take(maxTotal).map { it.copy(randomGenerated = false) }
        activePlans.forEach { def ->
            runtimes[def.planId] = careerStats[def.planId] ?: PlanRuntime(planId = def.planId)
        }
        return activePlans
    }

    fun getActivePlans(): List<PlanDefinition> =
        if (activePlans.isNotEmpty()) activePlans else PlanPool.ALL

    fun getRuntimes(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureCareerFromPool()
        val defs = if (activePlans.isNotEmpty()) activePlans else PlanPool.ALL
        return defs.map { def ->
            def to (careerStats[def.planId] ?: PlanRuntime(def.planId))
        }.sortedWith(
            compareBy<Pair<PlanDefinition, PlanRuntime>> { orderCategory(it.first.category) }
                .thenByDescending { it.second.hitRate }
        )
    }

    fun getRuntimesGrouped(): Map<String, List<Pair<PlanDefinition, PlanRuntime>>> =
        getRuntimes().groupBy { it.first.category }

    private fun orderCategory(cat: String): Int = when (cat) {
        "大小" -> 0; "单双" -> 1; "区间" -> 2; "号码" -> 3; "结构" -> 4; "AI" -> 5; else -> 9
    }

    fun getPredictionHistory(planId: String, limit: Int = 40): List<PlanPredictionRecord> =
        historyPreds.filter { it.planId == planId }.takeLast(limit).reversed()

    fun getAllRecentPredictions(limit: Int = 120): List<PlanPredictionRecord> =
        historyPreds.takeLast(limit).reversed()

    fun getCareerLeaderboard(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureCareerFromPool()
        return PlanPool.ALL.map { it to (careerStats[it.planId] ?: PlanRuntime(it.planId)) }
            .sortedByDescending { it.second.hitRate }
    }

    fun backtest(history: List<DrawRecord>, prefs: UserPrefs, minWarm: Int = 30) {
        buildFixedActivePlans(prefs)
        if (history.size < minWarm + 5) return
        for (i in minWarm until history.size) {
            val cutoff = history.subList(0, i)
            val actual = history[i]
            val preds = predictAll(cutoff, prefs, actual.issue, cutoff.last().issue)
            preds.forEach { rec ->
                val hit = evaluateHit(rec, actual)
                val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
                historyPreds.add(settled)
                updateRuntime(settled)
            }
        }
    }

    fun clearCareer() {
        careerStats.clear()
        runtimes.clear()
        historyPreds.clear()
        activePlans = emptyList()
    }

    fun predictForNext(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        buildFixedActivePlans(prefs)
        return predictAll(history, prefs, targetIssue, cutoffIssue)
    }

    fun consensus(
        lotteryKey: String,
        targetIssue: String,
        preds: List<PlanPredictionRecord>
    ): List<ModelConsensus> {
        val byCat = preds.groupBy { it.category.ifBlank { planCategory(it.planId) } }
        return listOf("大小", "单双", "组合").mapNotNull { cat ->
            val key = if (cat == "组合") listOf("组合", "区间", "结构", "AI") else listOf(cat)
            val list = byCat.filterKeys { it in key }.values.flatten()
            if (list.isEmpty()) return@mapNotNull null
            val weightSum = mutableMapOf<String, Double>()
            var totalW = 0.0
            list.forEach { rec ->
                val rt = careerStats[rec.planId] ?: runtimes[rec.planId] ?: return@forEach
                if (rt.status == PlanStatus.ELIMINATED) return@forEach
                val wr = if (rt.sampleCount >= 5) 0.5 + rt.hitRate * 0.5 else 0.5
                val w = (rt.weight * wr).coerceIn(0.05, 1.5)
                // 多候选拆开计权
                rec.output.split("/").map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
                    weightSum[part] = (weightSum[part] ?: 0.0) + w / rec.output.split("/").size.coerceAtLeast(1)
                }
                totalW += w
            }
            if (totalW <= 0) return@mapNotNull null
            val leading = weightSum.maxByOrNull { it.value } ?: return@mapNotNull null
            // 组合：可输出多候选
            val topParts = weightSum.entries.sortedByDescending { it.value }.take(3).map { it.key }
            val label = if (cat == "组合" && topParts.size > 1) topParts.joinToString("/") else leading.key
            val ratio = leading.value / totalW
            val second = weightSum.values.sortedDescending().getOrNull(1) ?: 0.0
            ModelConsensus(
                lotteryKey = lotteryKey,
                targetIssue = targetIssue,
                category = cat,
                leadingDirection = label,
                supportRatio = ratio,
                disagreement = if (leading.value > 0) second / leading.value else 1.0,
                participatingPlans = list.size,
                detail = weightSum.mapValues { it.value / totalW }
            )
        }
    }

    fun settlePendingWithDraw(draw: DrawRecord) {
        val pending = historyPreds.filter { !it.settled && issueReached(it.targetIssue, draw.issue) }
        pending.forEach { rec ->
            val hit = evaluateHit(rec, draw)
            val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
            val idx = historyPreds.indexOfFirst {
                it.planId == rec.planId && it.targetIssue == rec.targetIssue && !it.settled
            }
            if (idx >= 0) historyPreds[idx] = settled else historyPreds.add(settled)
            updateRuntime(settled)
        }
    }

    private fun issueReached(predIssue: String, drawIssue: String): Boolean {
        if (predIssue == drawIssue) return true
        val a = predIssue.toLongOrNull()
        val b = drawIssue.toLongOrNull()
        return a != null && b != null && a <= b
    }

    private fun predictAll(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        val plans = if (activePlans.isNotEmpty()) activePlans else buildFixedActivePlans(prefs)
        return plans.mapNotNull { def ->
            val out = runPlan(def, history, prefs) ?: return@mapNotNull null
            val rt = careerStats[def.planId] ?: PlanRuntime(def.planId)
            val rec = PlanPredictionRecord(
                planId = def.planId,
                lotteryKey = history.lastOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                output = out,
                scoreAtPredict = rt.score,
                weightAtPredict = rt.weight,
                planName = def.planName,
                category = def.category
            )
            historyPreds.removeAll { it.planId == def.planId && it.targetIssue == targetIssue && !it.settled }
            historyPreds.add(rec)
            if (historyPreds.size > 5000) {
                historyPreds.subList(0, historyPreds.size - 4000).clear()
            }
            careerStats[def.planId] = rt.copy(lastPrediction = out, lastTargetIssue = targetIssue)
            runtimes[def.planId] = careerStats.getValue(def.planId)
            rec
        }
    }

    private fun runPlan(def: PlanDefinition, history: List<DrawRecord>, prefs: UserPrefs): String? {
        val slice = history.takeLast(def.window.coerceAtLeast(5).coerceAtMost(history.size))
        if (slice.size < 3) return null
        val comboN = prefs.comboPredCount.coerceIn(1, 4)
        val numN = prefs.positionTopN.coerceIn(1, 10).coerceAtLeast(prefs.zuheTopN.coerceIn(1, 10))
        return when (def.category) {
            "大小" -> majority(slice.mapNotNull { it.dx }, def, prefs)
            "单双" -> majority(slice.mapNotNull { it.ds }, def, prefs)
            "组合" -> topMajors(slice.mapNotNull { it.combo }, def, prefs, comboN)
            "区间", "结构", "AI" -> topMajors(slice.mapNotNull { it.combo }, def, prefs, comboN)
            "号码" -> {
                val cnt = mutableMapOf<Int, Int>()
                slice.forEach { r -> r.numbers.forEach { n -> cnt[n] = (cnt[n] ?: 0) + 1 } }
                cnt.entries.sortedByDescending { it.value }.take(numN)
                    .joinToString("/") { it.key.toString() }
                    .ifBlank { null }
            }
            else -> majority(slice.mapNotNull { it.dx }, def, prefs)
        }
    }

    private fun topMajors(seq: List<String>, def: PlanDefinition, prefs: UserPrefs, topN: Int): String? {
        if (seq.isEmpty()) return null
        val scores = when (def.algorithm) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val ewma = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { lab ->
                        val t = if (lab == x) 1.0 else 0.0
                        ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                    }
                }
                ewma
            }
            "MKV1" -> {
                // 修复：直接返回 majority 的结果（String?），而不是 Map
                if (seq.size < 2) return majority(seq, def, prefs)
                val last = seq.last()
                val next = mutableMapOf<String, Double>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0.0) + 1.0
                }
                if (next.isEmpty()) seq.groupingBy { it }.eachCount().mapValues { it.value.toDouble() }
                else next
            }
            else -> seq.groupingBy { it }.eachCount().mapValues { it.value.toDouble() }
        }
        return scores.entries.sortedByDescending { it.value }.take(topN.coerceAtLeast(1))
            .joinToString("/") { it.key }
            .ifBlank { null }
    }

    private fun majority(seq: List<String>, def: PlanDefinition, prefs: UserPrefs): String? {
        if (seq.isEmpty()) return null
        return when (def.algorithm) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val ewma = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { lab ->
                        val t = if (lab == x) 1.0 else 0.0
                        ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                    }
                }
                ewma.maxByOrNull { it.value }?.key
            }
            "MKV1" -> {
                if (seq.size < 2) return seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                val last = seq.last()
                val next = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0) + 1
                }
                next.maxByOrNull { it.value }?.key
                    ?: seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            }
            else -> seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        }
    }

    private fun evaluateHit(rec: PlanPredictionRecord, actual: DrawRecord): Boolean {
        val cat = rec.category.ifBlank { planCategory(rec.planId) }
        val parts = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        return when (cat) {
            "大小" -> parts.any { it == actual.dx } || rec.output == actual.dx
            "单双" -> parts.any { it == actual.ds } || rec.output == actual.ds
            "组合", "区间", "结构", "AI" -> {
                val a = actual.combo ?: return false
                parts.any { it == a }
            }
            "号码" -> parts.any { it.toIntOrNull()?.let { n -> n in actual.numbers } == true }
            else -> parts.any { it == actual.dx || it == actual.ds || it == actual.combo }
        }
    }

    private fun updateRuntime(rec: PlanPredictionRecord) {
        val prev = careerStats[rec.planId] ?: PlanRuntime(planId = rec.planId)
        val hit = rec.hit == true
        val sample = prev.sampleCount + 1
        val hits = prev.hitCount + if (hit) 1 else 0
        val miss = if (hit) 0 else prev.consecutiveMiss + 1
        val hitRate = hits.toDouble() / sample
        var score = hitRate * ScoreWeights.RECENT_HIT * 2.5
        score += min(sample / 100.0, 1.0) * ScoreWeights.SAMPLE
        if (miss >= 5) score -= ScoreWeights.STREAK * (miss - 4) * 0.15
        score = score.coerceIn(0.0, 100.0)
        var weight = 0.5 + (hitRate - 0.5) * 0.6
        weight = weight.coerceIn(0.35, 1.15)
        val status = when {
            miss >= 12 && sample >= 30 -> PlanStatus.DEMOTED
            sample >= 100 && hitRate < 0.42 -> PlanStatus.ELIMINATED
            score >= 65 && sample >= 50 -> PlanStatus.PROMOTED
            else -> PlanStatus.ACTIVE
        }
        val updated = prev.copy(
            weight = weight, score = score, sampleCount = sample, hitCount = hits,
            consecutiveMiss = miss, status = status,
            lastPrediction = rec.output, lastTargetIssue = rec.targetIssue
        )
        careerStats[rec.planId] = updated
        runtimes[rec.planId] = updated
    }

    private fun planCategory(planId: String): String =
        activePlans.find { it.planId == planId }?.category
            ?: PlanPool.ALL.find { it.planId == planId }?.category
            ?: ""
}